/** 
 * 平台数据接口。
 * 由于每款游戏通常需要发布到多个平台上，所以提取出一个统一的接口用于开发者获取平台数据信息
 * 推荐开发者通过这种方式封装平台逻辑，以保证整体结构的稳定
 * 由于不同平台的接口形式各有不同，白鹭推荐开发者将所有接口封装为基于 Promise 的异步形式
 */
declare interface Platform {
    /** 登录 */
    login(incode): Promise<any>;
    /** 获取用户信息(之前已经授权过) */
    getUserInfo(): Promise<any>;
    /** 获取用户信息(之前没有授权过，需要调用授权按钮) */
    getUserInfoByButton(): Promise<any>;
    /** 设置右上角的分享功能（被动分享） */
    showShareMenu(): Promise<any>;
    /** 点击调用分享框（主动分享） */
    shareAppMessage(code: string, txt: string, imgData: { id: string, url: string }): Promise<any>;
    /** 查询是否授权过用户信息 */
    authorizeJurisdiction(): Promise<any>;
    /** 获取用户登录的AccessToken */
    getAccessToken(appId, secret): Promise<any>;
    /** 上报用户数据后台接口（将该用户的数据托管到后台） */
    setUserStorage(score, access_token, openid, session_key): Promise<any>;
    /** 上传用户分数（最高分） */
    setUseValue(playervalue, highestfraction): Promise<any>;
    /** 获取开放数据域 */
    getopenDataContext(): Promise<any>;
    /** 获取该用户所有好友的信息 */
    getFriendCloudStorage(): Promise<any>;
    /** 手机震动 */
    vibrateShort(): Promise<any>;
    /** 监听小游戏失去页面 */
    onHide(): Promise<any>;
    /** 监听小游戏激活页面 */
    onShow(): Promise<any>;
    getIsHide(): Promise<any>;
    getIsShow(): Promise<any>;
    createBannerAd1(): Promise<any>;
    createBannerAd2(): Promise<any>;
    createRewardedVideoAd(type:string): Promise<any>;
    /** 跳转到其他小游戏 */
    openGame(id): Promise<any>;
    /** 获取设备信息 */
    getPhoneInfo(): Promise<any>;
    /** 获取在启动时的参数 */
    getLaunchOptionsSync(): Promise<any>;
    /** 隐藏广告 */
    hideBannerAd(ad:any):Promise<any>;
    /** 显示广告 */
    showBannerAd(ad:any):Promise<any>;
    /** 创建插屏广告 */
    createInterstitialAd():Promise<any>;
}
class DebugPlatform implements Platform {
    async getUserInfo() {

    }
    async getUserInfoByButton() {

    }
    async login() {

    }
    async getAccessToken(appId, secret) {

    }
    async showShareMenu() {

    }
    async shareAppMessage() {

    }
    async getopenDataContext() {

    }
    async getFriendCloudStorage() {

    }
    async setUseValue(playervalue, highestfraction) {

    }
    async setUserStorage(score, access_token, openid, session_key) {

    }
    async authorizeJurisdiction() {

    }
    async vibrateShort() {

    }
    async onShow() {

    }
    async onHide() {

    }
    async getIsHide() {

    }
    async getIsShow() {

    }
    async createBannerAd1() {

    }
    async createBannerAd2() {

    }
    async createRewardedVideoAd(type:string) {

    }
    async openGame() {

    }
    async getPhoneInfo() {

    }
    async getLaunchOptionsSync() {

    }
    async hideBannerAd(ad:any) {

    }
    async showBannerAd(ad:any) {

    }
    async createInterstitialAd() {

    }
}
if (!window.platform) {
    window.platform = new DebugPlatform();
}

declare let platform: Platform;
declare interface Window {
    platform: Platform
}
