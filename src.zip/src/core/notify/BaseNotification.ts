module game{
	/**
	 *
	 * @author 
	 */
	export abstract class BaseNotification {
		public constructor() {
		}

		/**
		 * 注册
		 * */
		public addRegister(name: string, obj: any): void {
			NotifyManager.getInstance().addObj(name, obj);
		}

		/**
		 * 移除
		 * */
		public removeRegister(name: string): void {
			NotifyManager.getInstance().removeObj(name);
		}

		/** 罗列要接收的通知 */
		public abstract listNotification(): Array<NotifyConst>;
		/** 接收通知 */
		public abstract handleNotification(type: NotifyConst | UiNotifyConst, body?: any): void;

		/** 发送全局通知 */
		protected sendNotification(type: NotifyConst, body?: any): void {
			NotifyManager.getInstance().distribute(type, body);
		}
	}
}
