module game{
	/**
	 * 通知管理类
     * @public distribute Mediator、Server之间指派事件
     * @public distributeByUI UI指派事件给Mediator
	 */
    export class NotifyManager {

        /**
         * 对象字典
         * key 对象名字，string
         * value 对象引用
         */
        private ObjDic: Object;

        /**
         * type字典
         * 一个type对应多个Obj，方便消息的派发
         * key 消息类型，string
         * value 对象名字，string
         */
        private typeDic: Object;

        // ------------------------ 单例模式 ---------------------
        private static instance: NotifyManager;
        private constructor() {
            this.ObjDic = new Object();
            this.typeDic = new Object();
        }
        public static getInstance(): NotifyManager {
            if (this.instance == null) {
                this.instance = new NotifyManager();
            }
            return this.instance;
        }
        // -----------------------------------------------------------

        /**
         * Mediator、Server之间指派事件
         * @param type 事件类型
         * @param body 事件数据
         * @param className 可选，如果className存在，则会派发给指定类
         */
        public distribute(type: NotifyConst | UiNotifyConst, body?: any, className?: string): void {
            let n: BaseNotification;
            this.typeDic[type] && this.typeDic[type].forEach(name => {
                if (!className || className === name) {
                    n = <BaseNotification>this.ObjDic[name];
                    n && n.handleNotification(type, body);
                }
            });
        }

        /**
         * 添加一个对象到字典中
         * @param name {string} 类名
         * @param obj {Object} 对象
         */
        public addObj(name: string, obj: Object): void {
            if (this.ObjDic[name]) {
                // DebugUtil.debug("Notify repeat Register:" + name);
            } else {
                this.ObjDic[name] = obj;
                // 配置type字典
                this.configurationType(name, obj);
            }
        }

		/**
		 * 配置type字典
         * @param name {string} 类名
         * @param obj {Object} 对象
		 */
        private configurationType(name: string, obj: Object): void {
            // let n = <INotification>obj;
            // if (n) {
            //     let list = n.listNotification();
            //     let len = list.length;
            //     let type = -1;
            //     for (let i = 0; i < len; i++) {
            //         type = list[i];
            //         if (this.typeDic[type]) {
            //             //添加到末尾
            //             this.typeDic[type].push(name);
            //         }
            //         else {
            //             this.typeDic[type] = [name];
            //         }
            //     }
            // }
            let n = <BaseNotification>obj;
            n && n.listNotification().forEach(type => {
                if (this.typeDic[type]) {
                    this.typeDic[type].push(name); // 添加到末尾
                } else {
                    this.typeDic[type] = [name];
                }
            });
        }

        /**
         * 从字典中移除一个对象
         * @param name {string} 类名
         */
        public removeObj(name: string): void {
            if (this.ObjDic[name]) {
                this.cleanType(name);
                delete this.ObjDic[name];
            }
        }

        /**
         * 清除类型
         */
        private cleanType(name: string): void {
            let n = <BaseNotification>this.ObjDic[name];
            if (n) {
                let list = n.listNotification();
                let len = list.length;
                let type: NotifyConst;
                let arr: Array<string>;
                for (let i = 0; i < len; i++) {
                    type = list[i];
                    arr = this.typeDic[type];
                    if (arr) {
                        let index = arr.indexOf(name);
                        if (index > -1) {
                            arr.splice(index, 1);
                            if (arr.length > 0) {
                                this.typeDic[type] = arr;
                            }
                            else {
                                arr = null;
                                this.typeDic[type] = null;
                                delete this.typeDic[type];
                            }
                        }
                    }
                }
            }
        }
    }

}
