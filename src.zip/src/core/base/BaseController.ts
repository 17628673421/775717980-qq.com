module game{
	/**
	 * 控制器的基类
	 * 强制重写的方法：
	 * listNotification() 罗列要接收的通知
	 * handleNotification() 接收通知
	 * start() 启用
	 * initData() 初始化UI数据，在UI加载完毕后调用
	 */
	export abstract class BaseController extends BaseNotification {
		public constructor() {
			super();
			this.addRegister(egret.getQualifiedClassName(this), this);
		}
		/** 系统层UI */
		protected sysUI:BaseUI;
		/** controller控制的UI对象 */
		protected ui: BaseUI;
		/**界面是否ok */
		protected isUIComplete: boolean;

		/** 罗列要接收的通知 */
		abstract listNotification(): Array<number>;
		/** 接收通知 */
		abstract handleNotification(type: number, body: any): void;

		/** 通知UI */
		protected notifyUI(type: UiCommand, body?: any) {
			if (this.ui) {
				this.ui.onControllerCommand(type, body);
			}
			if(this.sysUI)
			{
				this.sysUI.onControllerCommand(type, body);
			}
		}

		/** 启用 */
		public abstract start();

		/** 打开UI */
		protected enterUI(ui: BaseUI,num?:number): void {
			this.ui = ui;
			this.ui.once(eui.UIEvent.CREATION_COMPLETE, () => {
				// this.sendNotification(NotifyConst.uiComplete)
				this.isUIComplete = true;
				this.initData();
			}, this);
			LayerManager.getInstance().addUI(this.ui,num);
		}

		/**设置系统UI */
		protected setSysUI(ui: BaseUI,num?:number){
			this.sysUI = ui
			this.sysUI.once(eui.UIEvent.CREATION_COMPLETE, () => {
				// this.sendNotification(NotifyConst.uiComplete)
				this.isUIComplete = true;
				this.initData();
			}, this);
			LayerManager.getInstance().addUI(this.sysUI,num);
		}

		/** 初始化UI数据 */
		protected abstract initData(): void;

		/** 关闭 */
		public dispose() {
			this.ui.dispose();
		}
	}
}
