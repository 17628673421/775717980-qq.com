module game{
	/**
	 * @desc 基本的UI界面显示类
	 * 强制重写的方法：
     * initUI() 组件创建完成初始化显示组件
     * initListener() 添加UI界面监听
     * onControllerCommand() 收到Controller的通知
	 */
    export abstract class BaseUI extends BaseComponent {

        /** 事件字典 */
        private eventDic: Dictionary;

        public constructor() {
            super();
            this.eventDic = new Dictionary();
        }

        /** 在本身以及子控件初始化完毕后自动触发 */
        protected childrenCreated() {
            this.initUI();
            this.onStageResize(null);
        }

        /** 组件创建完成初始化显示组件 */
        protected abstract initUI(): void;

        /**
         * 收到Controller的通知
         */
        public abstract onControllerCommand(type: UiCommand, params?: any): void;

        /**
         * 当舞台尺寸发生变化,需被子类继承
         */
        public onStageResize(evt: egret.Event): void {
            var stageW = StageUtil.width,
                stageH = StageUtil.height;
            this.scaleX = stageW / StageUtil.DesignWidth;
            this.scaleY = stageH / StageUtil.DesignHeight;
        }

        /**
         * 事件注册，所有事件的注册都需要走这里
         */
        protected registerEvent(target: egret.EventDispatcher, type: string, callBack: Function, thisObject: any): void {
            var eventParams: any = {};
            eventParams.target = target;
            eventParams.type = type;
            eventParams.callBack = callBack;
            eventParams.thisObject = thisObject;
            if (target) {
                target.addEventListener(type, callBack, thisObject);
                this.eventDic.setValue(target.hashCode + type, eventParams);
            }
        }
        /**
         * 统一移除所有事件
         */
        protected removeAllEvent(): void {
            var eventList: Array<any> = this.eventDic.getAllValue();
            while (eventList.length > 0) {
                var tempEvent: any = eventList.shift();
                if (tempEvent.target != null) {
                    tempEvent.target.removeEventListener(tempEvent.type, tempEvent.callBack, tempEvent.thisObject);
                }
            }
            this.eventDic.clear();
        }

        /**
         * 资源释放
         * @$isDispos 是否彻底释放资源
         */
        public dispose(): void {
            this.removeAllEvent();
            if (this.parent) {
                this.parent.removeChild(this);
            }
        }
    }
}
