module game{
	/**
	 * 项解析器的基类
	 * 实现了一个发送通知到Controller的方法
	 */
	export class BaseItemRenderer extends eui.ItemRenderer implements ISendNofity {
		public constructor() {
			super();
		}

		/** 发送全局通知 */
		sendNotification(type: UiNotifyConst, body?: any): void {
			NotifyManager.getInstance().distribute(type, body);
		}
	}
}