module game{
	/**
	 * 组件的基类
	 * 实现了一个发送通知到Controller的方法
	 */
	export class BaseComponent extends eui.Component implements ISendNofity {
		public constructor() {
			super();
		}

		/** 发送通知到Controller */
		sendNotification(type: UiNotifyConst, body?: any): void {
			NotifyManager.getInstance().distribute(type, body);
		}
	}
}
