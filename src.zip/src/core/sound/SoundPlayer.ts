module game {
	export class SoundPlayer {
		private static musicChannel: egret.SoundChannel;
		private static effectChannels: egret.SoundChannel[] = [];
		public static isSoundOpen: boolean = false;
		public static isMusicOpen: boolean = false;
		public constructor() {
		}

		/**播放音效 */
		public static playSound(name, callback?: Function, callbackObj?: any) {
			if (!this.isSoundOpen) return;
			let mp3 = RES.getRes(name);
			let sound: egret.Sound = mp3;
			let channel = sound.play(0, 1);
			channel.addEventListener(egret.Event.SOUND_COMPLETE, () => {
				if (callback) {
					callback.apply(callbackObj);
				}
			}, this)
		}
		public static playSoundWav(name, callback?: Function, callbackObj?: any) {
			if (!this.isSoundOpen) return;
			let wav = RES.getRes(name);
			let sound: egret.Sound = wav;
			let channel = sound.play(0, 1);
			channel.addEventListener(egret.Event.SOUND_COMPLETE, () => {
				if (callback) callback.apply(callbackObj);
			}, this)
		}
		/**播放音乐 */
		public static playMusic(name: string) {
			if (!this.isMusicOpen) return;
			if (this.musicChannel) {
				this.musicChannel.stop();
			}
			let sound: egret.Sound = RES.getRes(name);
			this.musicChannel = sound.play(0);
		}
		/**打开音效 */
		public static openSound(b: boolean) {
			this.isSoundOpen = b;
			this.isMusicOpen = b;
			if (b == false) {
				if (this.musicChannel) {
					this.musicChannel.stop();
					this.musicChannel = null;
				}
				while (this.effectChannels.length > 0) {
					let c = this.effectChannels.pop();
					if (c) {
						c.stop();
					}
				}
			}
		}

		/** 打开背景音乐 */
		public static openMusic(): void {
			this.isMusicOpen = true;
		}

		/**关闭背景音乐 */
		public static closeMusic() {
			this.isMusicOpen = false;
			if (this.musicChannel) {
				this.musicChannel.stop();
				this.musicChannel = null;
			}
			while (this.effectChannels.length > 0) {
				let c = this.effectChannels.pop();
				if (c) {
					c.stop();
				}
			}
		}

	}
}