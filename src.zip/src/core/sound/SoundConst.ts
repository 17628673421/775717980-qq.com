module game {
	export class SoundConst {

		/** 点击音效 */
		public static click:string = "button01_wav";
		/** 背景音乐 */
		public static bg:string = "bg_mp3";
	}
}