module game{
    /**
    *
    * @author 
    *
    */
    export class StageUtil {
        public static DesignWidth = 1080;
        public static DesignHeight = 1920;
        public static stage: egret.Stage;
        public static canvasHeight: number = 0;
        public static scaleMode;
        public constructor() {
        }
        public static get width(): number {
            if (this.stage) return this.stage.stageWidth;
            else return -1;
        }
        public static get height(): number {
            if (this.stage) return this.stage.stageHeight;
            else return -1;
        }
        public static get frameRate(): number {
            if (this.stage) return this.stage.frameRate;
            else return -1;
        }
        /**将内容复制到剪切板 */
        public static copyTxt(txt: string): void {
            window["copyTxt"](txt);
        }

        /**设置屏幕同时可触摸数量 */
        public static maxTouches(num: number): void {
            if (this.stage) this.stage.maxTouches = num;
        }
    }
}
