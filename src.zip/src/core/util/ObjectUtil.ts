namespace game.ObjectUtil {
    const compareObject = <T>(oldVal, newVal: T, smart?: boolean) => {
        let result,
            flag = false;
        switch ([oldVal, newVal].filter(item => item instanceof Object).length) {
            // 新旧值都是Object的情况下，进行递归比较得到结果
            case 2:
                let oldKey = Object.keys(oldVal),
                    newKey = Object.keys(newVal);
                // 默认情况下，对数组只考虑增量，不考虑复杂变化
                if (!smart && oldVal instanceof Array && newVal instanceof Array) {
                    result = [];
                    newVal.forEach(item => {
                        if (!oldVal.some(old => isEqualObject(old, item))) {
                            result.push(copyObject(item));
                            flag = true;
                        }
                    });
                } else {
                    result = newVal instanceof Array ? [] : {};
                    oldKey.forEach(item => {
                        let temp = compareObject(oldVal[item], newVal[item], smart);
                        if (temp.flag) {
                            result[item] = temp.result;
                            flag = true;
                        }
                    });
                    newKey.forEach(item => {
                        if (oldKey.indexOf(item) === -1) {
                            result[item] = copyObject(newVal[item]);
                            flag = true;
                        }
                    });
                }
                break;
            // 只有其中一个值是Object的情况下，如果新值是Object，那么将新值的拷贝作为结果，否则直接将新值作为结果
            case 1:
                result = newVal instanceof Object ? copyObject(newVal) : newVal;
                flag = true;
                break;
            // 新旧值都不是Object的情况下，如果新旧值不相等，那么将新值作为结果
            default:
                if (oldVal !== newVal) {
                    result = newVal;
                    flag = true;
                }
        }
        return {
            result: <T>result,
            flag: flag
        };
    };

    export const minusObject = <T>(oldVal, newVal: T, smart?: boolean) => compareObject(oldVal, newVal, smart).result;

    export const copyObject = <T>(obj: T) => minusObject({}, obj);

    export const isEqualObject = (oldVal, newVal) => !compareObject(oldVal, newVal, true).flag;

    export const isEmptyObject = (obj, unsafe?: boolean) => unsafe && (obj === undefined || obj === null) ? true : isEqualObject({}, obj);
}