module game {
	/**
	 * @desc 数字工具类
	 */
    export class NumberUtil {

        /**返回三位数的数字 前面用0补齐*/
        public static getNum3(n): string {
            if (n >= 0 && n < 10) return "00" + n;
            if (n >= 10 && n < 100) return "0" + n;
            if (n >= 100) return "" + n;
            return "";
        }
        public static getMax(arr: number[] = []): number {
            let max;
            if (arr.length > 0) {
                max = arr[0];
                for (let i = 0; i < arr.length; i++) {
                    if (arr[i] > max) {
                        max = arr[i];
                    }
                }
            }
            else {
                max = 0;
            }
            return max;
        }

        public static getMin(arr: number[] = []): number {
            let min;
            if (arr.length > 0) {
                min = arr[0];
                for (let i = 0; i < arr.length; i++) {
                    if (arr[i] < min) {
                        min = arr[i];
                    }
                }
            }
            else {
                min = 0;
            }
            return min;
        }

        /**数字处理转化为带汉字单位的小数 */
        public static numberToString(num: number): string {
            if (num == 0 || !num) {
                return "0";
            }
            let number = 0;
            let result = "";
            let suffix = "";
            let str: string = "";
            if (num >= 100000000) {
                number = num / 100000000;
                suffix = "亿";
            } else if (num >= 10000 && num < 100000000) {
                number = num / 10000;
                suffix = "万";
            } else if (num >= 1000 && num < 10000) {
                number = num / 1000;
                suffix = "千";
            } else {
                number = num;
                suffix = "";
            }
            if ((number + "").indexOf(".") != -1) {
                if ((number + "").split(".")[1].charAt(1)) {
                    str = (number + "").split(".")[0] + "." + (number + "").split(".")[1].charAt(0) + (number + "").split(".")[1].charAt(1);
                } else {
                    str = (number + "").split(".")[0] + "." + (number + "").split(".")[1].charAt(0) + "0";
                }
                if (str.split(".")[1].indexOf("0") != -1) {
                    if (str.split(".")[1] == "00") {
                        result = str.split(".")[0] + suffix;
                    } else if (str.split(".")[1].charAt(1) == "0") {
                        result = str.split(".")[0] + "." + str.split(".")[1].charAt(0) + suffix;
                    } else {
                        result = str + suffix;
                    }
                } else {
                    result = str + suffix;
                }
            } else {
                result = number + suffix;
            }
            // str = number.toFixed(2);
            // str.split(".")[1] == "00" ? result = str.split(".")[0] + suffix : result = str + suffix;
            return result;
        }


    	/**
    	 * 传入数字，返回千位逗号隔开的字符串效果
         * @param num 单位为分
         * @param isShort 是否为简写-->例如：10000000 --> 100k 1为大于等于1000就开始缩写 2为大于100000才开始缩写 3是保留一位小数
    	 */
        public static getSplitNumStr(num: number, isShort = 0): string {
            if (typeof num != "number") {
                return "0";
            }
            let preFix = num >= 0 ? "" : "-";
            num = Math.abs(num);
            num = num || 0;
            num = num / 100;
            //小数部分
            var decimal = "";
            var code: string = num.toString(10);
            if (code.indexOf(".") != -1) {
                // code = num.toFixed(2);
                let a = (num + "").split(".");
                if (a[1].length == 1) {
                    a[1] = a[1] + "0";
                }
                else {
                    a[1] = a[1].slice(0, 2);
                }
                code = a.join(".");
            }

            if (isShort) {
                code = this.num2short(num, isShort);
            }

            var data = code.split(".");
            var integer = data[0];
            var tailData: string = data[1];

            let DecimalPoint = ".";//小数点
            let Semicolon = ",";//分隔号

            // switch(LanguageConstTypes.AmountType)
            // {
            //     case 0:
            //         DecimalPoint = ".";
            //         Semicolon = ",";
            //         break;
            //     case 1:
            //         DecimalPoint = ",";
            //         Semicolon = ".";
            //         break;
            // }

            if (tailData) {
                if (tailData.length == 2 && tailData[1] == "0") {
                    tailData = tailData.substr(0, 1);
                    decimal = DecimalPoint + tailData;
                }
                else if (tailData.length == 2 && tailData[0] == "0" && tailData[1] == "0") {
                    tailData = "";
                    decimal = "";
                }
                else {
                    decimal = DecimalPoint + tailData;
                }
            }

            let result = integer.replace(/\B(?=(?:\d{3})+$)/g, Semicolon) + decimal;

            return preFix + result;
        }
        /**
         * 1000-->K
           1000 000-->M
           1 000 000 000-->B
           1 000 000 000 000-->T
         */
        public static num2short(value: number, type: number): string {
            let num = 0;
            let result = "";
            let suffix = "";
            let mini = 1000;
            if (type == 2) {
                mini = 1000;
            }

            if (value >= mini && value < 1000000)//1k--999k
            {
                num = value / 1000;
                suffix = "K";
            }
            else {
                num = value;
            }

            result = num.toString();
            let actNum = 4;

            if (result.indexOf(".") > -1 && suffix == "")//包含小数
            {
                actNum = 5;
            }
            if (result.length > actNum) {
                if (type == 1)//自定义筹码需要缩减显示位数
                {
                    result = result.slice(0, actNum);
                }
            }
            let bNum = parseFloat(result);//小数点后保留两位
            // let rNum = (Math.floor(bNum * 100))/100;
            //小数点后只显示一位小数
            if (type == 2 || type == 3) {
                bNum = (Math.floor(bNum * 10)) / 10;
            }
            else {
                if (suffix != "") {
                    bNum = Math.floor(bNum);//策划要求去掉小数
                }
            }

            return bNum + suffix;
        }


        /**返回经过处理的整十数
         * param 含一位小数字符
        */
        public static stringToNumber(str: string): number {
            let txt: string = str;
            let num: number;
            num = Number(txt);
            num.toFixed(1);
            num *= 10;
            num.toFixed(0);
            num *= 10;

            return num;
        }
        /**返回经过精度处理的2位小数,如果这个2位小数的末位是0，会省去0*/
        public static getCheckedNumber(n: number): number {
            var n0 = parseInt(n.toFixed(0));
            var n1 = parseFloat(n.toFixed(1));
            var n2 = parseFloat(n.toFixed(2));

            if (n2 == n1) {
                if (n1 == n0) {
                    return n0;
                }
                else {
                    return n1;
                }
            }
            else {
                return n2;
            }

        }

        /** 1-10数字转换成文字 */
        public static numberToBeString(num: number) {
            let str: string;
            switch (num) {
                case 1:
                    str = '一';
                    break;
                case 2:
                    str = '二';
                    break;
                case 3:
                    str = '三';
                    break;
                case 4:
                    str = '四';
                    break;
                case 5:
                    str = '五';
                    break;
                case 6:
                    str = '六';
                    break;
                case 7:
                    str = '七';
                    break;
                case 8:
                    str = '八';
                    break;
                case 9:
                    str = '九';
                    break;
                case 0:
                case 10:
                    str = '十';
                    break;
            }
            return str;
        }
    }
}
