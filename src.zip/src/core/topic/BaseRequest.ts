module topic
{
	/**基础请求类 */
	export class BaseRequest
	{
		
	}


}