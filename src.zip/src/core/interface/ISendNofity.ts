interface ISendNofity {
	/** 发送全局通知 */
	sendNotification(type: UiNotifyConst, body?: any): void;
}