module game{
	export class LayerManager {
		private static _instance:LayerManager;
		/** 登录层 */
		private loginGroup:eui.Group;
		/** 加载层 */
		private loadGroup:eui.Group;
		/** 主页层 */
		private mainGroup: eui.Group;
		/** 系统层 */
		private sysGroup: eui.Group;
		public constructor() {
		}
		public static getInstance():LayerManager{
			if(!this._instance) this._instance = new LayerManager();
			return this._instance;
		}

		/** 初始化管理器 */
		public initLayer(){
			this.loginGroup = new eui.Group();
			this.loadGroup = new eui.Group();
			this.mainGroup = new eui.Group();
			this.sysGroup = new eui.Group();
			this.sysGroup.touchThrough = true;
			StageUtil.stage.addChild(this.mainGroup);
			StageUtil.stage.addChild(this.loginGroup);
			StageUtil.stage.addChild(this.sysGroup);
			StageUtil.stage.addChild(this.loadGroup);
		}

		public addUI(ui, layer:LayerConst = LayerConst.Layer_UI){
			switch(layer){
				case LayerConst.Layer_UI:
					this.mainGroup.addChild(ui);
					break;
				case LayerConst.Layer_Sys:
					this.sysGroup.addChild(ui);
					break;
				case LayerConst.Layer_Load:
					this.loadGroup.addChild(ui);
					break;
				case LayerConst.Layer_Login:
					this.loginGroup.addChild(ui);
					break;
			}
		}

		public clear(){
			this.mainGroup.removeChildren();
		}
	}

	export class LayerConst{
		public static Layer_UI: number = 1;
		public static Layer_Sys: number = 2;
		public static Layer_Load: number = 3;
		public static Layer_Login: number = 4;
	}
}