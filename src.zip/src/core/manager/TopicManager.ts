module game {
    export class TopicManager {
        private static instance: TopicManager;
        public static getInstance(): TopicManager {
            if (this.instance == null) {
                this.instance = new TopicManager();
            }
            return this.instance;
        }

        /**发请求的seq和topic的字典 */
        private _requestPool: Dictionary;
        /**游戏socket */
        private gameSocket: GameSocket;
        /**当前seq 累加 */
        private _sequences: number;
        /**存放原始的snapshot，key:topic, value:BaseResponse*/
        private snapshotDic: Dictionary;
        /**发送请求的回调字典 */
        private _seqCallback: Dictionary;
        /**注册topic监听的字典 */
        private _topicListeners: Dictionary;
        /** 暂存当前房间号 */
        private roomID: any;

        public constructor() {
            this._requestPool = new Dictionary();
            this.gameSocket = new GameSocket();
            this.snapshotDic = new Dictionary();
            this._seqCallback = new Dictionary();
            this._topicListeners = new Dictionary();
            this._sequences = 1;
        }


        /**连接游戏socket */
        public connect(host: string, callback: Function, callbackobj: any, errCallback: Function): void {
            console.warn("连接socket==========", host);
            // this.gameSocket.connect(host,port,callback, callbackobj, errCallback);
            this.gameSocket.connectByUrl(host, callback, callbackobj, errCallback);
        }
        public disconnect(): void {
            this.gameSocket.disconnect();
        }
        /**登陆游戏 */
        public loginGame(msg: string) {
            this.sendCMD(msg);
        }
		/**
         * 添加协议监听
         */
        public addSocketListener(topic: string, callBack: Function, thisObject: any): void {
            this._topicListeners.setValue(topic, new RequestHandler(callBack, thisObject));
        }
		/**
         * 移除协议监听
         */
        public removeSocketListener(topic: string): void {
            this._topicListeners.removeKey(topic);
        }
        /**收到服务器数据 准备处理 */
        public onDataIn(message: any) {
            //返回有错误的话，直接执行回调 不继续派发消息
            this.handleData(message);
        }

        /** 客户端主动断开socket */
        public closeSocket() {
            this.gameSocket.disconnect();
        }

        /**处理数据 */
        private handleData(json: any) {
            // console.log("收到的服务器socket数据", json);
        }
        /**寻找此消息的seq是否注册过回调 并执行回调 */
        private checkSeqCallback(resp: topic.BaseResponse) {
            let callbacker = this._seqCallback.getValue(resp.seq);
            if (callbacker) {
                this._seqCallback.removeKey(resp.seq);
                callbacker.callBack.call(callbacker.thisObject, resp);
            }
        }

		/**
		 * 发送协议
		 */
        public sendCMD(message: string): void {
            this.gameSocket.sendCMD(message);
        }
    }
}