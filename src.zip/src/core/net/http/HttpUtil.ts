module game{
	/**
	 * @desc 处理一些http请求的类
	 */
	export class HttpUtil {
		/**
		 * 发送http请求
		 */

		public static sendRequest(method: string = "GET", url: string, successCallBack: Function = null, thisObject: any = null, errorCallback: Function = null, sendData: any = ""): void {
			var httpItem: HttpItem = new HttpItem(url, sendData, successCallBack, errorCallback, thisObject, method);
			httpItem.load();
		}

		public sendPostRequest() {

			// var request = new egret.HttpRequest();
			// request.responseType = egret.HttpResponseType.TEXT;
			// request.open("http://gapi.vzboo.net/Home/api/winLoseRecord?gameid=6&wid=1", egret.HttpMethod.POST);
			// request.send();

			// request.addEventListener(egret.Event.COMPLETE, this.onPostComplete, this);
			// request.addEventListener(egret.IOErrorEvent.IO_ERROR, this.onPostIOError, this);
			// request.addEventListener(egret.ProgressEvent.PROGRESS, this.onPostProgress, this);
		}

		private onPostComplete(event: egret.Event): void {
			var request = <egret.HttpRequest>event.currentTarget;
			egret.log("post data : ", request.response);
		}

		private onPostIOError(event: egret.IOErrorEvent): void {
			egret.log("post error : " + event);
		}

		private onPostProgress(event: egret.ProgressEvent): void {
			egret.log("post progress : " + Math.floor(100 * event.bytesLoaded / event.bytesTotal) + "%");
		}

	}
}
