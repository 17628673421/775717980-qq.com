module game{
	/**
	 * @desc 单个http请求
	 */
    export class HttpItem {
        private xhr: XMLHttpRequest;
        private url: string;
        private successCallBack: Function;
        private errorCallback: Function;
        private thisObject: any;
        private needTip: boolean = true;
        private isload = false;

        private sendData: string;
        private method: string;
        private timeOutId: any;

        public constructor(url, sendData: any = null, successCallBack: Function, errorCallback: Function, thisObject: any, method: string = "GET") {
            this.url = url;
            this.sendData = sendData;
            this.thisObject = thisObject;
            this.errorCallback = errorCallback;
            this.successCallBack = successCallBack;
            this.method = method;
            this.xhr = new XMLHttpRequest();
        }

        public load(): void {
            this.xhr.open(this.method, this.url, true);
            this.xhr.onreadystatechange = () => {
                if (this.xhr.readyState == 4) {
                    if (this.needTip && this.timeOutId) {
                        clearTimeout(this.timeOutId);
                        this.timeOutId = null;
                    }
                    this.isload = true;
                    let txt = this.xhr.responseText;
                    switch (this.xhr.status) {
                        case 200:
                        case 201:
                        case 204:
                            if (this.successCallBack && this.thisObject) {
                                this.successCallBack.call(this.thisObject, txt);
                            }
                            break;
                        default:
                            if (this.errorCallback && this.thisObject) {
                                this.errorCallback.call(this.thisObject, txt);
                            }
                            break;
                    }
                }

            };
            this.xhr.onerror = (err) => {
                this.abnormal();
            };
            if (this.sendData) this.xhr.send(this.sendData);
            else this.xhr.send();

            if (this.needTip) {
                this.timeOutId = setTimeout(this.ioError.bind(this), 10000);  
            }
        }
        /**
         * io网络超时
         */
        private ioError(): void {
            if (this.timeOutId) clearTimeout(this.timeOutId);
            this.timeOutId = null;
            if (!this.isload && this.needTip) {
                //提示网络超时吗
                this.abnormal();
            }
            this.xhr.abort();
        }
        /**提示网络异常*/
        private abnormal():void{
			NotifyManager.getInstance().distribute(NotifyConst.connectError, "lbl_network_error");
        }
    }
}
