module game {
	export class GameSocket {
		private socket: egret.WebSocket;
		private successCallback: Function;
		private successCallbackObj: any;
		private errCallback: Function;
		/**主动断开 */
		private isCloseBySelf: boolean;
		public constructor() {
			this.socket = new egret.WebSocket();
			this.socket.type = egret.WebSocket.TYPE_STRING;
			this.socket.addEventListener(egret.Event.CONNECT, this.onSocketConnected, this);
			this.socket.addEventListener(egret.Event.CLOSE, this.onSocketClose, this);
			this.socket.addEventListener(egret.ProgressEvent.SOCKET_DATA, this.onDataIn, this);
			this.socket.addEventListener(egret.IOErrorEvent.IO_ERROR, this.onIoError, this);
		}

		public connect(host: string, port: number, callback: Function, callbackobj: any, errCallback: Function) {
			this.successCallback = callback;
			this.successCallbackObj = callbackobj;
			this.errCallback = errCallback;
			this.socket.connect(host, port);
		}
		public connectByUrl(url: string, callback: Function, callbackobj: any, errCallback: Function) {
			// console.log("socket connectByUrl:" + url);
			this.successCallback = callback;
			this.successCallbackObj = callbackobj;
			this.errCallback = errCallback;
			this.socket.connectByUrl(url);
		}
		public disconnect(): void {
			this.isCloseBySelf = true;
			this.socket.close();
			console.log("客户端主动断开socket！");
		}
		/**
		 * 当socket连接上
		 */
		private onSocketConnected(evt: egret.Event): void {
			this.isCloseBySelf = false;
			if (this.successCallback && this.successCallbackObj) {
				this.successCallback.call(this.successCallbackObj);
			}
		}
		/**
		 * 当socket关闭了
		 */
		private onSocketClose(evt: egret.Event): void {
			console.warn("socket断开了~！");
			NotifyManager.getInstance().distribute(NotifyConst.connectError, "lbl_network_error");
		}
        /**
         * 当发生IO错误
         */
		private onIoError(evt: egret.IOErrorEvent): void {
			// DebugUtil.release('socket IO错误');
			NotifyManager.getInstance().distribute(NotifyConst.connectError, "lbl_network_error");
		}
		/**
         * 接收数据返回
         */
		private onDataIn(evt: egret.ProgressEvent): void {
			if (this.socket) {
				let str = this.socket.readUTF();
				// DebugUtil.debug("received data:"+str);
				// let decodestr = Main.decryptByDES(str,GlobalConfig.desKey);
				// if(decodestr.length == 0){
				// 	decodestr = str;
				// }
				// console.log("received data:" + str);
				let message = JSON.parse(str);
				TopicManager.getInstance().onDataIn(message);
			}
		}
        /**
         * 发送数据到服务器
         */
		public sendCMD(str: string): void {
			if (this.socket && this.socket.connected) {
				// str = Main.encryptByDES(str,GlobalConfig.desKey);
				// DebugUtil.debug(str, LogConst.LOGTYPE_MSG_FIRED);
				this.socket.writeUTF(str);
				this.socket.flush();
			}
		}
	}


}