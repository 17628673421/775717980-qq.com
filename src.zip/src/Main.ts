//////////////////////////////////////////////////////////////////////////////////////
//
//  Copyright (c) 2014-present, Egret Technology.
//  All rights reserved.
//  Redistribution and use in source and binary forms, with or without
//  modification, are permitted provided that the following conditions are met:
//
//     * Redistributions of source code must retain the above copyright
//       notice, this list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above copyright
//       notice, this list of conditions and the following disclaimer in the
//       documentation and/or other materials provided with the distribution.
//     * Neither the name of the Egret nor the
//       names of its contributors may be used to endorse or promote products
//       derived from this software without specific prior written permission.
//
//  THIS SOFTWARE IS PROVIDED BY EGRET AND CONTRIBUTORS "AS IS" AND ANY EXPRESS
//  OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
//  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
//  IN NO EVENT SHALL EGRET AND CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
//  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
//  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;LOSS OF USE, DATA,
//  OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
//  LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
//  NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
//  EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
//////////////////////////////////////////////////////////////////////////////////////
class Main extends eui.UILayer {


    protected createChildren(): void {
        super.createChildren();

        // egret.lifecycle.addLifecycleListener((context) => {
        //     // custom lifecycle plugin
        // })

        // egret.lifecycle.onPause = () => {
        //     egret.ticker.pause();
        // }

        // egret.lifecycle.onResume = () => {
        //     egret.ticker.resume();
        // }

        //inject the custom material parser
        //注入自定义的素材解析器
        let assetAdapter = new AssetAdapter();
        egret.registerImplementation("eui.IAssetAdapter", assetAdapter);
        egret.registerImplementation("eui.IThemeAdapter", new ThemeAdapter());
        this.runGame().catch(e => {
            console.log(e);
        })
        game.StageUtil.stage = this.stage;
        game.LayerManager.getInstance().initLayer();

    }

    private async runGame() {
        await this.loadResource()
    }

    private async loadResource() {
        try {
            let loadingView: LoadingUI;
            await RES.loadConfig("resource/default.res.json", "resource");
             //await RES.loadConfig("https://zt.cdbandou.cn/d1/default.res.json", "https://zt.cdbandou.cn/d1");
            // await this.loadTheme();
            await this.loadTheme()
            await RES.loadGroup("loading").then(()=>{
                loadingView = new LoadingUI();
                this.stage.addChild(loadingView);
            });
            await RES.loadGroup("preload",0,loadingView).then(()=>{
                this.stage.removeChild(loadingView);
            });
            this.userInfoHandler();
            // await RES.loadGroup("loading", 0).then(() => {
            //     loadingView = new LoadingUI();
            //     this.stage.addChild(loadingView);
            // });
            // await RES.loadGroup("preload", 0, loadingView).then(() => {
            //     this.userInfoHandler().then(() => {
            //         setTimeout(() => {
            //             loadingView.close();
            //             this.stage.removeChild(loadingView);
            this.createGameScene();
            //         }, 500);
            //     })
            // });
        }
        catch (e) {
            console.error(e);
        }
        this.removeChildren();
    }

    /** 微信用户信息处理 */
    private userInfoHandler(){
        let info: WXManager = WXManager.getInstance();
         platform.authorizeJurisdiction().then(() => {
                console.log("已经授权，正在获取用户信息...");
                platform.getUserInfo().then((data) => {
                    console.log("获取用户信息成功--授权过", data);
                    info.nickName = data.userInfo.nickName;
                    info.avatarUrl = data.userInfo.avatarUrl;
                    info.gender = data.userInfo.gender;
                    info.city = data.userInfo.city;
                    info.province = data.userInfo.province;
                    info.country = data.userInfo.country;
                }).catch(() => {
                    console.log("获取用户信息失败...")
                });
            }).catch(() => {
                platform.getUserInfoByButton().then((data) => {
                    console.log("获取用户信息成功--第一次授权", data);
                    info.nickName = data.userInfo.nickName;
                    info.avatarUrl = data.userInfo.avatarUrl;
                    info.gender = data.userInfo.gender;
                    info.city = data.userInfo.city;
                    info.province = data.userInfo.province;
                    info.country = data.userInfo.country;
                }).catch(() => {
                    console.log("获取用户信息失败...")
                });
            })
        // return new Promise(async (resolve, reject) => {
        //     platform.createBannerAd1();
        //     let login: boolean = false;
        //     let info: WXManager = WXManager.getInstance();
        //     platform.showShareMenu();
        //     console.log("资源加载完毕，进行登录操作...");
        //     let incode: any;
        //     await platform.getLaunchOptionsSync().then((info) => {
        //         console.log("返回的消息", info);
        //     });
        //     await platform.login(incode).then((jsonData) => {
        //         let js = jsonData.req.data;//RES.ResourceItem.TYPE_JSON(data.req.data.msg_data);
        //         console.log("登录成功，获取到用户的code以及openid：", jsonData);
        //         console.log("正在查询用户是否授权用户信息...");
        //         info.openId = js.openid;
        //         info.session_key = js.session_key;
        //         console.log("info.openId" + info.openId);
        //         // info.session_key = data.req.data.session_key;
        //         console.log("WXUserInfo.appId" + WXManager.appId);
        //         console.log("WXUserInfo.secret" + WXManager.secret);
        //         login = true;
        //     });
        //     await platform.authorizeJurisdiction().then(() => {
        //         console.log("已经授权，正在获取用户信息...");
        //         platform.getUserInfo().then((data) => {
        //             console.log("获取用户信息成功--授权过", data);
        //             info.nickName = data.userInfo.nickName;
        //             info.avatarUrl = data.userInfo.avatarUrl;
        //             info.gender = data.userInfo.gender;
        //             info.city = data.userInfo.city;
        //             info.province = data.userInfo.province;
        //             info.country = data.userInfo.country;
        //         }).catch(() => {
        //             console.log("获取用户信息失败...")
        //         });
        //     }).catch(() => {
        //         platform.getUserInfoByButton().then((data) => {
        //             console.log("获取用户信息成功--第一次授权", data);
        //             info.nickName = data.userInfo.nickName;
        //             info.avatarUrl = data.userInfo.avatarUrl;
        //             info.gender = data.userInfo.gender;
        //             info.city = data.userInfo.city;
        //             info.province = data.userInfo.province;
        //             info.country = data.userInfo.country;
        //         }).catch(() => {
        //             console.log("获取用户信息失败...")
        //         });
        //     })
        //     if (login) {
        //         resolve();
        //     }
        // })
    }

    private loadTheme() {
        return new Promise((resolve, reject) => {
            // load skin theme configuration file, you can manually modify the file. And replace the default skin.
            //加载皮肤主题配置文件,可以手动修改这个文件。替换默认皮肤。
            let theme = new eui.Theme("resource/default.thm.json", this.stage);
            theme.addEventListener(eui.UIEvent.COMPLETE, () => {
                resolve();
            }, this);
        })
    }

    /** 创建游戏场景 */
    private createGameScene() {
        let model: game.Model = game.Model.getInstance();
        let wx:WXManager = WXManager.getInstance();
        this.stage.maxTouches = 2;
        window["game"] = game;
        let scaleX:number = this.stage.stageWidth/1080;
        let scaleY:number = this.stage.stageHeight/1920;
        if(scaleY > 1){
            scaleY = 1920/this.stage.stageHeight;
        }
        if(scaleX < 1){
            scaleY = 1-(scaleY-1);
        }
        console.log("屏幕宽高",this.stage.stageWidth,this.stage.stageHeight,scaleX,scaleY,egret.Capabilities.boundingClientWidth,egret.Capabilities.boundingClientHeight);
        model.scaleX = scaleX;
        model.scaleY = scaleY;
        egret.ImageLoader.crossOrigin = "anonymous";
        game.Controller.getInstance().start();
        // platform.createBannerAd1().then((ad)=>{
        //     wx.overBanner = ad;
        // });
        // platform.createBannerAd2();
        // platform.createBannerAd2().then((ad)=>{
        //     wx.scenceBanner = ad;
        // });
        // platform.createRewardedVideoAd().then((ad)=>{
        //     wx.videoBanner = ad;
        // });
    }
}
