module game {
	/** 游戏场景类 */
	export class GameUI extends BaseUI {
		public constructor() {
			super();
			this.skinName = "resource/skins/GameUISkin.exml";
		}

		/** 是否第一次进游戏 */
		private isFirst:boolean;
		/** 适配组 */
		private adaptation: eui.Group;
		/** 开始组 */
		private grp_start: eui.Group;
		/** 游戏组 */
		private grp_game: eui.Group;
		/** 返回按钮 */
		private grp_game_back: eui.Group;
		/** 游戏场景遮罩 */
		private rect_mask: eui.Rect;
		/** 游戏场景组 */
		private grp_scence: eui.Group;
		/** 上一次差值 */
		private oldValue: number;
		/** 触碰结束点0 */
		private touchMovePoint0: egret.Point;
		/** 触碰结束点1 */
		private touchMovePoint1: egret.Point;
		/** 是否为双手触摸 */
		private isBothHands: boolean;
		/** 上次移动的X坐标 */
		private lastMoveX: number;
		/** 上次移动的Y坐标 */
		private lastMoveY: number;
		/** 确认按钮组 */
		private grp_sure: eui.Group;
		/** 确认文字 */
		private lab_sure: eui.Label;
		/** 确认图片 */
		private img_sure: eui.Image;
		/** 确认点图 */
		private img_target: eui.Image;
		/** 目标动画 */
		private targetTween:egret.MovieClip;
		/** 场景图 */
		private img_scence:eui.Image;
		/** 线索组 */
		private grp_clue:eui.Group;
		/** 会话名称 */
		private lab_section:eui.Label;
		/** 问题 */
		private lab_question:eui.Label;
		/** 关闭按钮 */
		private grp_close:eui.Group;
		/** 答案X坐标 */
		private answerX:number;
		/** 答案X坐标 */
		private answerY:number;
		/** 答案W宽度 */
		private answerW:number;
		/** 答案H高度 */
		private answerH:number;
		/** 结果组 */
		private grp_result:eui.Group;
		/** 结果组关闭按钮 */
		private grp_result_close:eui.Group;
		/** 结束组 */
		private grp_over:eui.Group;
		/** 结束界面提示语 */
		private lab_over:eui.Label;
		/** 再次推理按钮 */
		private grp_over_close:eui.Group;
		/** 选择关卡按钮 */
		private grp_over_choose:eui.Group;
		/** 看答案按钮 */
		private grp_over_answer:eui.Group;	
		/** 日记按钮 */
		private grp_game_plot:eui.Group;
		/** 日记组 */
		private grp_diary:eui.Group;
		/** 日记内容 */
		private lab_diary:eui.Label;
		/** 关闭日记按钮 */
		private grp_diary_close:eui.Label;
		/** 视频组 */
		private grp_video:eui.Group;
		/** 观看视频 */
		private grp_video_look:eui.Group;
		/** 关闭视频窗口 */
		private grp_video_close:eui.Group;
		/** 提示按钮 */
		private grp_game_tips:eui.Group;
		/** 线索按钮 */
		private grp_game_clue:eui.Group;
		/** 设置按钮 */
		private grp_setting:eui.Group;
		/** 设置组 */
		private grp_set:eui.Group;
		/** 音效按钮 */
		private grp_sound:eui.Group;
		/** 音效图片 */
		private img_sound:eui.Image;
		/** 音效组关闭按钮 */
		private grp_set_close:eui.Group;
		/** 关卡组 */
		private grp_check:eui.Group;
		/** 系列列表 */
		private list_series:eui.List;
		/** 关卡组返回按钮 */
		private grp_check_back:eui.Group;
		/** 破案数 */
		private lab_num:eui.Label;
		/** 会话组 */
		private grp_section:eui.Group;
		/** 系列滑动容器 */
		private sco_series:eui.Scroller;
		/** 关卡组 */
		private grp_stage:eui.Group;
		/** 关卡组关闭图片 */
		private img_stage_close:eui.Image;
		/** 关卡滑动容器 */
		private sco_stage:eui.Scroller;
		/** 关卡列表 */
		private list_stage:eui.List;
		/** 结果文字 */
		private lab_result:eui.Label;
		/** 继续组 */
		private grp_goon:eui.Group;
		/** 答案图片 */
		private img_answer:eui.Image;
		/** 解说文字 */
		private lab_explain:eui.Label;
		/** 继续组选择关卡按钮 */
		private grp_goon_choose:eui.Group;
		/** 继续组下一关按钮 */
		private grp_goon_next:eui.Group;
		/** 是否显示标题组 */
		private isShowTitle:boolean;
		/** 标题组 */
		private grp_titile:eui.Group;
		/** 标题id */
		private lab_title_id:eui.Label;
		/** 标题名称 */
		private lab_title_name:eui.Label;
		/** 是否观看了广告 */
		private isVideo:boolean;
		/** 提示组 */
		private grp_tips:eui.Group;
		/** 提示文字 */
		private lab_tips:eui.Label;
		/** 提示组关闭按钮 */
		private grp_tips_close:eui.Group;
		/** 头部按钮组 */
		private grp_gane_head:eui.Group;
		/** 场景背景组 */
		private grp_game_bg:eui.Group;
		/** 提示框组 */
		private grp_tip:eui.Group;
		/** 提示文字 */
		private lab_tip:eui.Label;

		/** 初始化操作 */
		protected initUI() {
			this.initAdaptation();
			this.initView();
			this.addStartMenuEventList();
		}

		/** 适配处理 */
		private initAdaptation() {
			Tool.setDisObjAdaptation(this.adaptation);
		}

		/** 添加开始菜单监听 */
		private addStartMenuEventList() {
			this.grp_start.addEventListener(egret.TouchEvent.TOUCH_TAP, this.startGame, this);
		}

		/** 移除开始菜单监听 */
		private removeStartMenuEventList() {
			this.grp_start.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.startGame, this);
		}

		/** 初始化界面 */
		private initView() {
			RES.loadGroup("sound").then(()=>{
				SoundPlayer.openSound(true);
				SoundPlayer.playMusic(SoundConst.bg);
            });
			this.grp_tip.visible = false;
			this.grp_tip.alpha = 0;
			this.isFirst = true;
			this.isShowTitle = false;
			this.sco_series.bounces = false;
			this.sco_stage.bounces = false;
			this.grp_start.visible = true;
			this.grp_game.visible = false;
			this.grp_result.visible = false;
			this.grp_diary.visible = false;
			this.isVideo = false;
			this.grp_over.visible = false;
			this.grp_video.visible = false;
			this.grp_set.visible = false;
			this.grp_check.visible = false;
			this.grp_section.visible = false;
			this.grp_goon.visible = false;
			this.grp_tips.visible = false;
			this.grp_stage.visible = false;
			this.list_stage.itemRenderer = StageItem;
			this.grp_scence.mask = this.rect_mask;
			this.touchMovePoint0 = new egret.Point(0, 0);
			this.touchMovePoint1 = new egret.Point(0, 0);
			this.isBothHands = false;
			this.oldValue = 0;
			this.lastMoveX = 0;
			this.lastMoveY = 0;
			this.img_target.visible = false;
			this.grp_sure.visible = false;
			this.targetTween = Tool.preLoadingFrameAnimation("click_json","click_png","click");
			this.sendNotification(UiNotifyConst.initStage);
			this.grp_clue.visible = false;
			this.img_target.width = this.img_target.height = GlobalConfig.diameter;
			this.img_target.anchorOffsetX = this.img_target.width/2;
			this.img_target.anchorOffsetY = this.img_target.height*Model.getInstance().scaleY/2;
			this.grp_gane_head.y = this.grp_game_bg.y;
			// this.rect_mask.width = this.grp_scence.width;
			// this.rect_mask.height = this.grp_scence.height;
			this.grp_scence.anchorOffsetY = this.grp_scence.height *  Model.getInstance().scaleY/2;
			this.grp_scence.x = this.width/2;
			this.grp_scence.y = this.height/2-100;
		}

		/** 接收Controller的控制命令*/
		public onControllerCommand(type: UiCommand, params: any = null): void {
			switch (type) {
				case UiCommand.createScence:
					this.createScence(params);
					break;
				case UiCommand.showDiary:
					this.showDiary(params);
					break;
				case UiCommand.initSeriesList:
					this.initSeriesList(params);
					break;
				case UiCommand.updateCheckNum:
					this.updateCheckNum(params);
					break;
				case UiCommand.showSectionList:
					this.showSectionList(params);
					break;
				case UiCommand.showStageList:
					this.showStageList(params);
					break;
				case UiCommand.initAnswer:
					this.initAnswer(params);
					break;
				case UiCommand.gameClearance:
					this.gameClearance();
					break;
				case UiCommand.showTip:
					this.showTips(params);
					break;
			}
		}

		/** 开始游戏 */
		private startGame() {
			platform.createBannerAd2();
			this.grp_start.visible = false;
			this.grp_game.visible = true;
			this.grp_clue.visible = true;
			this.removeStartMenuEventList();
			this.addGameScenceEventList();
			this.restScence();
			this.isFirst = false;
		}

		/** 游戏通关 */
		private gameClearance(){
			this.grp_result.visible = true;
			this.lab_result.text = "全部完成";
			this.grp_result_close.addEventListener(egret.TouchEvent.TOUCH_TAP,this.showCheckView,this);
		}


		/** 添加游戏场景内监听 */
		private addGameScenceEventList() {
			this.addEventListener(egret.TouchEvent.TOUCH_BEGIN, this.touchBeginScenceHandler, this);
			this.addEventListener(egret.TouchEvent.TOUCH_END, this.touchEndScenceHandler, this);
			this.addEventListener(egret.TouchEvent.TOUCH_MOVE, this.touchMoveScenceHandler, this);
			this.grp_scence.addEventListener(egret.TouchEvent.TOUCH_TAP, this.touchTapScencrHandler, this);
			this.grp_sure.addEventListener(egret.TouchEvent.TOUCH_TAP,this.inspect,this);
			this.grp_close.addEventListener(egret.TouchEvent.TOUCH_TAP,this.closeSection,this);
			this.grp_game_plot.addEventListener(egret.TouchEvent.TOUCH_TAP,this.getDiary,this);
			this.grp_diary_close.addEventListener(egret.TouchEvent.TOUCH_TAP,this.closeDiary,this);
			this.grp_video_close.addEventListener(egret.TouchEvent.TOUCH_TAP,this.closeVideo,this);
			this.grp_game_tips.addEventListener(egret.TouchEvent.TOUCH_TAP,this.showVideo,this);
			this.grp_game_clue.addEventListener(egret.TouchEvent.TOUCH_TAP,this.showClue,this);
			this.grp_setting.addEventListener(egret.TouchEvent.TOUCH_TAP,this.showSetting,this);
			this.grp_set_close.addEventListener(egret.TouchEvent.TOUCH_TAP,this.closeSet,this);
			this.grp_sound.addEventListener(egret.TouchEvent.TOUCH_TAP,this.isOpenSound,this);
			this.grp_game_back.addEventListener(egret.TouchEvent.TOUCH_TAP,this.closeScence,this);
			this.grp_video_look.addEventListener(egret.TouchEvent.TOUCH_TAP,this.playVideo,this);
			this.grp_tips_close.addEventListener(egret.TouchEvent.TOUCH_TAP,this.closeTips,this);
		}

		/** 移除游戏场景内监听 */
		private removeGameScenceEventList() {
			this.removeEventListener(egret.TouchEvent.TOUCH_BEGIN, this.touchBeginScenceHandler, this);
			this.removeEventListener(egret.TouchEvent.TOUCH_END, this.touchEndScenceHandler, this);
			this.removeEventListener(egret.TouchEvent.TOUCH_MOVE, this.touchMoveScenceHandler, this);
			this.grp_scence.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.touchTapScencrHandler, this);
			this.grp_sure.removeEventListener(egret.TouchEvent.TOUCH_TAP,this.inspect,this);
			this.grp_close.removeEventListener(egret.TouchEvent.TOUCH_TAP,this.closeSection,this);
			this.grp_game_plot.removeEventListener(egret.TouchEvent.TOUCH_TAP,this.getDiary,this);
			this.grp_diary_close.removeEventListener(egret.TouchEvent.TOUCH_TAP,this.closeDiary,this);
			this.grp_video_close.removeEventListener(egret.TouchEvent.TOUCH_TAP,this.closeVideo,this);
			this.grp_game_tips.removeEventListener(egret.TouchEvent.TOUCH_TAP,this.showVideo,this);
			this.grp_game_clue.removeEventListener(egret.TouchEvent.TOUCH_TAP,this.showClue,this);
			this.grp_setting.removeEventListener(egret.TouchEvent.TOUCH_TAP,this.showSetting,this);
			this.grp_set_close.removeEventListener(egret.TouchEvent.TOUCH_TAP,this.closeSet,this);
			this.grp_sound.removeEventListener(egret.TouchEvent.TOUCH_TAP,this.isOpenSound,this);
			this.grp_game_back.removeEventListener(egret.TouchEvent.TOUCH_TAP,this.closeScence,this);
			this.grp_video_look.removeEventListener(egret.TouchEvent.TOUCH_TAP,this.playVideo,this);
			this.grp_tips_close.removeEventListener(egret.TouchEvent.TOUCH_TAP,this.closeTips,this);
		}

		/** 关闭提示组 */
		private closeTips(){
			SoundPlayer.playSoundWav(SoundConst.click);
			this.grp_tips.visible = false;
		}

		/** 场景内触摸开始处理 */
		private touchBeginScenceHandler(evt: egret.TouchEvent) {
			this.lastMoveX = evt.stageX;
			this.lastMoveY = evt.stageY;
		}

		/** 场景内触摸结束处理 */
		private touchEndScenceHandler(evt: egret.TouchEvent) {
			this.isBothHands = false;
			this.oldValue = 0;
			this.touchMovePoint0.x = 0;
			this.touchMovePoint0.y = 0;
			this.touchMovePoint1.x = 0;
			this.touchMovePoint1.y = 0;
			this.lastMoveX = 0;
			this.lastMoveY = 0;
		}

		/** 场景内触摸发生时处理 */
		private touchMoveScenceHandler(evt: egret.TouchEvent) {
			let x: number = evt.stageX;
			let y: number = evt.stageY;
			let scence: eui.Group = this.grp_scence;
			if (evt.touchPointID == 0) {
				this.touchMovePoint0.x = x;
				this.touchMovePoint0.y = y;
			} else {
				this.isBothHands = true;
				this.touchMovePoint1.x = x;
				this.touchMovePoint1.y = y;
			}
			if (this.isBothHands) {
				let value: number = egret.Point.distance(this.touchMovePoint0,this.touchMovePoint1);
				if (Math.abs(this.oldValue - value) > 2) {
					if (value > this.oldValue) {
						if (scence.scaleX < 2) {
							scence.scaleX += 0.1;
							scence.scaleY += 0.1;
						}
					} else if (value < this.oldValue) {
						if (scence.scaleX > 1) {
							scence.scaleX -= 0.1;
							scence.scaleY -= 0.1;
							let speedX: number = 50;
							let speedY: number = 78;
							let numB: number = (scence.x - 540);
							let numC: number = (scence.y - 960);
							if (numB < 0) {
								scence.x + speedX >= 540 ? scence.x = 540 : scence.x += speedX;
							} else if (numB > 0) {
								scence.x - speedX <= 540 ? scence.x = 540 : scence.x -= speedX;
							}
							if (numC < 0) {
								scence.y + speedY >= 960 ? scence.y = 960 : scence.y += speedY;
							} else if (numC > 0) {
								scence.y - speedY <= 960 ? scence.y = 960 : scence.y -= speedY;
							}
						}
					}
					this.oldValue = value;
				}
			} else {
				if (scence.scaleX) {
					let valueX: number = x - this.lastMoveX;
					let valueY: number = y - this.lastMoveY;
					let valueWidth: number = scence.width * scence.scaleX / 2 + 36 - 540;
					let valueHeight: number = scence.height * scence.scaleY / 2 + 288 - 960;
					if (scence.x + valueX >= 540 - valueWidth && scence.x + valueX <= 540 + valueWidth) {
						scence.x += valueX;
					}
					if (scence.y + valueY >= 960 - valueHeight && scence.y + valueY <= 960 + valueHeight) {
						scence.y += valueY;
					}
					this.lastMoveX = x;
					this.lastMoveY = y;
				}
			}
		}

		/** 设置确认按钮状态 */
		private setSureState(type: number) {
			let grp: eui.Group = this.grp_sure;
			let txt: eui.Label = this.lab_sure;
			let target: eui.Image = this.img_target;
			let distance: number = target.width * target.scaleY / 2 + 10;
			grp.x = target.x;
			switch (type) {
				case 0://点在左上角
					grp.scaleX = Math.abs(grp.scaleX);
					txt.scaleX = Math.abs(txt.scaleX);
					grp.rotation = 180;
					txt.rotation = 180;
					grp.y = target.y + distance
					break;
				case 1://点在右上角
					if (grp.scaleX > 0) {
						grp.scaleX *= -1;
						txt.scaleX *= -1;
					}
					grp.y = target.y + distance
					grp.rotation = 180;
					txt.rotation = 180;
					break;
				case 2://点在左下角
					if (grp.scaleX > 0) {
						grp.scaleX *= -1;
						txt.scaleX *= -1;
					}
					grp.y = target.y - distance
					grp.rotation = 0;
					txt.rotation = 0;
					break;
				case 3://点在右下角
					grp.scaleX = Math.abs(grp.scaleX);
					txt.scaleX = Math.abs(txt.scaleX);
					grp.rotation = 0;
					txt.rotation = 0;
					grp.y = target.y - distance
					break;
			}
		}

		/** 游戏场景内点击处理 */
		private touchTapScencrHandler(evt: egret.TouchEvent) {
			let stageX: number = evt.stageX;
			let stageY: number = evt.stageY;
			let width: number = this.stage.stageWidth / 2;
			let height: number = this.stage.stageHeight / 2;
			this.img_target.x = evt.localX;
			this.img_target.y = evt.localY * Model.getInstance().scaleY;
			console.log( evt.stageY,evt.localY,this.img_scence.x,this.img_scence.y);
			if (stageX < width && stageY < height) {
				this.setSureState(0);
			} else if (stageX >= width && stageY <= height) {
				this.setSureState(1);
			} else if (stageX < width && stageY > height) {
				this.setSureState(2);
			} else if (stageX >= width && stageY >= height) {
				this.setSureState(3);
			}
			this.img_target.visible = true;
			this.grp_sure.visible = true;
		}

		/** 检查是否正确 */
		private inspect(){
			SoundPlayer.playSoundWav(SoundConst.click);
			let target:eui.Image = this.img_target;
			let centerX:number = this.img_scence.width*this.img_scence.scaleX /2;
			let centerY:number = this.img_scence.height*this.img_scence.scaleY /2;
			if(!this.targetTween.parent) this.grp_scence.addChild(this.targetTween);
			this.targetTween.scaleY = Model.getInstance().scaleY;
			this.targetTween.x = target.x;
			this.targetTween.y = target.y;
			this.targetTween.visible = true;
			this.targetTween.play(-1);
			this.grp_sure.visible = false;
			//判断是否在坐标范围内
			let targetPoint:egret.Point = new egret.Point(centerX + this.answerX,centerY - this.answerY);
			let clickPoint:egret.Point = new egret.Point(target.x,target.y);
			let distance:number = egret.Point.distance(targetPoint,clickPoint);
			this.removeGameScenceEventList();
			setTimeout(() => {
				if(distance <= GlobalConfig.diameter * target.scaleY)//正确处理
				{
					this.setResult(true);
				}else{//错误处理
					this.setResult(false);
				}
			}, 1000);
		}

		/** 设置结果 */
		private setResult(isWin:boolean){
			this.targetTween.visible = false;
			if(isWin)
			{
				this.lab_result.text = "正确";
				this.grp_result_close.addEventListener(egret.TouchEvent.TOUCH_TAP,this.showVictoryView,this);
			}else{
				this.lab_result.text = "不正确";
				this.grp_result_close.addEventListener(egret.TouchEvent.TOUCH_TAP,this.showDefeatView,this);
			}
			this.grp_result.visible = true;
		}

		/** 创建场景内容 */
		private createScence(data:{stage:data.StageConfig,section:data.SectionConfig}){
			this.lab_section.text = data.section.sectionId+"."+data.section.sectionName;
			this.lab_question.text = data.section.question;
			this.img_scence.source = data.stage.illust+"_png";
			this.answerX = data.section.answer_x*1.8;
			this.answerY = data.section.answer_y*1.53*Model.getInstance().scaleY;
			this.answerW = data.section.answer_w;
			this.answerH = data.section.answer_h;
			this.lab_tips.text = data.section.hint;
			this.lab_explain.text = data.section.answer;
			this.img_answer.source = data.section.answer_image+"_jpg";
			if(!this.isFirst){
				this.restScence();
			}
			if(data.section.sectionId == 1)
			{
				this.isShowTitle = true;
				this.lab_title_id.text = "日记."+data.stage.stageId;
				this.lab_title_name.text = data.stage.stageName;
				this.grp_titile.visible = true;
				this.grp_titile.addEventListener(egret.TouchEvent.TOUCH_TAP,this.closeTitile,this);
			}else{
				this.isShowTitle = false;
				this.closeTitile();
			}
		}

		/** 重置场景 */
		private restScence(){
			// platform.showBannerAd(WXManager.getInstance().scenceBanner);
			this.addGameScenceEventList();
			this.grp_tip.alpha = 0;
			this.grp_tip.visible = false;
			this.grp_over_close.removeEventListener(egret.TouchEvent.TOUCH_TAP,this.againGame,this);
			this.grp_over_choose.removeEventListener(egret.TouchEvent.TOUCH_TAP,this.showCheckView,this);
			this.grp_game.visible = true;
			this.grp_result.visible = false;
			this.grp_over.visible = false;
			// this.grp_scence.mask = this.rect_mask;
			this.isBothHands = false;
			this.oldValue = 0;
			this.lastMoveX = 0;
			this.lastMoveY = 0;
			this.isVideo = false;
			this.img_target.visible = false;
			this.grp_sure.visible = false;
			this.grp_clue.visible = true;
			this.grp_scence.scaleX = this.grp_scence.scaleY = 1;
			this.grp_scence.x = 540;
			this.grp_scence.y = this.height/2-100;
			this.grp_diary.visible = false;
			this.grp_video.visible = false;
			this.grp_set.visible = false;
			this.grp_section.visible = false;
			this.removeCheckEventList();
			this.grp_check.visible = false;
			this.grp_goon.visible = false;
			// if(this.isShowTitle)
			// {
			// 	this.grp_titile.visible = true;
			// 	this.grp_titile.addEventListener(egret.TouchEvent.TOUCH_TAP,this.closeTitile,this);
			// }else{
			// 	this.closeTitile();
			// }
		}

		/** 关闭标题界面 */
		private closeTitile(){
			this.grp_titile.visible = false;
			this.grp_titile.removeEventListener(egret.TouchEvent.TOUCH_TAP,this.closeTitile,this);
		}

		/** 关闭会话界面 */
		private closeSection(){
			SoundPlayer.playSoundWav(SoundConst.click);
			this.grp_clue.visible = false;
		}

		/** 显示失败界面 */
		private showDefeatView(){
			SoundPlayer.playSoundWav(SoundConst.click);
			this.grp_result_close.removeEventListener(egret.TouchEvent.TOUCH_TAP,this.showDefeatView,this);
			this.grp_result.visible = false;
			this.grp_over_close.addEventListener(egret.TouchEvent.TOUCH_TAP,this.againGame,this);
			this.grp_over_choose.addEventListener(egret.TouchEvent.TOUCH_TAP,this.showCheckView,this);
			this.grp_over_answer.addEventListener(egret.TouchEvent.TOUCH_TAP,this.playVideo,this);
			this.grp_over.visible = true;
			// platform.showBannerAd(WXManager.getInstance().overBanner);
			platform.createInterstitialAd();
		}

		/** 显示胜利界面 */
		private showVictoryView(){
			SoundPlayer.playSoundWav(SoundConst.click);
			this.sendNotification(UiNotifyConst.saveRecord);
			this.grp_over_close.removeEventListener(egret.TouchEvent.TOUCH_TAP,this.againGame,this);
			this.grp_over_choose.removeEventListener(egret.TouchEvent.TOUCH_TAP,this.showCheckView,this);
			this.grp_over_answer.removeEventListener(egret.TouchEvent.TOUCH_TAP,this.playVideo,this);
			this.grp_result_close.removeEventListener(egret.TouchEvent.TOUCH_TAP,this.showVictoryView,this);
			this.grp_over.visible = false;
			// platform.hideBannerAd(WXManager.getInstance().overBanner);
			this.grp_result.visible = false;
			this.grp_goon_choose.addEventListener(egret.TouchEvent.TOUCH_TAP,this.showCheckView,this);
			this.grp_goon_next.addEventListener(egret.TouchEvent.TOUCH_TAP,this.joinNextStage,this);
			this.grp_goon.visible = true;
			// platform.createInterstitialAd();
		}

		/** 重新推理 */
		private againGame(){
			SoundPlayer.playSoundWav(SoundConst.click);
			this.sendNotification(UiNotifyConst.againGame);
			platform.createBannerAd2();
		}

		/** 获取日记内容 */
		private getDiary(){
			SoundPlayer.playSoundWav(SoundConst.click);
			this.sendNotification(UiNotifyConst.getDiary);
		}

		/** 显示日记 */
		private showDiary(txt:string){
			this.lab_diary.text = txt;
			this.grp_diary.visible = true;
		}

		/** 关闭日记 */
		private closeDiary(){
			SoundPlayer.playSoundWav(SoundConst.click);
			this.grp_diary.visible = false;
		}

		/** 关闭视频组 */
		private closeVideo(){
			SoundPlayer.playSoundWav(SoundConst.click);
			this.grp_video.visible  = false;
		}

		/** 显示视频组 */
		private showVideo(){
			SoundPlayer.playSoundWav(SoundConst.click);
			this.grp_video.visible  = true;
		}

		/** 显示线索组 */
		private showClue(){
			SoundPlayer.playSoundWav(SoundConst.click);
			this.grp_clue.visible = true;
		}

		/** 显示设置 */
		private showSetting(){
			SoundPlayer.playSoundWav(SoundConst.click);
			this.grp_set.visible = true;
		}

		/** 关闭设置 */
		private closeSet(){
			SoundPlayer.playSoundWav(SoundConst.click);
			this.grp_set.visible = false;
		}

		/** 是否需要音效 */
		private isOpenSound(){
			if(this.img_sound.name == "on")
			{
				this.img_sound.name = "off";
				SoundPlayer.openSound(false);
			}else{
				this.img_sound.name = "on"
				SoundPlayer.openSound(true);
				SoundPlayer.playSoundWav(SoundConst.click);
				SoundPlayer.playMusic(SoundConst.bg);
			}
			this.img_sound.source = "res_json.btn_music_"+this.img_sound.name;
		}

		/** 初始化系列列表 */
		private initSeriesList(data:data.StageArrConfig[]){
			this.list_series.itemRenderer = Series;
			this.list_series.dataProvider = new eui.ArrayCollection(data);
		}

		/** 关闭场景 */
		private closeScence(){
			SoundPlayer.playSoundWav(SoundConst.click);
			this.removeGameScenceEventList();
			this.grp_game.visible = false;
			this.showCheckView();
		}

		/** 显示关卡界面 */
		private showCheckView(){
			SoundPlayer.playSoundWav(SoundConst.click);
			this.sendNotification(UiNotifyConst.updateCheckNum);
			this.grp_over_close.removeEventListener(egret.TouchEvent.TOUCH_TAP,this.againGame,this);
			this.grp_over_choose.removeEventListener(egret.TouchEvent.TOUCH_TAP,this.showCheckView,this);
			this.grp_over_answer.removeEventListener(egret.TouchEvent.TOUCH_TAP,this.playVideo,this);
			this.grp_goon_choose.removeEventListener(egret.TouchEvent.TOUCH_TAP,this.showCheckView,this);
			this.grp_goon_next.removeEventListener(egret.TouchEvent.TOUCH_TAP,this.joinNextStage,this);
			this.grp_result_close.removeEventListener(egret.TouchEvent.TOUCH_TAP,this.showCheckView,this);
			this.grp_result.visible = false;
			this.grp_over.visible = false;
			this.grp_check.visible = true;
			this.sco_series.visible = true;
			this.sco_series.viewport.scrollV = 0;
			this.addCheckEventList();
		}

		/** 添加关卡界面监听 */
		private addCheckEventList(){
			this.grp_check_back.addEventListener(egret.TouchEvent.TOUCH_TAP,this.closeCheck,this);
			this.img_stage_close.addEventListener(egret.TouchEvent.TOUCH_TAP,this.closeStageList,this);
		}

		/** 移除关卡界面监听 */
		private removeCheckEventList(){
			this.grp_check_back.removeEventListener(egret.TouchEvent.TOUCH_TAP,this.closeCheck,this);
			this.img_stage_close.removeEventListener(egret.TouchEvent.TOUCH_TAP,this.closeStageList,this);
		}

		/** 关闭关卡界面 */
		private closeCheck() {
			SoundPlayer.playSoundWav(SoundConst.click);
			if (this.grp_section.visible) {
				this.grp_section.visible = false;
				this.sco_series.visible = true;
				for (let i: number = 0; i < 4; i++) {
					this["grp_section_" + i].removeEventListener(egret.TouchEvent.TOUCH_TAP, this.joinAppointSection, this);
				}
			} else {
				this.removeCheckEventList();
				this.grp_check.visible = false;
				this.grp_game.visible = false;
				this.grp_start.visible = true;
				this.addStartMenuEventList();
			}
		}

		/** 刷新关卡数 */
		private updateCheckNum(data: { now: number, max: number }) {
			this.lab_num.text = data.now+"/"+data.max;
		}

		/** 显示会话列表 */
		private showSectionList(data:data.NeedSectionConfig[]){
			for(let i:number = 0;i < data.length;i++)
			{
				this["grp_section_"+i].name = data[i].section.sectionId;
				switch(data[i].isAdopt)
				{
					case 0://正在
						this["grp_section_pass_"+i].visible = false;
						this["img_section_lock_"+i].visible = false;
						break;
					case 1://已通关
						this["grp_section_pass_"+i].visible = true;
						this["img_section_lock_"+i].visible = false;
						break;
					case 2://未通关
						this["grp_section_pass_"+i].visible = false;
						this["img_section_lock_"+i].visible = true;
						break;
				}
				this["lab_section_id_"+i].text = "QUESTION."+data[i].section.sectionId;
				this["lab_section_name_"+i].text = data[i].section.sectionName;
			}
			for(let i:number = 0;i < 4;i++)
			{
				if(!this["img_section_lock_"+i].visible)
				{
					this["grp_section_"+i].addEventListener(egret.TouchEvent.TOUCH_TAP,this.joinAppointSection,this);
				}
			}
			this.sco_series.visible = false;
			this.grp_stage.visible = false;
			this.grp_section.visible = true;
		}

		/** 进入指定对话 */
		private joinAppointSection(evt:egret.TouchEvent){
			SoundPlayer.playSoundWav(SoundConst.click);
			this.sendNotification(UiNotifyConst.joinAppointSection,parseInt(evt.currentTarget.name));
		}

		/** 显示关卡列表 */
		private showStageList(data:data.NeedStageConfig){
			this.sco_stage.viewport.scrollV = 0;
			this.list_stage.dataProvider = new eui.ArrayCollection(data.stage.stage);
			this.grp_stage.visible = true;
		}

		/** 关闭关卡列表 */
		private closeStageList(){
			SoundPlayer.playSoundWav(SoundConst.click);
			this.grp_stage.visible = false;
		}

		/** 初始化答案界面 */
		private initAnswer(data:data.SectionConfig){
			this.img_answer.source = data.answer_image+"_jpg";
			this.lab_explain.text = data.answer;
		}

		/** 下一关 */
		private joinNextStage(){
			SoundPlayer.playSoundWav(SoundConst.click);
			this.grp_goon.visible = false;
			this.sendNotification(UiNotifyConst.joinNextStage);
		}

		/** 播放广告 */
		private playVideo(evt:egret.TouchEvent){
			SoundPlayer.playSoundWav(SoundConst.click);
			platform.createRewardedVideoAd(evt.currentTarget.name).then((suc)=>{
				console.log("看完了！",suc);
				switch(suc){
					case "1":
						this.isVideo = true;
						this.grp_tips.visible = true;
						this.closeVideo();
						break;
					case "2":
						this.isVideo = true;
						this.showVictoryView();
						break;
				}
			}).catch((data)=>{
				console.log("没看完！",data);
			})
			// platform.showBannerAd(WXManager.getInstance().videoBanner);
			// switch(evt.currentTarget.name)
			// {
			// 	case "1":
			// 		this.isVideo = true;
			// 		this.grp_tips.visible = true;
			// 		this.closeVideo();
			// 		break;
			// 	case "2":
			// 		this.isVideo = true;
			// 		this.showVictoryView();
			// 		break;
			// }
		}

		/** 显示提示框 */
		private showTips(txt:string){
			if(this.grp_tip.alpha != 0)
			{
				return;
			}
			this.grp_tip.visible = true;
			this.lab_tip.text = txt;
			egret.Tween.get(this.grp_tip)
				.to({alpha:1},800)
				.wait(1400)
				.to({alpha:0},800)
				.call(()=>{
					this.grp_tip.visible = false;
					egret.Tween.removeTweens(this.grp_tip);
				})
		}
	}
}