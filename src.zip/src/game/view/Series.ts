module game {
	export class Series extends eui.ItemRenderer{
		public constructor() {
			super();
			this.skinName = "resource/skins/SeriesSkin.exml";
			this.addEventListener(egret.Event.ADDED_TO_STAGE,this.init,this);
		}

		/** 标题图片 */
		private img_title:eui.Image;
		/** 选择 */
		private grp_chose:eui.Group;
		/** 更多关卡 */
		private grp_more:eui.Group;
		/** 系列编号 */
		private seriesId:number;
		/** 关卡数据 */
		private stageData:data.StageArrConfig;

		/** 初始化操作 */
		private init(){
			for(let i:number = 0;i < 4;i++){
				this["grp_"+i].addEventListener(egret.TouchEvent.TOUCH_TAP,this.getStageSectionList,this);
			}
			this.grp_more.addEventListener(egret.TouchEvent.TOUCH_TAP,this.getNeedStageList,this);	
			this.grp_chose.addEventListener(egret.TouchEvent.TOUCH_TAP,this.getNeedStageList,this);	
		}

		protected dataChanged(){
			this.setShowContent(this.data);
		}

		/** 设置显示内容 */
		private setShowContent(data:data.NeedSeriesConfig){
			this.stageData = data.stage;
			this.img_title.source = "title_"+data.stageId+"_png";
			for(let i:number = 0;i < 4;i++){
				this["lab_num_"+i].text = "Stage."+data.stage.stage[i].stageId;
				this["grp_"+i].name = data.stage.stage[i].stageId;
				this["lab_name_"+i].text = data.stage.stage[i].stageName;
				this.seriesId = data.stageId;
				this["img_lock_"+i].visible = data.stage.stage[i].isLock;
			}
		}

		/** 获取关卡会话列表 */
		private getStageSectionList(evt:egret.TouchEvent){
			SoundPlayer.playSound(SoundConst.click);
			if(this["img_lock_"+(parseInt(evt.currentTarget.name)-1)].visible)
			{
				return;
			}
			console.log("要显示的系列编号："+this.seriesId,"要显示的章节Id："+parseInt(evt.currentTarget.name));
			NotifyManager.getInstance().distribute(UiNotifyConst.getStageSectionList,{seriesId:this.seriesId,stageId:parseInt(evt.currentTarget.name)});
		}

		/** 获取需要的关卡列表 */
		private getNeedStageList(){
			NotifyManager.getInstance().distribute(UiNotifyConst.getStageList,{seriesId:this.seriesId,stageData:this.stageData});
		}
	}
}