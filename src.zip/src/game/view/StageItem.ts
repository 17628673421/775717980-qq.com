module game {
	export class StageItem extends eui.ItemRenderer {
		public constructor() {
			super();
			this.skinName = "resource/skins/StageItemSkin.exml";
			this.addEventListener(egret.Event.ADDED_TO_STAGE,this.init,this);
		}

		/** 关卡Id */
		private lab_id:eui.Label;
		/** 关卡名称 */
		private lab_name:eui.Label;
		/** 锁 */
		private img_lock:eui.Image;
		/** 关卡Id */
		private stageId:number;
		/** 系列id */
		private seriesId:number;

		/** 初始化 */
		private init(){
			this.img_lock.visible = true;
		}

		protected dataChanged(){
			this.setShowContent(this.data);
		}

		/** 设置显示内容 */
		private setShowContent(data:data.StageConfig){
			this.img_lock.visible = data.isLock;
			this.lab_id.text = "Stage."+data.stageId;
			this.lab_name.text = data.stageName;
			this.stageId = data.stageId;
			this.seriesId = data.seriesId;
			if(!data.isLock)
			{
				this.addEventListener(egret.TouchEvent.TOUCH_TAP,this.getStageSectionList,this);
			}
		}

		/** 获取关卡会话列表 */
		private getStageSectionList(){
			SoundPlayer.playSound(SoundConst.click);
			console.log("要显示的系列编号："+this.seriesId,"要显示的章节Id："+this.stageId);
			NotifyManager.getInstance().distribute(UiNotifyConst.getStageSectionList,{seriesId:this.seriesId,stageId:this.stageId});
		}
	}
}