/** Controller通知UI的枚举 */
enum UiCommand {
    /** 创建场景 */
    createScence,
    /** 显示日记 */
    showDiary,
    /** 初始化系列列表 */
    initSeriesList,
    /** 刷新关卡数 */
    updateCheckNum,
    /** 显示会话列表 */
    showSectionList,
    /** 显示关卡列表 */
    showStageList,
    /** 初始化答案界面 */
    initAnswer,
    /** 游戏通关 */
    gameClearance,
    /** 显示提示 */
    showTip
}
