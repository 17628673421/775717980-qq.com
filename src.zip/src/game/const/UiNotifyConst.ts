/** UI通知Controller的事件 */
enum UiNotifyConst {
    start = 200,
    /** 初始化舞台 */
    initStage,
    /** 再次推理 */
    againGame,
    /** 获取日记内容 */
    getDiary,
    /** 获取关卡回话列表 */
    getStageSectionList,
    /** 刷新关卡数（已破案/总关数） */
    updateCheckNum,
    /** 加入指定会话 */
    joinAppointSection,
    /** 获取关卡列表 */
    getStageList,
    /** 保存记录 */
    saveRecord,
    /** 下一关 */
    joinNextStage
}