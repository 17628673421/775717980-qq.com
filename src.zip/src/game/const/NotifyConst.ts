enum NotifyConst {
    connectError = 1,
}