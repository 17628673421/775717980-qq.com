module game {
	export class GlobalConfig {
		/** 本地保存的通关记录字段 */
		public static Record:string = "Record";
		/** 点击的蓝球直径（正确范围的直径） */
		public static diameter:number = 65;
	}
}