module game {
	export class Model {
		public constructor() { }
		private static _instance: Model;
		public static getInstance(): Model {
			if (!this._instance) this._instance = new Model();
			return this._instance;
		}

		/** 适配X */
		public scaleX:number = 0;
		/** 适配Y */
		public scaleY:number = 0;
		/** 通关记录 */
		public record:data.RecordConfig[];

		
	}
}