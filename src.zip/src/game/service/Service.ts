module game {
	export class Service extends BaseNotification {
		private static _instance: Service;
		private constructor() {
			super();
			this.addRegister("Service", this);
		}

		public static init() {
			if (!this._instance) this._instance = new Service();
		}

		/** 罗列要接收的通知 */
		public listNotification(): Array<number> {
			return [
				
			];
		}
		/** 接收通知 */
		public handleNotification(type: number, body: any): void {
			switch (type) {
				
			}
		}
	}
}