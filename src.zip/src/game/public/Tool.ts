module game {
	/** 
	 * 工具类(包含常用方法)
	 * @author zjw
	 */
	export class Tool {

		/** 
		 * 画一条直线
		 */
		public static drawLine(color: number, size: number, start: number[], end: number[]): egret.Shape {
			let line: egret.Shape = new egret.Shape();
			line.graphics.beginFill(color);
			line.graphics.lineStyle(size, color);
			line.graphics.lineTo(start[0], start[1]);
			line.graphics.lineTo(end[0], end[1]);
			line.graphics.endFill();
			return line;
		}

		/** 时间戳转换日期格式yy-mm-dd */
		public static timeChange_A(time: number): string {
			var date = new Date(time);
			var y = date.getFullYear();
			var m = "0" + (date.getMonth() + 1);
			var d = "0" + date.getDate();
			return y + "-" + m.substring(m.length - 2, m.length) + "-" + d.substring(d.length - 2, d.length);
		}

		/** 日期格式mm-dd-yy|hh:mm:ss转换为时间戳 */
		public static timeChange_B(dateStr: string): number {
			let time: number = 0;
			let strArr_a: string[] = dateStr.split("|");
			let strArr_b: string[] = strArr_a[0].split("-");
			let strArr_c: string[] = strArr_a[1].split(":");
			// let strDate:string = strArr_b[2]+"-"+strArr_b[0]+"-"+strArr_b[1]+" "+strArr_a[1];
			let date = new Date(
				parseInt(strArr_b[2]), parseInt(strArr_b[0]) - 1, parseInt(strArr_b[1]),
				parseInt(strArr_c[0]), parseInt(strArr_c[1]), parseInt(strArr_c[2])
			);
			time = date.getTime();
			return time;
		}

		/** 
		 * 在group里设置图片字
		 * @param imgSrc 图片字资源组
		 * @param grp 存放图片字的group
		 * @param num 需要设置的分数
		 * @param tipsImgRes 分数前的提示图片（历史最佳：6666）
		 * 
		 * @author zjw
		 */
		public static setFontImgInGroup(imgSrc: string[], grp: eui.Group, num: number, tipsImgRes?: string) {
			grp.removeChildren();
			if (tipsImgRes) {
				let img: eui.Image = new eui.Image();
				img.source = tipsImgRes;
				grp.addChild(img);
			}
			let str: string = num + "";
			for (let i: number = 0; i < str.length; i++) {
				let img: eui.Image = new eui.Image();
				img.source = imgSrc[parseInt(str.charAt(i))];
				grp.addChild(img);
			}
		}

		/**
		 * 预加载指定的帧动画(此方法需要game库)
		 * @param configRes 配置文件在RES配置里的key名称
		 * @param textureRes 图集文件在RES配置里的key名称
		 * @param animationNmae 需要播放的动画的名称
		 * @returns 加载完毕的MovieClip对象
		 * 
		 * @author zjw
		 */
		public static preLoadingFrameAnimation(configRes: string, textureRes: string, animationNmae: string): egret.MovieClip {
			let config: JSON = RES.getRes(configRes);
			let texture: egret.Texture = RES.getRes(textureRes);
			if (config && texture) {
				let factory: egret.MovieClipDataFactory = new egret.MovieClipDataFactory(config, texture);
				let mc: egret.MovieClip = new egret.MovieClip(factory.generateMovieClipData(animationNmae));
				return mc;
			} else {
				return null;
			}
		}

		/** 
		 * 指定范围内随机数 Min<=Num<=Max
		 * @param Min 最小值
		 * @param Max 最大值
		 * 
		 * @author zjw
		 */
		public static getRandom(Min: number, Max: number): number {
			let Range: number = Max - Min;
			let Rand: number = Math.random();
			let num: number = Min + Math.round(Rand * Range);
			return num;
		}

		/** 
		 * 一个点根据指定点旋转任意度数后的坐标
		 * @param point 需要旋转的点
		 * @param target 围绕的目标点
		 * @param angle 需要旋转的角度
		 * 
		 * @author zjw
		 */
		public static getAroundPointRotate(point: egret.Point, target: egret.Point, angle: number): egret.Point {
			let result: egret.Point = new egret.Point();
			result.x = (point.x - target.x) * Math.cos(angle) - (point.y - target.y) * Math.sin(angle) + target.x;
			result.y = (point.x - target.x) * Math.sin(angle) + (point.y - target.y) * Math.cos(angle) + target.x;
			return result;
		}

		/** 设置一个显示对象的适配属性 */
		public static setDisObjAdaptation(disObj: egret.DisplayObject) {
			let model: Model = Model.getInstance();
			let chilsArr: egret.DisplayObject[] = disObj.$children;
			if (chilsArr && disObj instanceof eui.Group) {
				chilsArr.forEach(element => {
					Tool.setDisObjAdaptation(element);
				});
			} else {
				if (disObj instanceof eui.Label && model.scaleX < 1) {
					disObj.scaleX = model.scaleX;
					disObj.scaleY = model.scaleY;
				} else {
					disObj.scaleX = model.scaleX;
					disObj.scaleY = model.scaleY;

				}
			}
		}

		/**
		 * 预加载指定的粒子特效(此方法需要第三方粒子库particle)
		 * @param configRes 配置文件在RES配置里的key名称
		 * @param textureRes 图集文件在RES配置里的key名称
		 * @returns 加载完毕的GravityParticleSystem对象
		 * 
		 * @author zjw
		 */
		// public static preLoadingParticleEffect(configRes: string, textureRes: string): particle.GravityParticleSystem {
		// 	let config: JSON = RES.getRes(configRes);
		// 	let texture: egret.Texture = RES.getRes(textureRes);
		// 	if (texture && config) {
		// 		let effect = new particle.GravityParticleSystem(texture, config);
		// 		return effect;
		// 	} else {
		// 		return null;
		// 	}
		// }

		/** 请求报价数据返回不足3000条时进行日期处理--往前推三个月 */
		public static dealDate(data: any) {
			let arrAll: string[] = data.startTime.split('|');
			let arrDate: string[] = arrAll[0].split('-');
			let month = parseInt(arrDate[0]);
			let newStart = '';
			if (month > 3) {
				newStart = `0${(month - 3).toString()}-${arrDate[1]}-${arrDate[2]}|${arrAll[1]}`;
				if (month - 3 == 2) {
					let year = parseInt(arrDate[2]);
					let day = parseInt(arrDate[1]);
					if (day > 28) {
						if (year % 4 == 0 && year % 100 != 0) {
							newStart = `02-29-${arrDate[2]}|${arrAll[1]}`;
						} else {
							newStart = `02-28-${arrDate[2]}|${arrAll[1]}`;
						}
					}
				}
			} else {
				newStart = `${(month + 9).toString()}-${arrDate[1]}-${(parseInt(arrDate[2]) - 1).toString()}|${arrAll[1]}`;
			}
			data.startTime = newStart;
			return data;
		}

		/** base64转换成纹理 */
		public static base64ToTexture(base64: string): Promise<{}> {
			return new Promise((resolve, reject) => {
				let imgTag: HTMLImageElement = new Image();
				let texture: egret.Texture = new egret.Texture();
				imgTag.src = base64;
				imgTag.onload = () => {
					let bitmapdata: egret.BitmapData = new egret.BitmapData(imgTag);
					texture.bitmapData = bitmapdata;
					resolve(texture);
				}
			})
		}

		/** 时间格式处理 
		 * @param time 毫秒数
		*/
		public static timeHandler(time: number): string {
			let result: string = "";
			let Minute: string = "00";
			let Second: string = "00";
			let numA: number = time / 60000;  
			let numB: number = time % 60000;
			if (numB == 0) {
				numA >= 10 ? Minute = numA + "" : Minute = "0" + numA;
			} else {
				let strArr: string[] = (numA + "").split(".");
				let numC: number = parseInt(strArr[0]);
				numC >= 10 ? Minute = numC + "" : Minute = "0" + numC;
				let numD: number = numB / 1000;
				numD >= 10 ? Second = numD + "" : Second = "0" + numD;
			}
			result = Minute + ":" + Second;
			return result;
		}

		/** 判断手机号是否合法 */
		public static judgeAccount(account: string): boolean {
			let result: boolean = false;
			let judge: any = /^(((13[0-9]{1})|(14[0-9]{1})|(17[0-9]{1})|(15[0-3]{1})|(15[4-9]{1})|(18[0-9]{1})|(199))+\d{8})$/;
			if (!judge.test(account)) {
				result = false;
			} else {
				result = true;
			}
			return result;
		}
	}
}

