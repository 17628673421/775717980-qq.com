module data {

    /** 关卡总表配置 */
    export class StageArrConfig{
        /** 关卡 */
        public stage:StageConfig[];
    }

    /** 关卡配置 */
    export class StageConfig{
        /** 关卡id */
        public stageId:number;
        /** 关卡名称 */
        public stageName:string;
        /** 关卡背景图 */
        public illust:string;
        /** 对话组 */
        public section:SectionConfig[];
        /** 是否上锁 */
        public isLock:boolean;
        /** 系列编号 */
        public seriesId:number;
    }

    /** 对话配置 */
    export class SectionConfig{
        /** 对话id */
        public sectionId:number;
        /** 对话名称 */
        public sectionName:string;
        /** 问题 */
        public question:string;
        /** 答案 */
        public answer:string;
        /** 提示 */
        public hint:string;
        /** 答案X坐标 */
        public answer_x:number;
        /** 答案Y坐标 */
        public answer_y:number;
        /** 答案宽度 */
        public answer_w:number;
        /** 答案Y高度 */
        public answer_h:number;
        /** 答案图片 */
        public answer_image:string;
    }

    /** 系列配置总表 */
    export class SeriesAllConfig{
        /** 显示的系列数量 */
        public stageNum:number;
        /** 系列配置组 */
        public stage:SeriesConfig[];
    }

    /** 系列配置 */
    export class SeriesConfig{
        /** 系列编号 */
        public stageId:number;
        /** 中文配置文件名 */
        public CnStagePath:string;
        /** 英文配置文件名 */
        public EnStagePath:string;
        /** 俄文配置文件名 */
        public RuStagePath:string;
        /** 系列总关卡数 */
        public sectionNum:number;
    }

    /** 需要显示的系列配置 */
    export class NeedSeriesConfig{
        /** 系列编号 */
        public stageId:number;
        /** 关卡配置 */
        public stage:StageArrConfig;
    }

    /** 需要显示的会话配置 */
    export class NeedSectionConfig{
        /** 关卡状态 0：正在通关 1：已通关  2：未通关 */
        public isAdopt:number;
        /** 会话配置 */
        public section:SectionConfig;
    }

    /** 需要显示的关卡配置 */
    export class NeedStageConfig{
        /** 系列id */
        public seriesId:number;
        /** 关卡总配置 */
        public stage:StageArrConfig;
    }

    /** 通关记录配置 */
    export class RecordConfig{
        /** 系列ID */
        public seriesId:number;
        /** 记录 */
        public record:Record;
    }

    /** 单条记录 */
    export class Record{
        /** 关卡Id */
        public stageId:number;
        /** 会话id */
        public sectionId:number;
    }
    
}