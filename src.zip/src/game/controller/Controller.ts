module game {
	export class Controller extends BaseController {
		public constructor() {
			super();
		}
		private static _instance: Controller;
		public static getInstance(): Controller {
			if (!this._instance) this._instance = new Controller();
			return this._instance;
		}

		/** 系列总表配置 */
		private seriesArr: data.SeriesAllConfig;
		/** 需要显示的系列关卡总配置数据 */
		private needSeriesArr: data.NeedSeriesConfig[];
		/** 关卡总表配置 */
		private stageArr: data.StageArrConfig;
		/** 当前关卡 */
		private nowStage: data.StageConfig;
		/** 当前系列 */
		private nowSeriesId: number;
		/** 当前会话 */
		private nowSection: data.SectionConfig;
		/** 点击的关卡id */
		private clickStageId: number;
		/** 点击的系列id */
		private clickSeriesId:number;


		/**
		 * @extends BaseController
		 */
		public start() {
			Service.init();
			this.openGameUI();
		}
		/** 打开主页 */
		public openGameUI() {
			this.enterUI(new GameUI, LayerConst.Layer_UI);
		}

		/**
		 * @extends BaseController
		* 初始化UI数据
		 */
		protected initData() {

		}

		/** 
		 * @extends BaseController
		 * 罗列要接收的通知 
		 */
		public listNotification(): Array<number> {
			return [
				UiNotifyConst.initStage,
				UiNotifyConst.againGame,
				UiNotifyConst.getDiary,
				UiNotifyConst.updateCheckNum,
				UiNotifyConst.getStageSectionList,
				UiNotifyConst.joinAppointSection,
				UiNotifyConst.getStageList,
				UiNotifyConst.saveRecord,
				UiNotifyConst.joinNextStage
			]
		};

		/** 
		 * @extends BaseController
		 * 接收通知 
		 */
		public handleNotification(type: number, body: any): void {
			switch (type) {
				case UiNotifyConst.initStage:
					this.initStage();
					break;
				case UiNotifyConst.againGame:
					this.againGame();
					break;
				case UiNotifyConst.getDiary:
					this.getDiary();
					break;
				case UiNotifyConst.updateCheckNum:
					this.updateCheckNum();
					break;
				case UiNotifyConst.getStageSectionList:
					this.getStageSectionList(body);
					break;
				case UiNotifyConst.joinAppointSection:
					this.joinAppointSection(body);
					break;
				case UiNotifyConst.getStageList:
					this.getStageList(body);
					break;
				case UiNotifyConst.saveRecord:
					this.saveRecord();
					break;
				case UiNotifyConst.joinNextStage:
					this.joinNextStage();
					break;
			}
		}

		/** 加载资源 */
		private loadRes(){
			let seriesArr:data.SeriesAllConfig = RES.getRes("StageConfig_json");
			for(let i:number = 0;i<seriesArr.stageNum;i++)
			{
				let stageArr:data.StageArrConfig = RES.getRes(seriesArr.stage[i].CnStagePath);
				stageArr.stage.forEach(stage => {
					RES.loadGroup("stage_"+seriesArr.stage[i].stageId+"_"+stage.stageId);
				});
			}
		}

		/** 初始化关卡 */
		private initStage() {
			//  egret.localStorage.clear();
			this.seriesArr = RES.getRes("StageConfig_json");
			let recordStr: string = egret.localStorage.getItem(GlobalConfig.Record);
			let model: Model = Model.getInstance();
			model.record = [];
			//游戏记录处理
			if (recordStr) {
				model.record = JSON.parse(recordStr);
				console.log("本地保存的通关记录", model.record);
				let nowStageId: number = 0;
				let nowSeriesId: number = 0;
				let nowSectionId: number = 0;
				//初始化关卡
				for (let i: number = 0; i < model.record.length; i++) {
					if (model.record[i].record.sectionId > 0 && model.record[i].record.sectionId <= 4) {
						nowSectionId = model.record[i].record.sectionId;
						nowStageId = model.record[i].record.stageId;
						nowSeriesId = model.record[i].seriesId;
						break;
					}
				}
				//设置初始化关卡数据
				for (let i: number = 0; i < this.seriesArr.stageNum; i++) {
					if (this.seriesArr.stage[i].stageId == nowSeriesId)//找到对应的系列数据
					{
						this.nowSeriesId = this.seriesArr.stage[i].stageId;
						this.stageArr = RES.getRes(this.seriesArr.stage[i].CnStagePath);//读取该系列的关卡总表配置
						for (let j: number = 0; j < this.stageArr.stage.length; j++) {
							if (this.stageArr.stage[j].stageId == nowStageId)//找到关卡配置
							{
								this.nowStage = this.stageArr.stage[j];
								for (let k: number = 0; k < this.nowStage.section.length; k++) {
									if (this.nowStage.section[k].sectionId == nowSectionId)//找到会话配置
									{
										if(this.nowStage.section[k+1])
										{
											this.nowSection = this.nowStage.section[k+1];
										}else{
											if(this.stageArr.stage[j+1])
											{
												this.nowStage = this.stageArr.stage[j+1];
												this.nowSection = this.nowStage.section[0];
											}else{
												if(this.seriesArr.stage[this.nowSeriesId] && this.nowSeriesId <= this.seriesArr.stageNum)
												{
													this.stageArr = RES.getRes(this.seriesArr.stage[this.nowSeriesId].CnStagePath)
													this.nowStage = this.stageArr.stage[0];
													this.nowSection = this.nowStage.section[0];
												}else{
													this.nowStage = this.stageArr.stage[j+1];
													this.nowSection = this.nowStage.section[0];
												}
											}
										}
										break;
									}
								}
								break;
							}
						}
						break;
					}
				}
			} else {
				for (let i: number = 0; i < this.seriesArr.stageNum; i++) {
					let recordConfig: data.RecordConfig = new data.RecordConfig();
					recordConfig.seriesId = this.seriesArr.stage[i].stageId;
					let record: data.Record = new data.Record();
					record.sectionId = 0;
					record.stageId = 1;
					recordConfig.record = record;
					model.record.push(recordConfig);
				}
				console.log("初始化的通关记录", model.record);
				//初始化关卡
				this.nowSeriesId = this.seriesArr.stage[0].stageId;
				this.stageArr = RES.getRes(this.seriesArr.stage[0].CnStagePath);
				this.nowStage = this.stageArr.stage[0];
				this.nowSection = this.nowStage.section[0];
			}
			console.log("初始化的关卡数据", this.nowSeriesId, this.nowStage, this.nowSection);
			this.updateSeriesList();
			RES.loadGroup("stage_"+this.nowSeriesId+"_"+this.nowStage.stageId).then(() => {
				this.notifyUI(UiCommand.createScence, { stage: this.nowStage, section: this.nowSection });
				this.loadRes();
			})
		}

		/** 刷新章节列表 */
		private updateSeriesList() {
			this.needSeriesArr = [];
			let record: data.RecordConfig[] = Model.getInstance().record;
			let seriesList: data.NeedSeriesConfig[] = [];
			for (let i: number = 0; i < record.length; i++) {
				for (let j: number = 0; j < this.seriesArr.stageNum; j++) {
					if (record[i].seriesId == this.seriesArr.stage[j].stageId) {
						let series: data.NeedSeriesConfig = new data.NeedSeriesConfig();
						series.stageId = this.seriesArr.stage[j].stageId;
						let stageArr: data.StageArrConfig = RES.getRes(this.seriesArr.stage[i].CnStagePath);
						series.stage = stageArr;
						for (let k: number = 0; k < stageArr.stage.length; k++) {
							series.stage.stage[k].seriesId = this.seriesArr.stage[j].stageId;
							if (stageArr.stage[k].stageId <= record[i].record.stageId) {
								series.stage.stage[k].isLock = false;
							} else if (stageArr.stage[k].stageId > record[i].record.stageId) {
								if (record[i].record.stageId + 1 == stageArr.stage[k].stageId && record[i].record.sectionId == 4) {
									series.stage.stage[k].isLock = false;
								} else {
									series.stage.stage[k].isLock = true;
								}
							} else {
								series.stage.stage[k].isLock = true;
							}
						}
						seriesList.push(series);
					}
				}
			}
			this.needSeriesArr = seriesList;
			console.log("需要显示的系列总表数据", this.needSeriesArr);
			this.notifyUI(UiCommand.initSeriesList, this.needSeriesArr);
		}

		/** 重新推理 */
		private againGame() {
			this.createScence();
		}

		/** 获取日记内容 */
		private getDiary() {
			let record: data.RecordConfig[] = Model.getInstance().record;
			let diary: string = "";
			for (let i: number = 0; i < this.nowStage.section.length; i++) {
				if (this.nowStage.section[i].sectionId <= this.nowSection.sectionId) {
					if (this.nowStage.section[i].sectionId == 1) {
						diary += this.nowStage.section[i].sectionId + ":" + this.nowStage.section[i].sectionName + "\n" + this.nowStage.section[i].question;
					} else {
						diary += "\n\n" + this.nowStage.section[i].sectionId + ":" + this.nowStage.section[i].sectionName + "\n" + this.nowStage.section[i].question;
					}
					if(this.nowSection.sectionId > this.nowStage.section[i].sectionId){
						diary += "\n\n("+this.nowStage.section[i].answer+")";
					}
				}
			}
			this.notifyUI(UiCommand.showDiary, diary);
		}

		/** 刷新已破案数和总关数 */
		private updateCheckNum() {
			let record: data.RecordConfig[] = Model.getInstance().record;
			let max: number = 0;
			let now: number = 0;
			for (let i: number = 0; i < this.seriesArr.stageNum; i++) {
				max += this.seriesArr.stage[i].sectionNum * 4;
			}
			record.forEach(record => {
				now += record.record.stageId * 4 - (4 - record.record.sectionId);
			});
			this.notifyUI(UiCommand.updateCheckNum, { now: now, max: max });
			this.updateSeriesList();
		}

		/** 获取关卡的会话列表 */
		private getStageSectionList(json: { seriesId: number, stageId: number }) {
			this.clickSeriesId = json.seriesId;
			this.clickStageId = json.stageId;
			let needSectionArr: data.NeedSectionConfig[] = [];
			let stageArr: data.StageArrConfig;
			let record: data.RecordConfig[] = Model.getInstance().record;
			for (let i: number = 0; i < this.needSeriesArr.length; i++) {
				if (this.needSeriesArr[i].stageId == json.seriesId) {
					stageArr = this.needSeriesArr[i].stage;
					break;
				}
			}

			for (let i: number = 0; i < record.length; i++) {
				if(record[i].seriesId == json.seriesId)
				{
					for (let j: number = 0; j < stageArr.stage.length; j++) {
						if (json.stageId == stageArr.stage[j].stageId) {
							let index: number = 0;
							for (let k: number = 0; k < stageArr.stage[j].section.length; k++) {
								let needSection: data.NeedSectionConfig = new data.NeedSectionConfig();
								if (index != 0 && stageArr.stage[j].section[index]) {
									needSection.isAdopt = 0;
									index = 0;
								} else {
									if (record[i].record.stageId == json.stageId) {
										if (record[i].record.sectionId > stageArr.stage[j].section[k].sectionId) {
											needSection.isAdopt = 1;
										} else if (record[i].record.sectionId == stageArr.stage[j].section[k].sectionId) {
											needSection.isAdopt = 1;
											index = k + 1;
										} else {
											if(record[i].record.sectionId == 0 && k == 0)
											{
												needSection.isAdopt = 0;
											}else{
												needSection.isAdopt = 2;
											}
										}
									} else if (record[i].record.stageId < json.stageId) {
										if (record[i].record.sectionId == 4 && record[i].record.stageId + 1 == json.stageId && k == 0) {
											needSection.isAdopt = 0;
										} else {
											needSection.isAdopt = 2;
										}
									} else {
										needSection.isAdopt = 1;
									}
								}
								needSection.section = this.needSeriesArr[i].stage.stage[j].section[k];
								needSectionArr.push(needSection);
							}
							console.log("要显示的会话列表", needSectionArr);
							this.notifyUI(UiCommand.showSectionList, needSectionArr);
							break;
						}
					}
					break;
				}
			}
		}

		/** 加入指定会话 */
		private joinAppointSection(sectionId: number) {
			for(let i:number = 0;i< this.needSeriesArr.length;i++)
			{
				if(this.needSeriesArr[i].stageId == this.clickSeriesId)
				{
					this.nowSeriesId = this.clickSeriesId;
					this.stageArr = this.needSeriesArr[i].stage;
					break;
				}
			}
			for(let i:number = 0;i < this.stageArr.stage.length;i++)
			{
				if(this.stageArr.stage[i].stageId == this.clickStageId)
				{
					this.nowStage = this.stageArr.stage[i];
					break;
				}
			}
			for(let i:number = 0;i < this.nowStage.section.length;i++)
			{
				if(sectionId == this.nowStage.section[i].sectionId)
				{
					this.nowSection = this.nowStage.section[i];
					break;
				}
			}
			this.createScence();
		}

		/** 创建场景 */
		private createScence(){
			let img:any = RES.getRes("Stage"+this.nowSeriesId+"_"+this.nowStage.stageId+"_png");
			if(img)
			{
				this.notifyUI(UiCommand.createScence, { stage: this.nowStage, section: this.nowSection });
			}else{
				this.notifyUI(UiCommand.showTip, "资源正在加载中...");
				RES.loadGroup("stage_"+this.nowSeriesId+"_"+this.nowStage.stageId);
			}
		}

		/** 获取关卡列表 */
		private getStageList(jsonData:{seriesId:number,stageData:data.StageArrConfig}) {
			this.clickSeriesId = jsonData.seriesId;
			let needStageConfig:data.NeedStageConfig = new data.NeedStageConfig();
			needStageConfig.seriesId = jsonData.seriesId;
			needStageConfig.stage = jsonData.stageData;
			this.notifyUI(UiCommand.showStageList,needStageConfig);
		}

		/** 保存记录 */
		private saveRecord() {
			let record:data.RecordConfig[] = Model.getInstance().record;
			for(let i:number = 0;i < record.length;i++)
			{
				if(record[i].seriesId == this.nowSeriesId)
				{
					if(record[i].record.stageId == this.nowStage.stageId)
					{
						 if(record[i].record.sectionId < this.nowSection.sectionId)
						 {
							 record[i].record.sectionId = this.nowSection.sectionId;
						 }
					}else if(record[i].record.stageId < this.nowStage.stageId){
						record[i].record.stageId = this.nowStage.stageId;
						record[i].record.sectionId = this.nowSection.sectionId;
					}
					break;
				}
			}
			console.log("保存记录", Model.getInstance().record);
			Model.getInstance().record = record;
			egret.localStorage.setItem(GlobalConfig.Record,JSON.stringify(record));												
			this.notifyUI(UiCommand.initAnswer,this.nowSection);
			console.log("保存记录", Model.getInstance().record);
		}

		/** 下一关 */
		private joinNextStage() {
			if (this.nowSection.sectionId + 1 > 4) {
				for (let i: number = 0; i < this.stageArr.stage.length; i++) {
					if (this.stageArr.stage[i] == this.nowStage && this.stageArr.stage[i + 1]) {
						this.nowStage = this.stageArr.stage[i + 1];
						this.nowSection = this.nowStage.section[0];
						this.createScence();
						break;
					}
				}
			} else {
				for (let i: number = 0; i < this.nowStage.section.length; i++) {
					if (this.nowStage.section[i] == this.nowSection) {
						if (this.nowStage.section[i + 1]) {
							this.nowSection = this.nowStage.section[i + 1];
							this.createScence();
						} else {
							this.nowSection = this.nowStage.section[i];
							let isFinish:boolean = true
							for(let i:number = 0;i < this.needSeriesArr.length;i++)
							{
								if(this.nowSeriesId +1 == this.needSeriesArr[i].stageId)
								{
									isFinish = false;
									this.stageArr = this.needSeriesArr[i].stage;
									this.nowStage = this.stageArr.stage[0];
									this.nowSection = this.nowStage.section[0];
									this.createScence();
									break;
								}
							}
							if(isFinish)
							{
								this.notifyUI(UiCommand.gameClearance);
							}
						}
						break;
					}
				}
			}
		}
	}
}