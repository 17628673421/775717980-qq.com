/** 微信用户信息类 */
class WXManager {
	public constructor() {

	}
	private static _instance: WXManager;

	public static getInstance(): WXManager {
		if (!this._instance) this._instance = new WXManager();
		return this._instance;
	}

	/** 小游戏appid */
	public static appId: string = "wx8da451056e55806f";
	/** 小游戏唯一密匙 */
	public static secret: string = "1dbc2a1314cc6c893b8e60c079eeead1";
	/** 结束广告 */
	public overBanner:any;
	/** 视频广告 */
	public videoBanner:any;
	/** 场景广告 */
	public scenceBanner:any;
	/** 用户的唯一标识 */
	public openId: string;
	/** 本次登录的会话密匙 */
	public session_key: string;
	/** 调用后台接口唯一凭证 */
	public access_token: string;
	/** 用户昵称 */
	public nickName: string;
	/** 头像地址 */
	public avatarUrl: string;
	/** 用户性别 0:未知 1:男 2:女 */
	public gender: number;
	/** 所在城市 */
	public city: string;
	/** 所在省份 */
	public province: string;
	/** 所在国家 */
	public country: string;
	/** 小游戏头像名称 */
	public headPortraitName: string;
}