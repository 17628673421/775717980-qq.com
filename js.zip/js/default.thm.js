var egret = window.egret;window.skins=window.skins||{};
                var __extends = this && this.__extends|| function (d, b) {
                    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
                        function __() {
                            this.constructor = d;
                        }
                    __.prototype = b.prototype;
                    d.prototype = new __();
                };
                window.generateEUI = window.generateEUI||{};
                generateEUI.paths = generateEUI.paths||{};
                generateEUI.styles = undefined;
                generateEUI.skins = {"eui.Button":"resource/eui_skins/ButtonSkin.exml","eui.CheckBox":"resource/eui_skins/CheckBoxSkin.exml","eui.HScrollBar":"resource/eui_skins/HScrollBarSkin.exml","eui.HSlider":"resource/eui_skins/HSliderSkin.exml","eui.Panel":"resource/eui_skins/PanelSkin.exml","eui.TextInput":"resource/eui_skins/TextInputSkin.exml","eui.ProgressBar":"resource/eui_skins/ProgressBarSkin.exml","eui.RadioButton":"resource/eui_skins/RadioButtonSkin.exml","eui.Scroller":"resource/eui_skins/ScrollerSkin.exml","eui.ToggleSwitch":"resource/eui_skins/ToggleSwitchSkin.exml","eui.VScrollBar":"resource/eui_skins/VScrollBarSkin.exml","eui.VSlider":"resource/eui_skins/VSliderSkin.exml","eui.ItemRenderer":"resource/eui_skins/ItemRendererSkin.exml"};generateEUI.paths['resource/eui_skins/ButtonSkin.exml'] = window.skins.ButtonSkin = (function (_super) {
	__extends(ButtonSkin, _super);
	function ButtonSkin() {
		_super.call(this);
		this.skinParts = ["labelDisplay","iconDisplay"];
		
		this.minHeight = 50;
		this.minWidth = 100;
		this.elementsContent = [this._Image1_i(),this.labelDisplay_i(),this.iconDisplay_i()];
		this.states = [
			new eui.State ("up",
				[
				])
			,
			new eui.State ("down",
				[
					new eui.SetProperty("_Image1","source","button_down_png")
				])
			,
			new eui.State ("disabled",
				[
					new eui.SetProperty("_Image1","alpha",0.5)
				])
		];
	}
	var _proto = ButtonSkin.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		this._Image1 = t;
		t.percentHeight = 100;
		t.scale9Grid = new egret.Rectangle(1,3,8,8);
		t.source = "button_up_png";
		t.percentWidth = 100;
		return t;
	};
	_proto.labelDisplay_i = function () {
		var t = new eui.Label();
		this.labelDisplay = t;
		t.bottom = 8;
		t.left = 8;
		t.right = 8;
		t.size = 40;
		t.textAlign = "center";
		t.textColor = 0xFFFFFF;
		t.top = 8;
		t.verticalAlign = "middle";
		return t;
	};
	_proto.iconDisplay_i = function () {
		var t = new eui.Image();
		this.iconDisplay = t;
		t.horizontalCenter = 0;
		t.verticalCenter = 0;
		return t;
	};
	return ButtonSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/CheckBoxSkin.exml'] = window.skins.CheckBoxSkin = (function (_super) {
	__extends(CheckBoxSkin, _super);
	function CheckBoxSkin() {
		_super.call(this);
		this.skinParts = ["labelDisplay"];
		
		this.elementsContent = [this._Group1_i()];
		this.states = [
			new eui.State ("up",
				[
				])
			,
			new eui.State ("down",
				[
					new eui.SetProperty("_Image1","alpha",0.7)
				])
			,
			new eui.State ("disabled",
				[
					new eui.SetProperty("_Image1","alpha",0.5)
				])
			,
			new eui.State ("upAndSelected",
				[
					new eui.SetProperty("_Image1","source","checkbox_select_up_png")
				])
			,
			new eui.State ("downAndSelected",
				[
					new eui.SetProperty("_Image1","source","checkbox_select_down_png")
				])
			,
			new eui.State ("disabledAndSelected",
				[
					new eui.SetProperty("_Image1","source","checkbox_select_disabled_png")
				])
		];
	}
	var _proto = CheckBoxSkin.prototype;

	_proto._Group1_i = function () {
		var t = new eui.Group();
		t.percentHeight = 100;
		t.percentWidth = 100;
		t.layout = this._HorizontalLayout1_i();
		t.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
		return t;
	};
	_proto._HorizontalLayout1_i = function () {
		var t = new eui.HorizontalLayout();
		t.verticalAlign = "middle";
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		this._Image1 = t;
		t.alpha = 1;
		t.fillMode = "scale";
		t.source = "checkbox_unselect_png";
		return t;
	};
	_proto.labelDisplay_i = function () {
		var t = new eui.Label();
		this.labelDisplay = t;
		t.fontFamily = "Tahoma";
		t.size = 20;
		t.textAlign = "center";
		t.textColor = 0x707070;
		t.verticalAlign = "middle";
		return t;
	};
	return CheckBoxSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/HScrollBarSkin.exml'] = window.skins.HScrollBarSkin = (function (_super) {
	__extends(HScrollBarSkin, _super);
	function HScrollBarSkin() {
		_super.call(this);
		this.skinParts = ["thumb"];
		
		this.minHeight = 8;
		this.minWidth = 20;
		this.elementsContent = [this.thumb_i()];
	}
	var _proto = HScrollBarSkin.prototype;

	_proto.thumb_i = function () {
		var t = new eui.Image();
		this.thumb = t;
		t.height = 8;
		t.scale9Grid = new egret.Rectangle(3,3,2,2);
		t.source = "roundthumb_png";
		t.verticalCenter = 0;
		t.width = 30;
		return t;
	};
	return HScrollBarSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/HSliderSkin.exml'] = window.skins.HSliderSkin = (function (_super) {
	__extends(HSliderSkin, _super);
	function HSliderSkin() {
		_super.call(this);
		this.skinParts = ["track","thumb"];
		
		this.minHeight = 8;
		this.minWidth = 20;
		this.elementsContent = [this.track_i(),this.thumb_i()];
	}
	var _proto = HSliderSkin.prototype;

	_proto.track_i = function () {
		var t = new eui.Image();
		this.track = t;
		t.height = 6;
		t.scale9Grid = new egret.Rectangle(1,1,4,4);
		t.source = "track_sb_png";
		t.verticalCenter = 0;
		t.percentWidth = 100;
		return t;
	};
	_proto.thumb_i = function () {
		var t = new eui.Image();
		this.thumb = t;
		t.source = "thumb_png";
		t.verticalCenter = 0;
		return t;
	};
	return HSliderSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/ItemRendererSkin.exml'] = window.skins.ItemRendererSkin = (function (_super) {
	__extends(ItemRendererSkin, _super);
	function ItemRendererSkin() {
		_super.call(this);
		this.skinParts = ["labelDisplay"];
		
		this.minHeight = 50;
		this.minWidth = 100;
		this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
		this.states = [
			new eui.State ("up",
				[
				])
			,
			new eui.State ("down",
				[
					new eui.SetProperty("_Image1","source","button_down_png")
				])
			,
			new eui.State ("disabled",
				[
					new eui.SetProperty("_Image1","alpha",0.5)
				])
		];
		
		eui.Binding.$bindProperties(this, ["hostComponent.data"],[0],this.labelDisplay,"text");
	}
	var _proto = ItemRendererSkin.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		this._Image1 = t;
		t.percentHeight = 100;
		t.scale9Grid = new egret.Rectangle(1,3,8,8);
		t.source = "button_up_png";
		t.percentWidth = 100;
		return t;
	};
	_proto.labelDisplay_i = function () {
		var t = new eui.Label();
		this.labelDisplay = t;
		t.bottom = 8;
		t.fontFamily = "Tahoma";
		t.left = 8;
		t.right = 8;
		t.size = 20;
		t.textAlign = "center";
		t.textColor = 0xFFFFFF;
		t.top = 8;
		t.verticalAlign = "middle";
		return t;
	};
	return ItemRendererSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/PanelSkin.exml'] = window.skins.PanelSkin = (function (_super) {
	__extends(PanelSkin, _super);
	function PanelSkin() {
		_super.call(this);
		this.skinParts = ["titleDisplay","moveArea","closeButton"];
		
		this.minHeight = 230;
		this.minWidth = 450;
		this.elementsContent = [this._Image1_i(),this.moveArea_i(),this.closeButton_i()];
	}
	var _proto = PanelSkin.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.bottom = 0;
		t.left = 0;
		t.right = 0;
		t.scale9Grid = new egret.Rectangle(2,2,12,12);
		t.source = "border_png";
		t.top = 0;
		return t;
	};
	_proto.moveArea_i = function () {
		var t = new eui.Group();
		this.moveArea = t;
		t.height = 45;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		t.elementsContent = [this._Image2_i(),this.titleDisplay_i()];
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		t.bottom = 0;
		t.left = 0;
		t.right = 0;
		t.source = "header_png";
		t.top = 0;
		return t;
	};
	_proto.titleDisplay_i = function () {
		var t = new eui.Label();
		this.titleDisplay = t;
		t.fontFamily = "Tahoma";
		t.left = 15;
		t.right = 5;
		t.size = 20;
		t.textColor = 0xFFFFFF;
		t.verticalCenter = 0;
		t.wordWrap = false;
		return t;
	};
	_proto.closeButton_i = function () {
		var t = new eui.Button();
		this.closeButton = t;
		t.bottom = 5;
		t.horizontalCenter = 0;
		t.label = "close";
		return t;
	};
	return PanelSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/ProgressBarSkin.exml'] = window.skins.ProgressBarSkin = (function (_super) {
	__extends(ProgressBarSkin, _super);
	function ProgressBarSkin() {
		_super.call(this);
		this.skinParts = ["thumb","labelDisplay"];
		
		this.minHeight = 18;
		this.minWidth = 30;
		this.elementsContent = [this._Image1_i(),this.thumb_i(),this.labelDisplay_i()];
	}
	var _proto = ProgressBarSkin.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.percentHeight = 100;
		t.scale9Grid = new egret.Rectangle(1,1,4,4);
		t.source = "track_pb_png";
		t.verticalCenter = 0;
		t.percentWidth = 100;
		return t;
	};
	_proto.thumb_i = function () {
		var t = new eui.Image();
		this.thumb = t;
		t.percentHeight = 100;
		t.source = "thumb_pb_png";
		t.percentWidth = 100;
		return t;
	};
	_proto.labelDisplay_i = function () {
		var t = new eui.Label();
		this.labelDisplay = t;
		t.fontFamily = "Tahoma";
		t.horizontalCenter = 0;
		t.size = 15;
		t.textAlign = "center";
		t.textColor = 0x707070;
		t.verticalAlign = "middle";
		t.verticalCenter = 0;
		return t;
	};
	return ProgressBarSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/RadioButtonSkin.exml'] = window.skins.RadioButtonSkin = (function (_super) {
	__extends(RadioButtonSkin, _super);
	function RadioButtonSkin() {
		_super.call(this);
		this.skinParts = ["labelDisplay"];
		
		this.elementsContent = [this._Group1_i()];
		this.states = [
			new eui.State ("up",
				[
				])
			,
			new eui.State ("down",
				[
					new eui.SetProperty("_Image1","alpha",0.7)
				])
			,
			new eui.State ("disabled",
				[
					new eui.SetProperty("_Image1","alpha",0.5)
				])
			,
			new eui.State ("upAndSelected",
				[
					new eui.SetProperty("_Image1","source","radiobutton_select_up_png")
				])
			,
			new eui.State ("downAndSelected",
				[
					new eui.SetProperty("_Image1","source","radiobutton_select_down_png")
				])
			,
			new eui.State ("disabledAndSelected",
				[
					new eui.SetProperty("_Image1","source","radiobutton_select_disabled_png")
				])
		];
	}
	var _proto = RadioButtonSkin.prototype;

	_proto._Group1_i = function () {
		var t = new eui.Group();
		t.percentHeight = 100;
		t.percentWidth = 100;
		t.layout = this._HorizontalLayout1_i();
		t.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
		return t;
	};
	_proto._HorizontalLayout1_i = function () {
		var t = new eui.HorizontalLayout();
		t.verticalAlign = "middle";
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		this._Image1 = t;
		t.alpha = 1;
		t.fillMode = "scale";
		t.source = "radiobutton_unselect_png";
		return t;
	};
	_proto.labelDisplay_i = function () {
		var t = new eui.Label();
		this.labelDisplay = t;
		t.fontFamily = "Tahoma";
		t.size = 20;
		t.textAlign = "center";
		t.textColor = 0x707070;
		t.verticalAlign = "middle";
		return t;
	};
	return RadioButtonSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/ScrollerSkin.exml'] = window.skins.ScrollerSkin = (function (_super) {
	__extends(ScrollerSkin, _super);
	function ScrollerSkin() {
		_super.call(this);
		this.skinParts = ["horizontalScrollBar","verticalScrollBar"];
		
		this.minHeight = 20;
		this.minWidth = 20;
		this.elementsContent = [this.horizontalScrollBar_i(),this.verticalScrollBar_i()];
	}
	var _proto = ScrollerSkin.prototype;

	_proto.horizontalScrollBar_i = function () {
		var t = new eui.HScrollBar();
		this.horizontalScrollBar = t;
		t.bottom = 0;
		t.percentWidth = 100;
		return t;
	};
	_proto.verticalScrollBar_i = function () {
		var t = new eui.VScrollBar();
		this.verticalScrollBar = t;
		t.percentHeight = 100;
		t.right = 0;
		return t;
	};
	return ScrollerSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/TextInputSkin.exml'] = window.skins.TextInputSkin = (function (_super) {
	__extends(TextInputSkin, _super);
	function TextInputSkin() {
		_super.call(this);
		this.skinParts = ["textDisplay","promptDisplay"];
		
		this.minHeight = 40;
		this.minWidth = 300;
		this.elementsContent = [this._Image1_i(),this._Rect1_i(),this.textDisplay_i()];
		this.promptDisplay_i();
		
		this.states = [
			new eui.State ("normal",
				[
				])
			,
			new eui.State ("disabled",
				[
					new eui.SetProperty("textDisplay","textColor",0xff0000)
				])
			,
			new eui.State ("normalWithPrompt",
				[
					new eui.AddItems("promptDisplay","",1,"")
				])
			,
			new eui.State ("disabledWithPrompt",
				[
					new eui.AddItems("promptDisplay","",1,"")
				])
		];
	}
	var _proto = TextInputSkin.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.percentHeight = 100;
		t.scale9Grid = new egret.Rectangle(1,3,8,8);
		t.source = "button_up_png";
		t.percentWidth = 100;
		return t;
	};
	_proto._Rect1_i = function () {
		var t = new eui.Rect();
		t.fillColor = 0xffffff;
		t.percentHeight = 100;
		t.percentWidth = 100;
		return t;
	};
	_proto.textDisplay_i = function () {
		var t = new eui.EditableText();
		this.textDisplay = t;
		t.height = 24;
		t.left = "10";
		t.right = "10";
		t.size = 20;
		t.textColor = 0x000000;
		t.verticalCenter = "0";
		t.percentWidth = 100;
		return t;
	};
	_proto.promptDisplay_i = function () {
		var t = new eui.Label();
		this.promptDisplay = t;
		t.height = 24;
		t.left = 10;
		t.right = 10;
		t.size = 20;
		t.textColor = 0xa9a9a9;
		t.touchEnabled = false;
		t.verticalCenter = 0;
		t.percentWidth = 100;
		return t;
	};
	return TextInputSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/ToggleSwitchSkin.exml'] = window.skins.ToggleSwitchSkin = (function (_super) {
	__extends(ToggleSwitchSkin, _super);
	function ToggleSwitchSkin() {
		_super.call(this);
		this.skinParts = [];
		
		this.elementsContent = [this._Image1_i(),this._Image2_i()];
		this.states = [
			new eui.State ("up",
				[
					new eui.SetProperty("_Image1","source","off_png")
				])
			,
			new eui.State ("down",
				[
					new eui.SetProperty("_Image1","source","off_png")
				])
			,
			new eui.State ("disabled",
				[
					new eui.SetProperty("_Image1","source","off_png")
				])
			,
			new eui.State ("upAndSelected",
				[
					new eui.SetProperty("_Image2","horizontalCenter",18)
				])
			,
			new eui.State ("downAndSelected",
				[
					new eui.SetProperty("_Image2","horizontalCenter",18)
				])
			,
			new eui.State ("disabledAndSelected",
				[
					new eui.SetProperty("_Image2","horizontalCenter",18)
				])
		];
	}
	var _proto = ToggleSwitchSkin.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		this._Image1 = t;
		t.source = "on_png";
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		this._Image2 = t;
		t.horizontalCenter = -18;
		t.source = "handle_png";
		t.verticalCenter = 0;
		return t;
	};
	return ToggleSwitchSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/VScrollBarSkin.exml'] = window.skins.VScrollBarSkin = (function (_super) {
	__extends(VScrollBarSkin, _super);
	function VScrollBarSkin() {
		_super.call(this);
		this.skinParts = ["thumb"];
		
		this.minHeight = 20;
		this.minWidth = 8;
		this.elementsContent = [this.thumb_i()];
	}
	var _proto = VScrollBarSkin.prototype;

	_proto.thumb_i = function () {
		var t = new eui.Image();
		this.thumb = t;
		t.height = 30;
		t.horizontalCenter = 0;
		t.scale9Grid = new egret.Rectangle(3,3,2,2);
		t.source = "roundthumb_png";
		t.width = 8;
		return t;
	};
	return VScrollBarSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/VSliderSkin.exml'] = window.skins.VSliderSkin = (function (_super) {
	__extends(VSliderSkin, _super);
	function VSliderSkin() {
		_super.call(this);
		this.skinParts = ["track","thumb"];
		
		this.minHeight = 30;
		this.minWidth = 25;
		this.elementsContent = [this.track_i(),this.thumb_i()];
	}
	var _proto = VSliderSkin.prototype;

	_proto.track_i = function () {
		var t = new eui.Image();
		this.track = t;
		t.percentHeight = 100;
		t.horizontalCenter = 0;
		t.scale9Grid = new egret.Rectangle(1,1,4,4);
		t.source = "track_png";
		t.width = 7;
		return t;
	};
	_proto.thumb_i = function () {
		var t = new eui.Image();
		this.thumb = t;
		t.horizontalCenter = 0;
		t.source = "thumb_png";
		return t;
	};
	return VSliderSkin;
})(eui.Skin);generateEUI.paths['resource/skins/GameUISkin.exml'] = window.GameUISkin = (function (_super) {
	__extends(GameUISkin, _super);
	function GameUISkin() {
		_super.call(this);
		this.skinParts = ["grp_game_back","grp_game_tips","grp_game_plot","grp_setting","grp_game_clue","grp_gane_head","grp_game_bg","img_scence","img_target","img_sure","lab_sure","grp_sure","grp_scence","rect_mask","lab_section","lab_question","grp_close","grp_clue","lab_diary","grp_diary_close","grp_diary","grp_video_look","grp_video_close","grp_video","grp_set_close","img_sound","grp_sound","grp_set","lab_tips","grp_tips_close","grp_tips","grp_game","lab_title_id","lab_title_name","grp_titile","lab_result","grp_result_close","grp_result","img_answer","lab_explain","grp_goon_choose","grp_goon_next","grp_goon","lab_over","grp_over_close","grp_over_choose","grp_over_answer","grp_over","lab_num","grp_check_back","list_series","sco_series","list_stage","sco_stage","img_stage_close","grp_stage","lab_section_id_0","lab_section_name_0","grp_section_pass_0","img_section_lock_0","grp_section_0","lab_section_id_1","lab_section_name_1","grp_section_pass_1","img_section_lock_1","grp_section_1","lab_section_id_2","lab_section_name_2","grp_section_pass_2","img_section_lock_2","grp_section_2","lab_section_id_3","lab_section_name_3","grp_section_pass_3","img_section_lock_3","grp_section_3","grp_section","grp_check","grp_start","lab_tip","grp_tip","adaptation"];
		
		this.height = 1920;
		this.width = 1080;
		this.elementsContent = [this.adaptation_i()];
	}
	var _proto = GameUISkin.prototype;

	_proto.adaptation_i = function () {
		var t = new eui.Group();
		this.adaptation = t;
		t.percentHeight = 100;
		t.horizontalCenter = 0;
		t.verticalCenter = 0;
		t.percentWidth = 100;
		t.elementsContent = [this._Rect1_i(),this.grp_game_i(),this.grp_titile_i(),this.grp_result_i(),this.grp_goon_i(),this.grp_over_i(),this.grp_check_i(),this.grp_start_i(),this.grp_tip_i()];
		return t;
	};
	_proto._Rect1_i = function () {
		var t = new eui.Rect();
		t.percentHeight = 100;
		t.horizontalCenter = 0;
		t.verticalCenter = 0;
		t.percentWidth = 100;
		return t;
	};
	_proto.grp_game_i = function () {
		var t = new eui.Group();
		this.grp_game = t;
		t.percentHeight = 100;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.verticalCenter = 0;
		t.percentWidth = 100;
		t.x = 0;
		t.y = 0;
		t.elementsContent = [this.grp_game_bg_i(),this.grp_scence_i(),this.rect_mask_i(),this.grp_clue_i(),this.grp_diary_i(),this.grp_video_i(),this.grp_set_i(),this.grp_tips_i()];
		return t;
	};
	_proto.grp_game_bg_i = function () {
		var t = new eui.Group();
		this.grp_game_bg = t;
		t.horizontalCenter = 0;
		t.verticalCenter = 0;
		t.width = 1080;
		t.elementsContent = [this._Image1_i(),this.grp_gane_head_i()];
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "1_png";
		t.verticalCenter = 0;
		return t;
	};
	_proto.grp_gane_head_i = function () {
		var t = new eui.Group();
		this.grp_gane_head = t;
		t.height = 200;
		t.horizontalCenter = 0;
		t.top = 0;
		t.percentWidth = 100;
		t.layout = this._HorizontalLayout1_i();
		t.elementsContent = [this.grp_game_back_i(),this.grp_game_tips_i(),this.grp_game_plot_i(),this.grp_setting_i(),this.grp_game_clue_i()];
		return t;
	};
	_proto._HorizontalLayout1_i = function () {
		var t = new eui.HorizontalLayout();
		t.gap = 20;
		t.horizontalAlign = "left";
		t.paddingLeft = 20;
		t.verticalAlign = "middle";
		return t;
	};
	_proto.grp_game_back_i = function () {
		var t = new eui.Group();
		this.grp_game_back = t;
		t.verticalCenter = 0;
		t.x = 321;
		t.elementsContent = [this._Rect2_i(),this._Image2_i()];
		return t;
	};
	_proto._Rect2_i = function () {
		var t = new eui.Rect();
		t.fillAlpha = 0.3;
		t.height = 150;
		t.horizontalCenter = 0;
		t.verticalCenter = 0;
		t.width = 150;
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "res_json.UI_Icon_ArrowLeft";
		t.verticalCenter = 0;
		return t;
	};
	_proto.grp_game_tips_i = function () {
		var t = new eui.Group();
		this.grp_game_tips = t;
		t.verticalCenter = 0;
		t.x = 351;
		t.y = 30;
		t.elementsContent = [this._Rect3_i(),this._Image3_i()];
		return t;
	};
	_proto._Rect3_i = function () {
		var t = new eui.Rect();
		t.fillAlpha = 0.3;
		t.height = 160;
		t.horizontalCenter = 0;
		t.verticalCenter = 0;
		t.width = 160;
		return t;
	};
	_proto._Image3_i = function () {
		var t = new eui.Image();
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "res_json.UI_Icon_LightbulbOn";
		t.verticalCenter = 0;
		return t;
	};
	_proto.grp_game_plot_i = function () {
		var t = new eui.Group();
		this.grp_game_plot = t;
		t.verticalCenter = 0;
		t.x = 341;
		t.y = 20;
		t.elementsContent = [this._Rect4_i(),this._Image4_i()];
		return t;
	};
	_proto._Rect4_i = function () {
		var t = new eui.Rect();
		t.fillAlpha = 0.3;
		t.height = 160;
		t.horizontalCenter = 0;
		t.verticalCenter = 0;
		t.width = 160;
		return t;
	};
	_proto._Image4_i = function () {
		var t = new eui.Image();
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "res_json.UI_Icon_Receipt";
		t.verticalCenter = 0;
		return t;
	};
	_proto.grp_setting_i = function () {
		var t = new eui.Group();
		this.grp_setting = t;
		t.verticalCenter = 0;
		t.x = 371;
		t.y = 50;
		t.elementsContent = [this._Rect5_i(),this._Image5_i()];
		return t;
	};
	_proto._Rect5_i = function () {
		var t = new eui.Rect();
		t.fillAlpha = 0.3;
		t.height = 160;
		t.horizontalCenter = 0;
		t.verticalCenter = 0;
		t.width = 160;
		return t;
	};
	_proto._Image5_i = function () {
		var t = new eui.Image();
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "res_json.UI_Icon_Settings";
		t.verticalCenter = 0;
		return t;
	};
	_proto.grp_game_clue_i = function () {
		var t = new eui.Group();
		this.grp_game_clue = t;
		t.verticalCenter = 0;
		t.visible = false;
		t.x = 361;
		t.y = 40;
		t.elementsContent = [this._Rect6_i(),this._Image6_i()];
		return t;
	};
	_proto._Rect6_i = function () {
		var t = new eui.Rect();
		t.fillAlpha = 0.3;
		t.height = 160;
		t.horizontalCenter = 0;
		t.verticalCenter = 0;
		t.width = 160;
		return t;
	};
	_proto._Image6_i = function () {
		var t = new eui.Image();
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "res_json.UI_Icon_Question";
		t.verticalCenter = 0;
		return t;
	};
	_proto.grp_scence_i = function () {
		var t = new eui.Group();
		this.grp_scence = t;
		t.anchorOffsetX = 504;
		t.anchorOffsetY = 672;
		t.scaleX = 1;
		t.scaleY = 1;
		t.touchThrough = true;
		t.x = 540;
		t.y = 860;
		t.elementsContent = [this.img_scence_i(),this.img_target_i(),this.grp_sure_i()];
		return t;
	};
	_proto.img_scence_i = function () {
		var t = new eui.Image();
		this.img_scence = t;
		t.height = 1344;
		t.horizontalCenter = 0;
		t.name = "no";
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "Stage1_1_png";
		t.verticalCenter = 0;
		t.width = 1008;
		return t;
	};
	_proto.img_target_i = function () {
		var t = new eui.Image();
		this.img_target = t;
		t.alpha = 0.8;
		t.anchorOffsetX = 30;
		t.anchorOffsetY = 30;
		t.height = 60;
		t.source = "res_json.badge";
		t.width = 60;
		t.x = 504;
		t.y = 672;
		return t;
	};
	_proto.grp_sure_i = function () {
		var t = new eui.Group();
		this.grp_sure = t;
		t.anchorOffsetX = 320;
		t.anchorOffsetY = 144;
		t.scaleX = 1;
		t.scaleY = 1;
		t.x = 368;
		t.y = 339;
		t.elementsContent = [this.img_sure_i(),this.lab_sure_i()];
		return t;
	};
	_proto.img_sure_i = function () {
		var t = new eui.Image();
		this.img_sure = t;
		t.anchorOffsetX = 160;
		t.anchorOffsetY = 72;
		t.height = 144;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "res_json.btn_ans_frame";
		t.verticalCenter = 0;
		t.width = 320;
		return t;
	};
	_proto.lab_sure_i = function () {
		var t = new eui.Label();
		this.lab_sure = t;
		t.fontFamily = "Microsoft YaHei";
		t.horizontalCenter = 0;
		t.size = 80;
		t.text = "确定";
		t.verticalCenter = -12;
		return t;
	};
	_proto.rect_mask_i = function () {
		var t = new eui.Rect();
		this.rect_mask = t;
		t.fillAlpha = 1;
		t.percentHeight = 75;
		t.horizontalCenter = 0;
		t.name = "no";
		t.touchChildren = true;
		t.touchEnabled = false;
		t.verticalCenter = -100;
		t.percentWidth = 95;
		return t;
	};
	_proto.grp_clue_i = function () {
		var t = new eui.Group();
		this.grp_clue = t;
		t.percentHeight = 100;
		t.horizontalCenter = 0;
		t.verticalCenter = 0;
		t.visible = false;
		t.percentWidth = 100;
		t.elementsContent = [this._Group1_i(),this._Group2_i()];
		return t;
	};
	_proto._Group1_i = function () {
		var t = new eui.Group();
		t.percentHeight = 100;
		t.horizontalCenter = 0;
		t.verticalCenter = 0;
		t.percentWidth = 100;
		t.elementsContent = [this._Rect7_i(),this._Rect8_i(),this._Rect9_i(),this._Rect10_i()];
		return t;
	};
	_proto._Rect7_i = function () {
		var t = new eui.Rect();
		t.fillAlpha = 0.8;
		t.fillColor = 0x000000;
		t.percentHeight = 100;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.verticalCenter = 0;
		t.percentWidth = 100;
		t.x = 118;
		t.y = 394;
		return t;
	};
	_proto._Rect8_i = function () {
		var t = new eui.Rect();
		t.fillColor = 0xffffff;
		t.percentHeight = 60;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.verticalCenter = 0;
		t.percentWidth = 80;
		t.x = 108;
		t.y = 384;
		return t;
	};
	_proto._Rect9_i = function () {
		var t = new eui.Rect();
		t.ellipseWidth = 30;
		t.percentHeight = 58;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.verticalCenter = 0;
		t.percentWidth = 78;
		t.x = 119.00000000000001;
		t.y = 403;
		return t;
	};
	_proto._Rect10_i = function () {
		var t = new eui.Rect();
		t.fillColor = 0xa8a8a8;
		t.percentHeight = 57;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.verticalCenter = 0;
		t.percentWidth = 76;
		t.x = 130;
		t.y = 413.00000000000006;
		return t;
	};
	_proto._Group2_i = function () {
		var t = new eui.Group();
		t.percentHeight = 55;
		t.horizontalCenter = 0;
		t.verticalCenter = 0;
		t.elementsContent = [this.lab_section_i(),this.lab_question_i(),this.grp_close_i()];
		return t;
	};
	_proto.lab_section_i = function () {
		var t = new eui.Label();
		this.lab_section = t;
		t.fontFamily = "Microsoft YaHei";
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.size = 60;
		t.text = "1.一个人的怀疑";
		t.top = 10;
		t.x = -105;
		return t;
	};
	_proto.lab_question_i = function () {
		var t = new eui.Label();
		this.lab_question = t;
		t.fontFamily = "Microsoft YaHei";
		t.height = 784;
		t.horizontalCenter = 0;
		t.lineSpacing = 10;
		t.scaleX = 1;
		t.scaleY = 1;
		t.size = 50;
		t.text = "但是反对杀戮空间反倒是离开房间都是六块腹肌多斯拉克房间都是的设计费列举了开发金额分为弗兰克聚隆科技弗兰克";
		t.top = 100;
		t.width = 750;
		t.x = -275;
		return t;
	};
	_proto.grp_close_i = function () {
		var t = new eui.Group();
		this.grp_close = t;
		t.bottom = 0;
		t.horizontalCenter = 0;
		t.elementsContent = [this._Image7_i(),this._Label1_i()];
		return t;
	};
	_proto._Image7_i = function () {
		var t = new eui.Image();
		t.bottom = 0;
		t.height = 150;
		t.horizontalCenter = 0;
		t.scale9Grid = new egret.Rectangle(62,23,372,140);
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "res_json.btn2";
		t.x = -216;
		t.y = 238;
		return t;
	};
	_proto._Label1_i = function () {
		var t = new eui.Label();
		t.fontFamily = "Microsoft YaHei";
		t.horizontalCenter = 0;
		t.size = 70;
		t.text = "关闭";
		t.verticalCenter = 0;
		return t;
	};
	_proto.grp_diary_i = function () {
		var t = new eui.Group();
		this.grp_diary = t;
		t.percentHeight = 100;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.verticalCenter = 0;
		t.visible = false;
		t.percentWidth = 100;
		t.elementsContent = [this._Group4_i(),this.grp_diary_close_i()];
		return t;
	};
	_proto._Group4_i = function () {
		var t = new eui.Group();
		t.percentHeight = 100;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.top = 0;
		t.percentWidth = 100;
		t.x = 0;
		t.elementsContent = [this._Rect11_i(),this._Rect12_i(),this._Rect13_i(),this._Rect14_i(),this._Scroller1_i()];
		return t;
	};
	_proto._Rect11_i = function () {
		var t = new eui.Rect();
		t.fillAlpha = 0.8;
		t.fillColor = 0x000000;
		t.percentHeight = 100;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.verticalCenter = 0;
		t.percentWidth = 100;
		t.x = 108;
		t.y = 384;
		return t;
	};
	_proto._Rect12_i = function () {
		var t = new eui.Rect();
		t.fillColor = 0xFFFFFF;
		t.percentHeight = 80;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.verticalCenter = 0;
		t.percentWidth = 95;
		t.x = 118;
		t.y = 394;
		return t;
	};
	_proto._Rect13_i = function () {
		var t = new eui.Rect();
		t.ellipseWidth = 30;
		t.percentHeight = 78;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.verticalCenter = 0;
		t.percentWidth = 92;
		t.x = 119.00000000000001;
		t.y = 403;
		return t;
	};
	_proto._Rect14_i = function () {
		var t = new eui.Rect();
		t.fillColor = 0x1c1b1b;
		t.percentHeight = 76;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.verticalCenter = 0;
		t.percentWidth = 90;
		t.x = 130;
		t.y = 413.00000000000006;
		return t;
	};
	_proto._Scroller1_i = function () {
		var t = new eui.Scroller();
		t.percentHeight = 50;
		t.horizontalCenter = 0;
		t.top = 300;
		t.percentWidth = 80;
		t.viewport = this._Group3_i();
		return t;
	};
	_proto._Group3_i = function () {
		var t = new eui.Group();
		t.elementsContent = [this.lab_diary_i()];
		return t;
	};
	_proto.lab_diary_i = function () {
		var t = new eui.Label();
		this.lab_diary = t;
		t.fontFamily = "Microsoft YaHei";
		t.horizontalCenter = 0;
		t.size = 50;
		t.text = "1:发呆";
		t.textAlign = "left";
		t.top = 0;
		t.percentWidth = 100;
		return t;
	};
	_proto.grp_diary_close_i = function () {
		var t = new eui.Group();
		this.grp_diary_close = t;
		t.bottom = 380;
		t.height = 167;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.x = 292;
		t.elementsContent = [this._Image8_i(),this._Label2_i()];
		return t;
	};
	_proto._Image8_i = function () {
		var t = new eui.Image();
		t.height = 161;
		t.horizontalCenter = 0;
		t.source = "res_json.btn2";
		t.verticalCenter = 0;
		return t;
	};
	_proto._Label2_i = function () {
		var t = new eui.Label();
		t.fontFamily = "Microsoft YaHei";
		t.horizontalCenter = 0;
		t.size = 80;
		t.text = "关闭";
		t.verticalCenter = 0;
		return t;
	};
	_proto.grp_video_i = function () {
		var t = new eui.Group();
		this.grp_video = t;
		t.percentHeight = 100;
		t.horizontalCenter = 0;
		t.verticalCenter = 0;
		t.visible = false;
		t.percentWidth = 100;
		t.elementsContent = [this._Rect15_i(),this._Group5_i()];
		return t;
	};
	_proto._Rect15_i = function () {
		var t = new eui.Rect();
		t.fillAlpha = 0.8;
		t.fillColor = 0x000000;
		t.percentHeight = 100;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.verticalCenter = 0;
		t.percentWidth = 100;
		t.x = 118;
		t.y = 394;
		return t;
	};
	_proto._Group5_i = function () {
		var t = new eui.Group();
		t.percentHeight = 30;
		t.horizontalCenter = 0;
		t.verticalCenter = 0;
		t.percentWidth = 80;
		t.elementsContent = [this._Rect16_i(),this._Rect17_i(),this._Rect18_i(),this._Label3_i(),this.grp_video_look_i(),this.grp_video_close_i()];
		return t;
	};
	_proto._Rect16_i = function () {
		var t = new eui.Rect();
		t.percentHeight = 100;
		t.horizontalCenter = 0;
		t.verticalCenter = 0;
		t.percentWidth = 100;
		return t;
	};
	_proto._Rect17_i = function () {
		var t = new eui.Rect();
		t.fillColor = 0x474747;
		t.percentHeight = 98;
		t.horizontalCenter = 0;
		t.verticalCenter = 0;
		t.percentWidth = 98;
		t.x = 10;
		t.y = 10;
		return t;
	};
	_proto._Rect18_i = function () {
		var t = new eui.Rect();
		t.fillColor = 0x211f1f;
		t.percentHeight = 96;
		t.horizontalCenter = 0;
		t.verticalCenter = 0;
		t.percentWidth = 96;
		t.x = 20;
		t.y = 20;
		return t;
	};
	_proto._Label3_i = function () {
		var t = new eui.Label();
		t.fontFamily = "Microsoft YaHei";
		t.horizontalCenter = 0;
		t.size = 50;
		t.text = "看视频获得提示";
		t.top = 100;
		return t;
	};
	_proto.grp_video_look_i = function () {
		var t = new eui.Group();
		this.grp_video_look = t;
		t.horizontalCenter = 0;
		t.name = "1";
		t.scaleX = 1;
		t.scaleY = 1;
		t.verticalCenter = 0;
		t.x = 184;
		t.elementsContent = [this._Image9_i(),this._Label4_i()];
		return t;
	};
	_proto._Image9_i = function () {
		var t = new eui.Image();
		t.height = 140;
		t.horizontalCenter = 0;
		t.source = "res_json.btn3";
		t.verticalCenter = 0;
		return t;
	};
	_proto._Label4_i = function () {
		var t = new eui.Label();
		t.fontFamily = "Microsoft YaHei";
		t.horizontalCenter = 0;
		t.size = 40;
		t.text = "接受提示";
		t.verticalCenter = 0;
		return t;
	};
	_proto.grp_video_close_i = function () {
		var t = new eui.Group();
		this.grp_video_close = t;
		t.bottom = 50;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.x = 194;
		t.elementsContent = [this._Image10_i(),this._Label5_i()];
		return t;
	};
	_proto._Image10_i = function () {
		var t = new eui.Image();
		t.height = 140;
		t.horizontalCenter = 0;
		t.source = "res_json.btn1";
		t.verticalCenter = 0;
		return t;
	};
	_proto._Label5_i = function () {
		var t = new eui.Label();
		t.fontFamily = "Microsoft YaHei";
		t.horizontalCenter = 0;
		t.size = 40;
		t.text = "关闭";
		t.verticalCenter = 0;
		return t;
	};
	_proto.grp_set_i = function () {
		var t = new eui.Group();
		this.grp_set = t;
		t.percentHeight = 100;
		t.horizontalCenter = 0;
		t.verticalCenter = 0;
		t.visible = false;
		t.percentWidth = 100;
		t.elementsContent = [this._Rect19_i(),this._Group6_i()];
		return t;
	};
	_proto._Rect19_i = function () {
		var t = new eui.Rect();
		t.fillAlpha = 0.8;
		t.fillColor = 0x000000;
		t.percentHeight = 100;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.verticalCenter = 0;
		t.percentWidth = 100;
		t.x = 128;
		t.y = 404;
		return t;
	};
	_proto._Group6_i = function () {
		var t = new eui.Group();
		t.percentHeight = 50;
		t.horizontalCenter = 0;
		t.verticalCenter = 0;
		t.percentWidth = 80;
		t.elementsContent = [this._Rect20_i(),this._Rect21_i(),this._Label6_i(),this.grp_set_close_i(),this.grp_sound_i()];
		return t;
	};
	_proto._Rect20_i = function () {
		var t = new eui.Rect();
		t.ellipseWidth = 50;
		t.percentHeight = 100;
		t.horizontalCenter = 0;
		t.verticalCenter = 0;
		t.percentWidth = 100;
		return t;
	};
	_proto._Rect21_i = function () {
		var t = new eui.Rect();
		t.fillColor = 0x3d3b3b;
		t.percentHeight = 96;
		t.horizontalCenter = 0;
		t.verticalCenter = 0;
		t.percentWidth = 96;
		t.x = 10;
		t.y = 10;
		return t;
	};
	_proto._Label6_i = function () {
		var t = new eui.Label();
		t.fontFamily = "Microsoft YaHei";
		t.horizontalCenter = 0;
		t.size = 80;
		t.text = "设置";
		t.top = 50;
		return t;
	};
	_proto.grp_set_close_i = function () {
		var t = new eui.Group();
		this.grp_set_close = t;
		t.bottom = 100;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.x = 184;
		t.y = 893;
		t.elementsContent = [this._Image11_i(),this._Label7_i()];
		return t;
	};
	_proto._Image11_i = function () {
		var t = new eui.Image();
		t.height = 119;
		t.horizontalCenter = 0;
		t.source = "res_json.btn2";
		t.verticalCenter = 0;
		t.width = 460;
		return t;
	};
	_proto._Label7_i = function () {
		var t = new eui.Label();
		t.fontFamily = "Microsoft YaHei";
		t.horizontalCenter = 0;
		t.size = 60;
		t.text = "关闭";
		t.verticalCenter = 0;
		return t;
	};
	_proto.grp_sound_i = function () {
		var t = new eui.Group();
		this.grp_sound = t;
		t.height = 200;
		t.horizontalCenter = 0;
		t.verticalCenter = 0;
		t.width = 200;
		t.elementsContent = [this._Rect22_i(),this._Rect23_i(),this.img_sound_i()];
		return t;
	};
	_proto._Rect22_i = function () {
		var t = new eui.Rect();
		t.fillColor = 0xffffff;
		t.percentHeight = 100;
		t.horizontalCenter = 0;
		t.verticalCenter = 0;
		t.percentWidth = 100;
		return t;
	};
	_proto._Rect23_i = function () {
		var t = new eui.Rect();
		t.fillColor = 0x514d4d;
		t.percentHeight = 96;
		t.horizontalCenter = 0;
		t.verticalCenter = 0;
		t.percentWidth = 96;
		t.x = 10;
		t.y = 10;
		return t;
	};
	_proto.img_sound_i = function () {
		var t = new eui.Image();
		this.img_sound = t;
		t.horizontalCenter = 0;
		t.name = "on";
		t.source = "res_json.btn_music_on";
		t.verticalCenter = 0;
		return t;
	};
	_proto.grp_tips_i = function () {
		var t = new eui.Group();
		this.grp_tips = t;
		t.percentHeight = 100;
		t.horizontalCenter = 0;
		t.verticalCenter = 0;
		t.visible = false;
		t.percentWidth = 100;
		t.elementsContent = [this._Rect24_i(),this._Group7_i()];
		return t;
	};
	_proto._Rect24_i = function () {
		var t = new eui.Rect();
		t.fillAlpha = 0.8;
		t.percentHeight = 100;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.verticalCenter = 0;
		t.percentWidth = 100;
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto._Group7_i = function () {
		var t = new eui.Group();
		t.percentHeight = 50;
		t.horizontalCenter = 0;
		t.verticalCenter = 0;
		t.percentWidth = 80;
		t.elementsContent = [this._Rect25_i(),this._Label8_i(),this.lab_tips_i(),this.grp_tips_close_i()];
		return t;
	};
	_proto._Rect25_i = function () {
		var t = new eui.Rect();
		t.fillColor = 0x494949;
		t.percentHeight = 100;
		t.horizontalCenter = 0;
		t.strokeColor = 0xffffff;
		t.strokeWeight = 5;
		t.verticalCenter = 0;
		t.percentWidth = 100;
		return t;
	};
	_proto._Label8_i = function () {
		var t = new eui.Label();
		t.fontFamily = "Microsoft YaHei";
		t.horizontalCenter = 0;
		t.size = 60;
		t.text = "提示";
		t.top = 20;
		return t;
	};
	_proto.lab_tips_i = function () {
		var t = new eui.Label();
		this.lab_tips = t;
		t.fontFamily = "Microsoft YaHei";
		t.horizontalCenter = 0;
		t.size = 50;
		t.text = "垃圾桶里的电影票";
		t.top = 220;
		t.percentWidth = 80;
		return t;
	};
	_proto.grp_tips_close_i = function () {
		var t = new eui.Group();
		this.grp_tips_close = t;
		t.bottom = 150;
		t.percentHeight = 15;
		t.horizontalCenter = 0;
		t.percentWidth = 40;
		t.elementsContent = [this._Rect26_i(),this._Label9_i()];
		return t;
	};
	_proto._Rect26_i = function () {
		var t = new eui.Rect();
		t.fillColor = 0x004b59;
		t.percentHeight = 100;
		t.horizontalCenter = 0;
		t.strokeColor = 0xffffff;
		t.strokeWeight = 5;
		t.verticalCenter = 0;
		t.percentWidth = 100;
		return t;
	};
	_proto._Label9_i = function () {
		var t = new eui.Label();
		t.fontFamily = "Microsoft YaHei";
		t.horizontalCenter = 0;
		t.size = 50;
		t.text = "关闭";
		t.verticalCenter = 0;
		return t;
	};
	_proto.grp_titile_i = function () {
		var t = new eui.Group();
		this.grp_titile = t;
		t.percentHeight = 100;
		t.horizontalCenter = 0;
		t.verticalCenter = 0;
		t.visible = false;
		t.percentWidth = 100;
		t.elementsContent = [this._Rect27_i(),this._Label10_i(),this._Group8_i()];
		return t;
	};
	_proto._Rect27_i = function () {
		var t = new eui.Rect();
		t.percentHeight = 100;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.verticalCenter = 0;
		t.percentWidth = 100;
		return t;
	};
	_proto._Label10_i = function () {
		var t = new eui.Label();
		t.fontFamily = "Microsoft YaHei";
		t.horizontalCenter = 0;
		t.size = 50;
		t.text = "侦探大作战";
		t.top = 200;
		return t;
	};
	_proto._Group8_i = function () {
		var t = new eui.Group();
		t.height = 200;
		t.horizontalCenter = 0;
		t.top = 350;
		t.percentWidth = 80;
		t.elementsContent = [this._Image12_i(),this.lab_title_id_i(),this.lab_title_name_i()];
		return t;
	};
	_proto._Image12_i = function () {
		var t = new eui.Image();
		t.percentHeight = 100;
		t.horizontalCenter = 0;
		t.source = "res_json.btn3";
		t.verticalCenter = 0;
		t.percentWidth = 100;
		return t;
	};
	_proto.lab_title_id_i = function () {
		var t = new eui.Label();
		this.lab_title_id = t;
		t.fontFamily = "Microsoft YaHei";
		t.left = 50;
		t.size = 40;
		t.text = "日记.1";
		t.top = 30;
		return t;
	};
	_proto.lab_title_name_i = function () {
		var t = new eui.Label();
		this.lab_title_name = t;
		t.fontFamily = "Microsoft YaHei";
		t.left = 100;
		t.size = 45;
		t.text = "回家的诱惑";
		t.verticalCenter = 0;
		return t;
	};
	_proto.grp_result_i = function () {
		var t = new eui.Group();
		this.grp_result = t;
		t.percentHeight = 100;
		t.horizontalCenter = 0;
		t.verticalCenter = 0;
		t.visible = false;
		t.percentWidth = 100;
		t.elementsContent = [this._Rect28_i(),this.lab_result_i(),this.grp_result_close_i()];
		return t;
	};
	_proto._Rect28_i = function () {
		var t = new eui.Rect();
		t.fillColor = 0x494949;
		t.height = 1920;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.verticalCenter = 0;
		t.width = 1080;
		return t;
	};
	_proto.lab_result_i = function () {
		var t = new eui.Label();
		this.lab_result = t;
		t.fontFamily = "Microsoft YaHei";
		t.horizontalCenter = 0;
		t.size = 105;
		t.text = "不正确";
		t.top = 300;
		return t;
	};
	_proto.grp_result_close_i = function () {
		var t = new eui.Group();
		this.grp_result_close = t;
		t.height = 167;
		t.horizontalCenter = 0;
		t.verticalCenter = 0;
		t.elementsContent = [this._Image13_i(),this._Label11_i()];
		return t;
	};
	_proto._Image13_i = function () {
		var t = new eui.Image();
		t.height = 161;
		t.horizontalCenter = 0;
		t.source = "res_json.btn2";
		t.verticalCenter = 0;
		return t;
	};
	_proto._Label11_i = function () {
		var t = new eui.Label();
		t.fontFamily = "Microsoft YaHei";
		t.horizontalCenter = 0;
		t.size = 80;
		t.text = "关闭";
		t.verticalCenter = 0;
		return t;
	};
	_proto.grp_goon_i = function () {
		var t = new eui.Group();
		this.grp_goon = t;
		t.height = 1920;
		t.horizontalCenter = 0;
		t.verticalCenter = 0;
		t.visible = false;
		t.percentWidth = 100;
		t.elementsContent = [this._Rect29_i(),this.img_answer_i(),this._Label12_i(),this.lab_explain_i(),this._Group11_i()];
		return t;
	};
	_proto._Rect29_i = function () {
		var t = new eui.Rect();
		t.fillColor = 0xffffff;
		t.percentHeight = 100;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.verticalCenter = 0;
		t.percentWidth = 100;
		return t;
	};
	_proto.img_answer_i = function () {
		var t = new eui.Image();
		this.img_answer = t;
		t.height = 300;
		t.horizontalCenter = 0;
		t.source = "";
		t.top = 100;
		t.width = 300;
		return t;
	};
	_proto._Label12_i = function () {
		var t = new eui.Label();
		t.fontFamily = "Microsoft YaHei";
		t.horizontalCenter = 0;
		t.size = 50;
		t.text = "解说";
		t.textColor = 0x000000;
		t.top = 450;
		return t;
	};
	_proto.lab_explain_i = function () {
		var t = new eui.Label();
		this.lab_explain = t;
		t.fontFamily = "Microsoft YaHei";
		t.horizontalCenter = 0;
		t.lineSpacing = 10;
		t.size = 45;
		t.text = "放狗梵蒂冈电饭锅假道伐虢了发动机梵蒂梵蒂冈梵蒂冈梵蒂冈发呆施工方道森股份道森股份道森股份打三个富商大贾冈梵蒂冈梵蒂冈发呆";
		t.textColor = 0x000000;
		t.top = 550;
		t.percentWidth = 80;
		return t;
	};
	_proto._Group11_i = function () {
		var t = new eui.Group();
		t.bottom = 500;
		t.horizontalCenter = 0;
		t.layout = this._HorizontalLayout2_i();
		t.elementsContent = [this.grp_goon_choose_i(),this.grp_goon_next_i()];
		return t;
	};
	_proto._HorizontalLayout2_i = function () {
		var t = new eui.HorizontalLayout();
		t.gap = 80;
		return t;
	};
	_proto.grp_goon_choose_i = function () {
		var t = new eui.Group();
		this.grp_goon_choose = t;
		t.x = 56;
		t.y = 82;
		t.elementsContent = [this._Image14_i(),this._Group9_i()];
		return t;
	};
	_proto._Image14_i = function () {
		var t = new eui.Image();
		t.height = 220;
		t.horizontalCenter = 0;
		t.source = "res_json.btn1";
		t.verticalCenter = 0;
		t.width = 300;
		return t;
	};
	_proto._Group9_i = function () {
		var t = new eui.Group();
		t.horizontalCenter = 0;
		t.verticalCenter = 0;
		t.layout = this._VerticalLayout1_i();
		t.elementsContent = [this._Image15_i(),this._Label13_i()];
		return t;
	};
	_proto._VerticalLayout1_i = function () {
		var t = new eui.VerticalLayout();
		t.horizontalAlign = "center";
		return t;
	};
	_proto._Image15_i = function () {
		var t = new eui.Image();
		t.source = "res_json.icon_theme13_3";
		t.x = 18;
		t.y = 38;
		return t;
	};
	_proto._Label13_i = function () {
		var t = new eui.Label();
		t.fontFamily = "Microsoft YaHei";
		t.size = 35;
		t.text = "选择关卡";
		t.x = 42;
		t.y = 66;
		return t;
	};
	_proto.grp_goon_next_i = function () {
		var t = new eui.Group();
		this.grp_goon_next = t;
		t.x = 66;
		t.y = 92;
		t.elementsContent = [this._Image16_i(),this._Group10_i()];
		return t;
	};
	_proto._Image16_i = function () {
		var t = new eui.Image();
		t.height = 220;
		t.horizontalCenter = 0;
		t.source = "res_json.btn2";
		t.verticalCenter = 0;
		t.width = 300;
		return t;
	};
	_proto._Group10_i = function () {
		var t = new eui.Group();
		t.horizontalCenter = 0;
		t.verticalCenter = 0;
		t.layout = this._VerticalLayout2_i();
		t.elementsContent = [this._Image17_i(),this._Label14_i()];
		return t;
	};
	_proto._VerticalLayout2_i = function () {
		var t = new eui.VerticalLayout();
		t.horizontalAlign = "center";
		return t;
	};
	_proto._Image17_i = function () {
		var t = new eui.Image();
		t.source = "res_json.icon_theme13_38";
		t.x = 18;
		t.y = 38;
		return t;
	};
	_proto._Label14_i = function () {
		var t = new eui.Label();
		t.fontFamily = "Microsoft YaHei";
		t.size = 35;
		t.text = "下一关";
		t.x = 42;
		t.y = 66;
		return t;
	};
	_proto.grp_over_i = function () {
		var t = new eui.Group();
		this.grp_over = t;
		t.horizontalCenter = 0;
		t.verticalCenter = 0;
		t.visible = false;
		t.elementsContent = [this._Rect30_i(),this.lab_over_i(),this._Group15_i()];
		return t;
	};
	_proto._Rect30_i = function () {
		var t = new eui.Rect();
		t.fillColor = 0x494949;
		t.height = 1920;
		t.horizontalCenter = 0;
		t.verticalCenter = 0;
		t.width = 1080;
		return t;
	};
	_proto.lab_over_i = function () {
		var t = new eui.Label();
		this.lab_over = t;
		t.fontFamily = "Microsoft YaHei";
		t.left = 300;
		t.size = 60;
		t.text = "有点儿难吗？";
		t.top = 150;
		return t;
	};
	_proto._Group15_i = function () {
		var t = new eui.Group();
		t.horizontalCenter = 0;
		t.verticalCenter = 0;
		t.percentWidth = 100;
		t.layout = this._VerticalLayout3_i();
		t.elementsContent = [this.grp_over_close_i(),this._Group14_i()];
		return t;
	};
	_proto._VerticalLayout3_i = function () {
		var t = new eui.VerticalLayout();
		t.gap = 200;
		t.horizontalAlign = "center";
		t.verticalAlign = "bottom";
		return t;
	};
	_proto.grp_over_close_i = function () {
		var t = new eui.Group();
		this.grp_over_close = t;
		t.height = 167;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.verticalCenter = 0;
		t.percentWidth = 50;
		t.x = -151;
		t.y = 141;
		t.elementsContent = [this._Image18_i(),this._Label15_i()];
		return t;
	};
	_proto._Image18_i = function () {
		var t = new eui.Image();
		t.percentHeight = 100;
		t.horizontalCenter = 0;
		t.source = "res_json.btn2";
		t.verticalCenter = 0;
		t.percentWidth = 100;
		return t;
	};
	_proto._Label15_i = function () {
		var t = new eui.Label();
		t.fontFamily = "Microsoft YaHei";
		t.horizontalCenter = 0;
		t.size = 80;
		t.text = "再次推理";
		t.verticalCenter = 0;
		return t;
	};
	_proto._Group14_i = function () {
		var t = new eui.Group();
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.verticalCenter = 200;
		t.x = -394;
		t.y = 348.9999999999999;
		t.layout = this._HorizontalLayout5_i();
		t.elementsContent = [this.grp_over_choose_i(),this.grp_over_answer_i()];
		return t;
	};
	_proto._HorizontalLayout5_i = function () {
		var t = new eui.HorizontalLayout();
		t.gap = 40;
		t.verticalAlign = "middle";
		return t;
	};
	_proto.grp_over_choose_i = function () {
		var t = new eui.Group();
		this.grp_over_choose = t;
		t.height = 150;
		t.horizontalCenter = 200;
		t.scaleX = 1;
		t.scaleY = 1;
		t.verticalCenter = 300;
		t.x = 130;
		t.y = 427;
		t.elementsContent = [this._Image19_i(),this._Group12_i()];
		return t;
	};
	_proto._Image19_i = function () {
		var t = new eui.Image();
		t.percentHeight = 100;
		t.horizontalCenter = 3;
		t.source = "res_json.btn1";
		t.verticalCenter = 0;
		t.percentWidth = 100;
		return t;
	};
	_proto._Group12_i = function () {
		var t = new eui.Group();
		t.horizontalCenter = 0;
		t.verticalCenter = 0;
		t.layout = this._HorizontalLayout3_i();
		t.elementsContent = [this._Label16_i()];
		return t;
	};
	_proto._HorizontalLayout3_i = function () {
		var t = new eui.HorizontalLayout();
		t.verticalAlign = "middle";
		return t;
	};
	_proto._Label16_i = function () {
		var t = new eui.Label();
		t.fontFamily = "Microsoft YaHei";
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.size = 60;
		t.text = "选择关卡";
		t.verticalCenter = 0;
		t.x = -123;
		t.y = 5.999999999999773;
		return t;
	};
	_proto.grp_over_answer_i = function () {
		var t = new eui.Group();
		this.grp_over_answer = t;
		t.height = 150;
		t.horizontalCenter = -200;
		t.name = "2";
		t.scaleX = 1;
		t.scaleY = 1;
		t.verticalCenter = 300;
		t.x = -270;
		t.y = 427;
		t.elementsContent = [this._Image20_i(),this._Group13_i()];
		return t;
	};
	_proto._Image20_i = function () {
		var t = new eui.Image();
		t.percentHeight = 100;
		t.horizontalCenter = 3;
		t.source = "res_json.btn1";
		t.verticalCenter = 0;
		t.percentWidth = 100;
		return t;
	};
	_proto._Group13_i = function () {
		var t = new eui.Group();
		t.horizontalCenter = 0;
		t.verticalCenter = 0;
		t.layout = this._HorizontalLayout4_i();
		t.elementsContent = [this._Label17_i()];
		return t;
	};
	_proto._HorizontalLayout4_i = function () {
		var t = new eui.HorizontalLayout();
		t.verticalAlign = "middle";
		return t;
	};
	_proto._Label17_i = function () {
		var t = new eui.Label();
		t.fontFamily = "Microsoft YaHei";
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.size = 60;
		t.text = "看广告获得答案";
		t.verticalCenter = 0;
		t.x = -123;
		t.y = 5.999999999999773;
		return t;
	};
	_proto.grp_check_i = function () {
		var t = new eui.Group();
		this.grp_check = t;
		t.percentHeight = 100;
		t.horizontalCenter = 0;
		t.verticalCenter = 0;
		t.visible = false;
		t.percentWidth = 100;
		t.elementsContent = [this._Group18_i(),this.sco_series_i(),this.grp_stage_i(),this.grp_section_i()];
		return t;
	};
	_proto._Group18_i = function () {
		var t = new eui.Group();
		t.horizontalCenter = 0;
		t.verticalCenter = 0;
		t.elementsContent = [this._Rect31_i(),this._Group17_i(),this.grp_check_back_i()];
		return t;
	};
	_proto._Rect31_i = function () {
		var t = new eui.Rect();
		t.fillColor = 0x4db9d5;
		t.height = 1920;
		t.horizontalCenter = 0;
		t.verticalCenter = 0;
		t.width = 1080;
		return t;
	};
	_proto._Group17_i = function () {
		var t = new eui.Group();
		t.percentHeight = 5;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.top = 50;
		t.percentWidth = 30;
		t.x = 558;
		t.y = 50;
		t.elementsContent = [this._Rect32_i(),this._Group16_i()];
		return t;
	};
	_proto._Rect32_i = function () {
		var t = new eui.Rect();
		t.fillAlpha = 0.7;
		t.percentHeight = 100;
		t.horizontalCenter = 0;
		t.verticalCenter = 0;
		t.percentWidth = 100;
		return t;
	};
	_proto._Group16_i = function () {
		var t = new eui.Group();
		t.horizontalCenter = 0;
		t.verticalCenter = 0;
		t.layout = this._HorizontalLayout6_i();
		t.elementsContent = [this._Label18_i(),this.lab_num_i()];
		return t;
	};
	_proto._HorizontalLayout6_i = function () {
		var t = new eui.HorizontalLayout();
		t.gap = 50;
		t.verticalAlign = "middle";
		return t;
	};
	_proto._Label18_i = function () {
		var t = new eui.Label();
		t.fontFamily = "Microsoft YaHei";
		t.size = 40;
		t.text = "破案数";
		t.x = 55;
		t.y = 132;
		return t;
	};
	_proto.lab_num_i = function () {
		var t = new eui.Label();
		this.lab_num = t;
		t.fontFamily = "Microsoft YaHei";
		t.size = 40;
		t.text = "10/80";
		t.x = 65;
		t.y = 142;
		return t;
	};
	_proto.grp_check_back_i = function () {
		var t = new eui.Group();
		this.grp_check_back = t;
		t.left = 100;
		t.scaleX = 1;
		t.scaleY = 1;
		t.top = 50;
		t.x = 230;
		t.y = 50;
		t.elementsContent = [this._Rect33_i(),this._Image21_i()];
		return t;
	};
	_proto._Rect33_i = function () {
		var t = new eui.Rect();
		t.fillAlpha = 0.7;
		t.percentHeight = 100;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.verticalCenter = 0;
		t.percentWidth = 100;
		t.x = 328;
		t.y = 0;
		return t;
	};
	_proto._Image21_i = function () {
		var t = new eui.Image();
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "res_json.UI_Icon_ArrowLeft";
		t.verticalCenter = 0;
		return t;
	};
	_proto.sco_series_i = function () {
		var t = new eui.Scroller();
		this.sco_series = t;
		t.height = 1344;
		t.horizontalCenter = 0;
		t.verticalCenter = 0;
		t.visible = false;
		t.percentWidth = 100;
		t.viewport = this._Group19_i();
		return t;
	};
	_proto._Group19_i = function () {
		var t = new eui.Group();
		t.elementsContent = [this.list_series_i()];
		return t;
	};
	_proto.list_series_i = function () {
		var t = new eui.List();
		this.list_series = t;
		t.horizontalCenter = 0;
		t.top = 0;
		t.percentWidth = 80;
		return t;
	};
	_proto.grp_stage_i = function () {
		var t = new eui.Group();
		this.grp_stage = t;
		t.horizontalCenter = 0;
		t.verticalCenter = 110;
		t.visible = false;
		t.percentWidth = 100;
		t.elementsContent = [this._Rect34_i(),this._Rect35_i(),this.sco_stage_i(),this.img_stage_close_i()];
		return t;
	};
	_proto._Rect34_i = function () {
		var t = new eui.Rect();
		t.fillAlpha = 0.8;
		t.height = 1700;
		t.horizontalCenter = 0;
		t.verticalCenter = 0;
		t.percentWidth = 100;
		return t;
	};
	_proto._Rect35_i = function () {
		var t = new eui.Rect();
		t.fillColor = 0xffffff;
		t.height = 1464;
		t.horizontalCenter = 0;
		t.top = 100;
		t.percentWidth = 90;
		return t;
	};
	_proto.sco_stage_i = function () {
		var t = new eui.Scroller();
		this.sco_stage = t;
		t.height = 1344;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.top = 130;
		t.percentWidth = 90;
		t.viewport = this._Group20_i();
		return t;
	};
	_proto._Group20_i = function () {
		var t = new eui.Group();
		t.elementsContent = [this.list_stage_i()];
		return t;
	};
	_proto.list_stage_i = function () {
		var t = new eui.List();
		this.list_stage = t;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.top = 0;
		t.percentWidth = 100;
		t.layout = this._VerticalLayout4_i();
		return t;
	};
	_proto._VerticalLayout4_i = function () {
		var t = new eui.VerticalLayout();
		t.gap = 20;
		t.horizontalAlign = "center";
		t.verticalAlign = "middle";
		return t;
	};
	_proto.img_stage_close_i = function () {
		var t = new eui.Image();
		this.img_stage_close = t;
		t.height = 135;
		t.right = 10;
		t.source = "res_json.btn_close";
		t.top = 20;
		t.width = 135;
		return t;
	};
	_proto.grp_section_i = function () {
		var t = new eui.Group();
		this.grp_section = t;
		t.horizontalCenter = 0;
		t.verticalCenter = 0;
		t.visible = false;
		t.percentWidth = 100;
		t.elementsContent = [this._Group21_i()];
		return t;
	};
	_proto._Group21_i = function () {
		var t = new eui.Group();
		t.horizontalCenter = 0;
		t.top = 0;
		t.percentWidth = 90;
		t.layout = this._VerticalLayout5_i();
		t.elementsContent = [this.grp_section_0_i(),this.grp_section_1_i(),this.grp_section_2_i(),this.grp_section_3_i()];
		return t;
	};
	_proto._VerticalLayout5_i = function () {
		var t = new eui.VerticalLayout();
		t.gap = 80;
		t.horizontalAlign = "center";
		t.verticalAlign = "middle";
		return t;
	};
	_proto.grp_section_0_i = function () {
		var t = new eui.Group();
		this.grp_section_0 = t;
		t.height = 200;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.percentWidth = 100;
		t.x = -486;
		t.y = 43;
		t.elementsContent = [this._Rect36_i(),this.lab_section_id_0_i(),this.lab_section_name_0_i(),this.grp_section_pass_0_i(),this.img_section_lock_0_i()];
		return t;
	};
	_proto._Rect36_i = function () {
		var t = new eui.Rect();
		t.ellipseWidth = 50;
		t.fillColor = 0x3f3f3f;
		t.percentHeight = 100;
		t.horizontalCenter = 0;
		t.verticalCenter = 0;
		t.percentWidth = 100;
		return t;
	};
	_proto.lab_section_id_0_i = function () {
		var t = new eui.Label();
		this.lab_section_id_0 = t;
		t.fontFamily = "Microsoft YaHei";
		t.left = 50;
		t.size = 35;
		t.text = "QUESTION.1";
		t.top = 20;
		return t;
	};
	_proto.lab_section_name_0_i = function () {
		var t = new eui.Label();
		this.lab_section_name_0 = t;
		t.fontFamily = "Microsoft YaHei";
		t.left = 100;
		t.size = 45;
		t.text = "礼物";
		t.verticalCenter = 0;
		return t;
	};
	_proto.grp_section_pass_0_i = function () {
		var t = new eui.Group();
		this.grp_section_pass_0 = t;
		t.right = 50;
		t.verticalCenter = 0;
		t.elementsContent = [this._Image22_i(),this._Label19_i()];
		return t;
	};
	_proto._Image22_i = function () {
		var t = new eui.Image();
		t.height = 102;
		t.horizontalCenter = 0;
		t.source = "res_json.icon_clear";
		t.verticalCenter = 0;
		t.width = 102;
		return t;
	};
	_proto._Label19_i = function () {
		var t = new eui.Label();
		t.fontFamily = "Microsoft YaHei";
		t.horizontalCenter = 0;
		t.text = "通关";
		t.verticalCenter = 0;
		return t;
	};
	_proto.img_section_lock_0_i = function () {
		var t = new eui.Image();
		this.img_section_lock_0 = t;
		t.right = 40;
		t.source = "res_json.UI_Icon_LockLocked";
		t.verticalCenter = 0;
		return t;
	};
	_proto.grp_section_1_i = function () {
		var t = new eui.Group();
		this.grp_section_1 = t;
		t.height = 200;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.percentWidth = 100;
		t.x = -476;
		t.y = 53;
		t.elementsContent = [this._Rect37_i(),this.lab_section_id_1_i(),this.lab_section_name_1_i(),this.grp_section_pass_1_i(),this.img_section_lock_1_i()];
		return t;
	};
	_proto._Rect37_i = function () {
		var t = new eui.Rect();
		t.ellipseWidth = 50;
		t.fillColor = 0x3F3F3F;
		t.percentHeight = 100;
		t.horizontalCenter = 0;
		t.verticalCenter = 0;
		t.percentWidth = 100;
		return t;
	};
	_proto.lab_section_id_1_i = function () {
		var t = new eui.Label();
		this.lab_section_id_1 = t;
		t.fontFamily = "Microsoft YaHei";
		t.left = 50;
		t.size = 35;
		t.text = "QUESTION.1";
		t.top = 20;
		return t;
	};
	_proto.lab_section_name_1_i = function () {
		var t = new eui.Label();
		this.lab_section_name_1 = t;
		t.fontFamily = "Microsoft YaHei";
		t.left = 100;
		t.size = 45;
		t.text = "礼物";
		t.verticalCenter = 0;
		return t;
	};
	_proto.grp_section_pass_1_i = function () {
		var t = new eui.Group();
		this.grp_section_pass_1 = t;
		t.right = 50;
		t.verticalCenter = 0;
		t.elementsContent = [this._Image23_i(),this._Label20_i()];
		return t;
	};
	_proto._Image23_i = function () {
		var t = new eui.Image();
		t.height = 102;
		t.horizontalCenter = 0;
		t.source = "res_json.icon_clear";
		t.verticalCenter = 0;
		t.width = 102;
		return t;
	};
	_proto._Label20_i = function () {
		var t = new eui.Label();
		t.fontFamily = "Microsoft YaHei";
		t.horizontalCenter = 0;
		t.text = "通关";
		t.verticalCenter = 0;
		return t;
	};
	_proto.img_section_lock_1_i = function () {
		var t = new eui.Image();
		this.img_section_lock_1 = t;
		t.right = 40;
		t.source = "res_json.UI_Icon_LockLocked";
		t.verticalCenter = 0;
		return t;
	};
	_proto.grp_section_2_i = function () {
		var t = new eui.Group();
		this.grp_section_2 = t;
		t.height = 200;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.percentWidth = 100;
		t.x = -466;
		t.y = 63;
		t.elementsContent = [this._Rect38_i(),this.lab_section_id_2_i(),this.lab_section_name_2_i(),this.grp_section_pass_2_i(),this.img_section_lock_2_i()];
		return t;
	};
	_proto._Rect38_i = function () {
		var t = new eui.Rect();
		t.ellipseWidth = 50;
		t.fillColor = 0x3F3F3F;
		t.percentHeight = 100;
		t.horizontalCenter = 0;
		t.verticalCenter = 0;
		t.percentWidth = 100;
		return t;
	};
	_proto.lab_section_id_2_i = function () {
		var t = new eui.Label();
		this.lab_section_id_2 = t;
		t.fontFamily = "Microsoft YaHei";
		t.left = 50;
		t.size = 35;
		t.text = "QUESTION.1";
		t.top = 20;
		return t;
	};
	_proto.lab_section_name_2_i = function () {
		var t = new eui.Label();
		this.lab_section_name_2 = t;
		t.fontFamily = "Microsoft YaHei";
		t.left = 100;
		t.size = 45;
		t.text = "礼物";
		t.verticalCenter = 0;
		return t;
	};
	_proto.grp_section_pass_2_i = function () {
		var t = new eui.Group();
		this.grp_section_pass_2 = t;
		t.right = 50;
		t.verticalCenter = 0;
		t.elementsContent = [this._Image24_i(),this._Label21_i()];
		return t;
	};
	_proto._Image24_i = function () {
		var t = new eui.Image();
		t.height = 102;
		t.horizontalCenter = 0;
		t.source = "res_json.icon_clear";
		t.verticalCenter = 0;
		t.width = 102;
		return t;
	};
	_proto._Label21_i = function () {
		var t = new eui.Label();
		t.fontFamily = "Microsoft YaHei";
		t.horizontalCenter = 0;
		t.text = "通关";
		t.verticalCenter = 0;
		return t;
	};
	_proto.img_section_lock_2_i = function () {
		var t = new eui.Image();
		this.img_section_lock_2 = t;
		t.right = 40;
		t.source = "res_json.UI_Icon_LockLocked";
		t.verticalCenter = 0;
		return t;
	};
	_proto.grp_section_3_i = function () {
		var t = new eui.Group();
		this.grp_section_3 = t;
		t.height = 200;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.percentWidth = 100;
		t.x = -456;
		t.y = 73;
		t.elementsContent = [this._Rect39_i(),this.lab_section_id_3_i(),this.lab_section_name_3_i(),this.grp_section_pass_3_i(),this.img_section_lock_3_i()];
		return t;
	};
	_proto._Rect39_i = function () {
		var t = new eui.Rect();
		t.ellipseWidth = 50;
		t.fillColor = 0x3F3F3F;
		t.percentHeight = 100;
		t.horizontalCenter = 0;
		t.verticalCenter = 0;
		t.percentWidth = 100;
		return t;
	};
	_proto.lab_section_id_3_i = function () {
		var t = new eui.Label();
		this.lab_section_id_3 = t;
		t.fontFamily = "Microsoft YaHei";
		t.left = 50;
		t.size = 35;
		t.text = "QUESTION.1";
		t.top = 20;
		return t;
	};
	_proto.lab_section_name_3_i = function () {
		var t = new eui.Label();
		this.lab_section_name_3 = t;
		t.fontFamily = "Microsoft YaHei";
		t.left = 100;
		t.size = 45;
		t.text = "礼物";
		t.verticalCenter = 0;
		return t;
	};
	_proto.grp_section_pass_3_i = function () {
		var t = new eui.Group();
		this.grp_section_pass_3 = t;
		t.right = 50;
		t.verticalCenter = 0;
		t.elementsContent = [this._Image25_i(),this._Label22_i()];
		return t;
	};
	_proto._Image25_i = function () {
		var t = new eui.Image();
		t.height = 102;
		t.horizontalCenter = 0;
		t.source = "res_json.icon_clear";
		t.verticalCenter = 0;
		t.width = 102;
		return t;
	};
	_proto._Label22_i = function () {
		var t = new eui.Label();
		t.fontFamily = "Microsoft YaHei";
		t.horizontalCenter = 0;
		t.text = "通关";
		t.verticalCenter = 0;
		return t;
	};
	_proto.img_section_lock_3_i = function () {
		var t = new eui.Image();
		this.img_section_lock_3 = t;
		t.right = 40;
		t.source = "res_json.UI_Icon_LockLocked";
		t.verticalCenter = 0;
		return t;
	};
	_proto.grp_start_i = function () {
		var t = new eui.Group();
		this.grp_start = t;
		t.percentHeight = 100;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.verticalCenter = 0;
		t.visible = false;
		t.percentWidth = 100;
		t.elementsContent = [this._Image26_i(),this._Label23_i(),this._Label24_i()];
		return t;
	};
	_proto._Image26_i = function () {
		var t = new eui.Image();
		t.horizontalCenter = -3;
		t.source = "0_png";
		t.verticalCenter = 0;
		return t;
	};
	_proto._Label23_i = function () {
		var t = new eui.Label();
		t.fontFamily = "Microsoft YaHei";
		t.horizontalCenter = 0;
		t.size = 90;
		t.stroke = 2;
		t.text = "侦探大作战";
		t.top = 280;
		return t;
	};
	_proto._Label24_i = function () {
		var t = new eui.Label();
		t.bottom = 500;
		t.fontFamily = "Microsoft YaHei";
		t.horizontalCenter = 0;
		t.size = 90;
		t.text = "开始游戏";
		return t;
	};
	_proto.grp_tip_i = function () {
		var t = new eui.Group();
		this.grp_tip = t;
		t.height = 100;
		t.horizontalCenter = 0;
		t.touchChildren = true;
		t.touchEnabled = true;
		t.touchThrough = true;
		t.verticalCenter = 0;
		t.visible = false;
		t.percentWidth = 100;
		t.elementsContent = [this._Rect40_i(),this.lab_tip_i()];
		return t;
	};
	_proto._Rect40_i = function () {
		var t = new eui.Rect();
		t.ellipseWidth = 50;
		t.fillAlpha = 0.6;
		t.percentHeight = 100;
		t.horizontalCenter = 0;
		t.verticalCenter = 0;
		t.percentWidth = 100;
		return t;
	};
	_proto.lab_tip_i = function () {
		var t = new eui.Label();
		this.lab_tip = t;
		t.fontFamily = "Microsoft YaHei";
		t.horizontalCenter = 0;
		t.size = 50;
		t.text = "资源正在加载中....";
		t.verticalCenter = 0;
		return t;
	};
	return GameUISkin;
})(eui.Skin);generateEUI.paths['resource/skins/LoadingSkin.exml'] = window.LoadingSkin = (function (_super) {
	__extends(LoadingSkin, _super);
	function LoadingSkin() {
		_super.call(this);
		this.skinParts = ["img_loading","adaptation"];
		
		this.height = 1920;
		this.width = 1080;
		this.elementsContent = [this.adaptation_i()];
	}
	var _proto = LoadingSkin.prototype;

	_proto.adaptation_i = function () {
		var t = new eui.Group();
		this.adaptation = t;
		t.percentHeight = 100;
		t.horizontalCenter = 0;
		t.verticalCenter = 0;
		t.percentWidth = 100;
		t.elementsContent = [this._Rect1_i(),this._Label1_i(),this.img_loading_i()];
		return t;
	};
	_proto._Rect1_i = function () {
		var t = new eui.Rect();
		t.fillColor = 0x5fafc8;
		t.percentHeight = 100;
		t.horizontalCenter = 0;
		t.verticalCenter = 0;
		t.percentWidth = 100;
		return t;
	};
	_proto._Label1_i = function () {
		var t = new eui.Label();
		t.bottom = 526;
		t.fontFamily = "Microsoft YaHei";
		t.horizontalCenter = 0;
		t.size = 50;
		t.text = "资源加载中.....";
		return t;
	};
	_proto.img_loading_i = function () {
		var t = new eui.Image();
		this.img_loading = t;
		t.left = 169;
		t.source = "loading_1_png";
		t.verticalCenter = 0;
		return t;
	};
	return LoadingSkin;
})(eui.Skin);generateEUI.paths['resource/skins/SeriesSkin.exml'] = window.SeriesSkin = (function (_super) {
	__extends(SeriesSkin, _super);
	function SeriesSkin() {
		_super.call(this);
		this.skinParts = ["img_title","grp_chose","lab_num_0","lab_name_0","img_lock_0","grp_0","lab_num_1","lab_name_1","img_lock_1","grp_1","lab_num_2","lab_name_2","img_lock_2","grp_2","lab_num_3","lab_name_3","img_lock_3","grp_3","grp_more","adaptation"];
		
		this.height = 1250;
		this.width = 864;
		this.elementsContent = [this.adaptation_i()];
	}
	var _proto = SeriesSkin.prototype;

	_proto.adaptation_i = function () {
		var t = new eui.Group();
		this.adaptation = t;
		t.percentHeight = 100;
		t.horizontalCenter = 0;
		t.verticalCenter = 0;
		t.percentWidth = 100;
		t.elementsContent = [this._Group1_i(),this._Group2_i(),this.grp_more_i()];
		return t;
	};
	_proto._Group1_i = function () {
		var t = new eui.Group();
		t.horizontalCenter = 0;
		t.top = 0;
		t.elementsContent = [this.img_title_i(),this.grp_chose_i()];
		return t;
	};
	_proto.img_title_i = function () {
		var t = new eui.Image();
		this.img_title = t;
		t.height = 300;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "title_0_png";
		t.verticalCenter = 0;
		t.width = 864;
		t.x = -336;
		return t;
	};
	_proto.grp_chose_i = function () {
		var t = new eui.Group();
		this.grp_chose = t;
		t.height = 110;
		t.right = 50;
		t.top = 50;
		t.width = 110;
		t.elementsContent = [this._Rect1_i(),this._Image1_i()];
		return t;
	};
	_proto._Rect1_i = function () {
		var t = new eui.Rect();
		t.fillAlpha = 0.5;
		t.percentHeight = 100;
		t.horizontalCenter = 0;
		t.verticalCenter = 0;
		t.percentWidth = 100;
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.height = 89.6;
		t.horizontalCenter = 0;
		t.source = "res_json.icon_theme13_3";
		t.verticalCenter = 0;
		t.width = 89.6;
		return t;
	};
	_proto._Group2_i = function () {
		var t = new eui.Group();
		t.horizontalCenter = 0;
		t.top = 325;
		t.percentWidth = 94;
		t.layout = this._VerticalLayout1_i();
		t.elementsContent = [this.grp_0_i(),this.grp_1_i(),this.grp_2_i(),this.grp_3_i()];
		return t;
	};
	_proto._VerticalLayout1_i = function () {
		var t = new eui.VerticalLayout();
		t.gap = 40;
		return t;
	};
	_proto.grp_0_i = function () {
		var t = new eui.Group();
		this.grp_0 = t;
		t.height = 180;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.percentWidth = 100;
		t.x = -297;
		t.y = -333;
		t.elementsContent = [this._Rect2_i(),this._Rect3_i(),this.lab_num_0_i(),this.lab_name_0_i(),this.img_lock_0_i()];
		return t;
	};
	_proto._Rect2_i = function () {
		var t = new eui.Rect();
		t.ellipseWidth = 50;
		t.fillColor = 0x161616;
		t.percentHeight = 100;
		t.horizontalCenter = 0;
		t.verticalCenter = 0;
		t.percentWidth = 100;
		return t;
	};
	_proto._Rect3_i = function () {
		var t = new eui.Rect();
		t.ellipseWidth = 50;
		t.fillColor = 0x0a0909;
		t.percentHeight = 86;
		t.horizontalCenter = 0;
		t.verticalCenter = 0;
		t.percentWidth = 96;
		t.x = 10;
		t.y = 10;
		return t;
	};
	_proto.lab_num_0_i = function () {
		var t = new eui.Label();
		this.lab_num_0 = t;
		t.fontFamily = "Microsoft YaHei";
		t.left = 50;
		t.size = 35;
		t.text = "Stage.1";
		t.top = 25;
		return t;
	};
	_proto.lab_name_0_i = function () {
		var t = new eui.Label();
		this.lab_name_0 = t;
		t.fontFamily = "Microsoft YaHei";
		t.left = 70;
		t.size = 35;
		t.text = "回家的诱惑";
		t.verticalCenter = 0;
		return t;
	};
	_proto.img_lock_0_i = function () {
		var t = new eui.Image();
		this.img_lock_0 = t;
		t.right = 50;
		t.source = "res_json.UI_Icon_LockLocked";
		t.verticalCenter = 0;
		return t;
	};
	_proto.grp_1_i = function () {
		var t = new eui.Group();
		this.grp_1 = t;
		t.height = 180;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.percentWidth = 100;
		t.x = -287;
		t.y = -323;
		t.elementsContent = [this._Rect4_i(),this._Rect5_i(),this.lab_num_1_i(),this.lab_name_1_i(),this.img_lock_1_i()];
		return t;
	};
	_proto._Rect4_i = function () {
		var t = new eui.Rect();
		t.ellipseWidth = 50;
		t.fillColor = 0x161616;
		t.percentHeight = 100;
		t.horizontalCenter = 0;
		t.verticalCenter = 0;
		t.percentWidth = 100;
		return t;
	};
	_proto._Rect5_i = function () {
		var t = new eui.Rect();
		t.ellipseWidth = 50;
		t.fillColor = 0x0A0909;
		t.percentHeight = 86;
		t.horizontalCenter = 0;
		t.verticalCenter = 0;
		t.percentWidth = 96;
		t.x = 10;
		t.y = 10;
		return t;
	};
	_proto.lab_num_1_i = function () {
		var t = new eui.Label();
		this.lab_num_1 = t;
		t.fontFamily = "Microsoft YaHei";
		t.left = 50;
		t.size = 35;
		t.text = "Stage.1";
		t.top = 25;
		return t;
	};
	_proto.lab_name_1_i = function () {
		var t = new eui.Label();
		this.lab_name_1 = t;
		t.fontFamily = "Microsoft YaHei";
		t.left = 70;
		t.size = 35;
		t.text = "回家的诱惑";
		t.verticalCenter = 0;
		return t;
	};
	_proto.img_lock_1_i = function () {
		var t = new eui.Image();
		this.img_lock_1 = t;
		t.right = 50;
		t.source = "res_json.UI_Icon_LockLocked";
		t.verticalCenter = 0;
		return t;
	};
	_proto.grp_2_i = function () {
		var t = new eui.Group();
		this.grp_2 = t;
		t.height = 180;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.percentWidth = 100;
		t.x = -277;
		t.y = -313;
		t.elementsContent = [this._Rect6_i(),this._Rect7_i(),this.lab_num_2_i(),this.lab_name_2_i(),this.img_lock_2_i()];
		return t;
	};
	_proto._Rect6_i = function () {
		var t = new eui.Rect();
		t.ellipseWidth = 50;
		t.fillColor = 0x161616;
		t.percentHeight = 100;
		t.horizontalCenter = 0;
		t.verticalCenter = 0;
		t.percentWidth = 100;
		return t;
	};
	_proto._Rect7_i = function () {
		var t = new eui.Rect();
		t.ellipseWidth = 50;
		t.fillColor = 0x0A0909;
		t.percentHeight = 86;
		t.horizontalCenter = 0;
		t.verticalCenter = 0;
		t.percentWidth = 96;
		t.x = 10;
		t.y = 10;
		return t;
	};
	_proto.lab_num_2_i = function () {
		var t = new eui.Label();
		this.lab_num_2 = t;
		t.fontFamily = "Microsoft YaHei";
		t.left = 50;
		t.size = 35;
		t.text = "Stage.1";
		t.top = 25;
		return t;
	};
	_proto.lab_name_2_i = function () {
		var t = new eui.Label();
		this.lab_name_2 = t;
		t.fontFamily = "Microsoft YaHei";
		t.left = 70;
		t.size = 35;
		t.text = "回家的诱惑";
		t.verticalCenter = 0;
		return t;
	};
	_proto.img_lock_2_i = function () {
		var t = new eui.Image();
		this.img_lock_2 = t;
		t.right = 50;
		t.source = "res_json.UI_Icon_LockLocked";
		t.verticalCenter = 0;
		return t;
	};
	_proto.grp_3_i = function () {
		var t = new eui.Group();
		this.grp_3 = t;
		t.height = 180;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.percentWidth = 100;
		t.x = -267;
		t.y = -303;
		t.elementsContent = [this._Rect8_i(),this._Rect9_i(),this.lab_num_3_i(),this.lab_name_3_i(),this.img_lock_3_i()];
		return t;
	};
	_proto._Rect8_i = function () {
		var t = new eui.Rect();
		t.ellipseWidth = 50;
		t.fillColor = 0x161616;
		t.percentHeight = 100;
		t.horizontalCenter = 0;
		t.verticalCenter = 0;
		t.percentWidth = 100;
		return t;
	};
	_proto._Rect9_i = function () {
		var t = new eui.Rect();
		t.ellipseWidth = 50;
		t.fillColor = 0x0A0909;
		t.percentHeight = 86;
		t.horizontalCenter = 0;
		t.verticalCenter = 0;
		t.percentWidth = 96;
		t.x = 10;
		t.y = 10;
		return t;
	};
	_proto.lab_num_3_i = function () {
		var t = new eui.Label();
		this.lab_num_3 = t;
		t.fontFamily = "Microsoft YaHei";
		t.left = 50;
		t.size = 35;
		t.text = "Stage.1";
		t.top = 25;
		return t;
	};
	_proto.lab_name_3_i = function () {
		var t = new eui.Label();
		this.lab_name_3 = t;
		t.fontFamily = "Microsoft YaHei";
		t.left = 70;
		t.size = 35;
		t.text = "回家的诱惑";
		t.verticalCenter = 0;
		return t;
	};
	_proto.img_lock_3_i = function () {
		var t = new eui.Image();
		this.img_lock_3 = t;
		t.right = 50;
		t.source = "res_json.UI_Icon_LockLocked";
		t.verticalCenter = 0;
		return t;
	};
	_proto.grp_more_i = function () {
		var t = new eui.Group();
		this.grp_more = t;
		t.bottom = 20;
		t.horizontalCenter = 0;
		t.percentWidth = 94;
		t.elementsContent = [this._Image2_i(),this._Label1_i()];
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		t.horizontalCenter = 0;
		t.scale9Grid = new egret.Rectangle(88,5,222,33);
		t.source = "res_json.btn_continue";
		t.verticalCenter = 0;
		t.percentWidth = 100;
		return t;
	};
	_proto._Label1_i = function () {
		var t = new eui.Label();
		t.fontFamily = "Microsoft YaHei";
		t.horizontalCenter = 0;
		t.text = "更多关卡";
		t.verticalCenter = 0;
		return t;
	};
	return SeriesSkin;
})(eui.Skin);generateEUI.paths['resource/skins/StageItemSkin.exml'] = window.StageItemSkin = (function (_super) {
	__extends(StageItemSkin, _super);
	function StageItemSkin() {
		_super.call(this);
		this.skinParts = ["lab_id","lab_name","img_lock","adaptation"];
		
		this.height = 200;
		this.width = 864;
		this.elementsContent = [this.adaptation_i()];
	}
	var _proto = StageItemSkin.prototype;

	_proto.adaptation_i = function () {
		var t = new eui.Group();
		this.adaptation = t;
		t.percentHeight = 100;
		t.horizontalCenter = 0;
		t.verticalCenter = 0;
		t.percentWidth = 100;
		t.elementsContent = [this._Rect1_i(),this.lab_id_i(),this.lab_name_i(),this.img_lock_i()];
		return t;
	};
	_proto._Rect1_i = function () {
		var t = new eui.Rect();
		t.ellipseWidth = 50;
		t.fillColor = 0x3f3f3f;
		t.percentHeight = 100;
		t.horizontalCenter = 0;
		t.verticalCenter = 0;
		t.percentWidth = 100;
		return t;
	};
	_proto.lab_id_i = function () {
		var t = new eui.Label();
		this.lab_id = t;
		t.fontFamily = "Microsoft YaHei";
		t.left = 50;
		t.size = 35;
		t.text = "Stage.1";
		t.top = 10;
		return t;
	};
	_proto.lab_name_i = function () {
		var t = new eui.Label();
		this.lab_name = t;
		t.fontFamily = "Microsoft YaHei";
		t.left = 100;
		t.size = 45;
		t.text = "回家的诱惑";
		t.verticalCenter = 0;
		return t;
	};
	_proto.img_lock_i = function () {
		var t = new eui.Image();
		this.img_lock = t;
		t.right = 40;
		t.source = "res_json.UI_Icon_LockLocked";
		t.verticalCenter = 0;
		return t;
	};
	return StageItemSkin;
})(eui.Skin);