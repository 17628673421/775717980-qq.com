var egret = window.egret;var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = y[op[0] & 2 ? "return" : op[0] ? "throw" : "next"]) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [0, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var game;
(function (game) {
    /**
     * 组件的基类
     * 实现了一个发送通知到Controller的方法
     */
    var BaseComponent = (function (_super) {
        __extends(BaseComponent, _super);
        function BaseComponent() {
            return _super.call(this) || this;
        }
        /** 发送通知到Controller */
        BaseComponent.prototype.sendNotification = function (type, body) {
            game.NotifyManager.getInstance().distribute(type, body);
        };
        return BaseComponent;
    }(eui.Component));
    game.BaseComponent = BaseComponent;
    __reflect(BaseComponent.prototype, "game.BaseComponent", ["ISendNofity"]);
})(game || (game = {}));
var game;
(function (game) {
    /**
     *
     * @author
     */
    var BaseNotification = (function () {
        function BaseNotification() {
        }
        /**
         * 注册
         * */
        BaseNotification.prototype.addRegister = function (name, obj) {
            game.NotifyManager.getInstance().addObj(name, obj);
        };
        /**
         * 移除
         * */
        BaseNotification.prototype.removeRegister = function (name) {
            game.NotifyManager.getInstance().removeObj(name);
        };
        /** 发送全局通知 */
        BaseNotification.prototype.sendNotification = function (type, body) {
            game.NotifyManager.getInstance().distribute(type, body);
        };
        return BaseNotification;
    }());
    game.BaseNotification = BaseNotification;
    __reflect(BaseNotification.prototype, "game.BaseNotification");
})(game || (game = {}));
var game;
(function (game) {
    /**
     * 控制器的基类
     * 强制重写的方法：
     * listNotification() 罗列要接收的通知
     * handleNotification() 接收通知
     * start() 启用
     * initData() 初始化UI数据，在UI加载完毕后调用
     */
    var BaseController = (function (_super) {
        __extends(BaseController, _super);
        function BaseController() {
            var _this = _super.call(this) || this;
            _this.addRegister(egret.getQualifiedClassName(_this), _this);
            return _this;
        }
        /** 通知UI */
        BaseController.prototype.notifyUI = function (type, body) {
            if (this.ui) {
                this.ui.onControllerCommand(type, body);
            }
            if (this.sysUI) {
                this.sysUI.onControllerCommand(type, body);
            }
        };
        /** 打开UI */
        BaseController.prototype.enterUI = function (ui, num) {
            var _this = this;
            this.ui = ui;
            this.ui.once(eui.UIEvent.CREATION_COMPLETE, function () {
                // this.sendNotification(NotifyConst.uiComplete)
                _this.isUIComplete = true;
                _this.initData();
            }, this);
            game.LayerManager.getInstance().addUI(this.ui, num);
        };
        /**设置系统UI */
        BaseController.prototype.setSysUI = function (ui, num) {
            var _this = this;
            this.sysUI = ui;
            this.sysUI.once(eui.UIEvent.CREATION_COMPLETE, function () {
                // this.sendNotification(NotifyConst.uiComplete)
                _this.isUIComplete = true;
                _this.initData();
            }, this);
            game.LayerManager.getInstance().addUI(this.sysUI, num);
        };
        /** 关闭 */
        BaseController.prototype.dispose = function () {
            this.ui.dispose();
        };
        return BaseController;
    }(game.BaseNotification));
    game.BaseController = BaseController;
    __reflect(BaseController.prototype, "game.BaseController");
})(game || (game = {}));
var game;
(function (game) {
    /**
     * @desc 基本的UI界面显示类
     * 强制重写的方法：
     * initUI() 组件创建完成初始化显示组件
     * initListener() 添加UI界面监听
     * onControllerCommand() 收到Controller的通知
     */
    var BaseUI = (function (_super) {
        __extends(BaseUI, _super);
        function BaseUI() {
            var _this = _super.call(this) || this;
            _this.eventDic = new game.Dictionary();
            return _this;
        }
        /** 在本身以及子控件初始化完毕后自动触发 */
        BaseUI.prototype.childrenCreated = function () {
            this.initUI();
            this.onStageResize(null);
        };
        /**
         * 当舞台尺寸发生变化,需被子类继承
         */
        BaseUI.prototype.onStageResize = function (evt) {
            var stageW = game.StageUtil.width, stageH = game.StageUtil.height;
            this.scaleX = stageW / game.StageUtil.DesignWidth;
            this.scaleY = stageH / game.StageUtil.DesignHeight;
        };
        /**
         * 事件注册，所有事件的注册都需要走这里
         */
        BaseUI.prototype.registerEvent = function (target, type, callBack, thisObject) {
            var eventParams = {};
            eventParams.target = target;
            eventParams.type = type;
            eventParams.callBack = callBack;
            eventParams.thisObject = thisObject;
            if (target) {
                target.addEventListener(type, callBack, thisObject);
                this.eventDic.setValue(target.hashCode + type, eventParams);
            }
        };
        /**
         * 统一移除所有事件
         */
        BaseUI.prototype.removeAllEvent = function () {
            var eventList = this.eventDic.getAllValue();
            while (eventList.length > 0) {
                var tempEvent = eventList.shift();
                if (tempEvent.target != null) {
                    tempEvent.target.removeEventListener(tempEvent.type, tempEvent.callBack, tempEvent.thisObject);
                }
            }
            this.eventDic.clear();
        };
        /**
         * 资源释放
         * @$isDispos 是否彻底释放资源
         */
        BaseUI.prototype.dispose = function () {
            this.removeAllEvent();
            if (this.parent) {
                this.parent.removeChild(this);
            }
        };
        return BaseUI;
    }(game.BaseComponent));
    game.BaseUI = BaseUI;
    __reflect(BaseUI.prototype, "game.BaseUI");
})(game || (game = {}));
var game;
(function (game) {
    var SoundConst = (function () {
        function SoundConst() {
        }
        /** 点击音效 */
        SoundConst.click = "button01_wav";
        /** 背景音乐 */
        SoundConst.bg = "bg_mp3";
        return SoundConst;
    }());
    game.SoundConst = SoundConst;
    __reflect(SoundConst.prototype, "game.SoundConst");
})(game || (game = {}));
/** 微信用户信息类 */
var WXManager = (function () {
    function WXManager() {
    }
    WXManager.getInstance = function () {
        if (!this._instance)
            this._instance = new WXManager();
        return this._instance;
    };
    /** 小游戏appid */
    WXManager.appId = "wx8da451056e55806f";
    /** 小游戏唯一密匙 */
    WXManager.secret = "1dbc2a1314cc6c893b8e60c079eeead1";
    return WXManager;
}());
__reflect(WXManager.prototype, "WXManager");
//////////////////////////////////////////////////////////////////////////////////////
//
//  Copyright (c) 2014-present, Egret Technology.
//  All rights reserved.
//  Redistribution and use in source and binary forms, with or without
//  modification, are permitted provided that the following conditions are met:
//
//     * Redistributions of source code must retain the above copyright
//       notice, this list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above copyright
//       notice, this list of conditions and the following disclaimer in the
//       documentation and/or other materials provided with the distribution.
//     * Neither the name of the Egret nor the
//       names of its contributors may be used to endorse or promote products
//       derived from this software without specific prior written permission.
//
//  THIS SOFTWARE IS PROVIDED BY EGRET AND CONTRIBUTORS "AS IS" AND ANY EXPRESS
//  OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
//  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
//  IN NO EVENT SHALL EGRET AND CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
//  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
//  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;LOSS OF USE, DATA,
//  OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
//  LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
//  NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
//  EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
//////////////////////////////////////////////////////////////////////////////////////
var AssetAdapter = (function () {
    function AssetAdapter() {
    }
    /**
     * @language zh_CN
     * 解析素材
     * @param source 待解析的新素材标识符
     * @param compFunc 解析完成回调函数，示例：callBack(content:any,source:string):void;
     * @param thisObject callBack的 this 引用
     */
    AssetAdapter.prototype.getAsset = function (source, compFunc, thisObject) {
        function onGetRes(data) {
            compFunc.call(thisObject, data, source);
        }
        if (RES.hasRes(source)) {
            var data_1 = RES.getRes(source);
            if (data_1) {
                onGetRes(data_1);
            }
            else {
                RES.getResAsync(source, onGetRes, this);
            }
        }
        else {
            RES.getResByUrl(source, onGetRes, this, RES.ResourceItem.TYPE_IMAGE);
        }
    };
    return AssetAdapter;
}());
__reflect(AssetAdapter.prototype, "AssetAdapter", ["eui.IAssetAdapter"]);
//////////////////////////////////////////////////////////////////////////////////////
//
//  Copyright (c) 2014-present, Egret Technology.
//  All rights reserved.
//  Redistribution and use in source and binary forms, with or without
//  modification, are permitted provided that the following conditions are met:
//
//     * Redistributions of source code must retain the above copyright
//       notice, this list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above copyright
//       notice, this list of conditions and the following disclaimer in the
//       documentation and/or other materials provided with the distribution.
//     * Neither the name of the Egret nor the
//       names of its contributors may be used to endorse or promote products
//       derived from this software without specific prior written permission.
//
//  THIS SOFTWARE IS PROVIDED BY EGRET AND CONTRIBUTORS "AS IS" AND ANY EXPRESS
//  OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
//  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
//  IN NO EVENT SHALL EGRET AND CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
//  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
//  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;LOSS OF USE, DATA,
//  OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
//  LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
//  NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
//  EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
//////////////////////////////////////////////////////////////////////////////////////
var Main = (function (_super) {
    __extends(Main, _super);
    function Main() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    Main.prototype.createChildren = function () {
        _super.prototype.createChildren.call(this);
        // egret.lifecycle.addLifecycleListener((context) => {
        //     // custom lifecycle plugin
        // })
        // egret.lifecycle.onPause = () => {
        //     egret.ticker.pause();
        // }
        // egret.lifecycle.onResume = () => {
        //     egret.ticker.resume();
        // }
        //inject the custom material parser
        //注入自定义的素材解析器
        var assetAdapter = new AssetAdapter();
        egret.registerImplementation("eui.IAssetAdapter", assetAdapter);
        egret.registerImplementation("eui.IThemeAdapter", new ThemeAdapter());
        this.runGame().catch(function (e) {
            console.log(e);
        });
        game.StageUtil.stage = this.stage;
        game.LayerManager.getInstance().initLayer();
    };
    Main.prototype.runGame = function () {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.loadResource()];
                    case 1:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    Main.prototype.loadResource = function () {
        return __awaiter(this, void 0, void 0, function () {
            var _this = this;
            var loadingView_1, e_1;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        _a.trys.push([0, 5, , 6]);
                        return [4 /*yield*/, RES.loadConfig("resource/default.res.json", "resource")];
                    case 1:
                        _a.sent();
                        //await RES.loadConfig("https://zt.cdbandou.cn/d1/default.res.json", "https://zt.cdbandou.cn/d1");
                        // await this.loadTheme();
                        return [4 /*yield*/, this.loadTheme()];
                    case 2:
                        //await RES.loadConfig("https://zt.cdbandou.cn/d1/default.res.json", "https://zt.cdbandou.cn/d1");
                        // await this.loadTheme();
                        _a.sent();
                        return [4 /*yield*/, RES.loadGroup("loading").then(function () {
                                loadingView_1 = new LoadingUI();
                                _this.stage.addChild(loadingView_1);
                            })];
                    case 3:
                        _a.sent();
                        return [4 /*yield*/, RES.loadGroup("preload", 0, loadingView_1).then(function () {
                                _this.stage.removeChild(loadingView_1);
                            })];
                    case 4:
                        _a.sent();
                        this.userInfoHandler();
                        // await RES.loadGroup("loading", 0).then(() => {
                        //     loadingView = new LoadingUI();
                        //     this.stage.addChild(loadingView);
                        // });
                        // await RES.loadGroup("preload", 0, loadingView).then(() => {
                        //     this.userInfoHandler().then(() => {
                        //         setTimeout(() => {
                        //             loadingView.close();
                        //             this.stage.removeChild(loadingView);
                        this.createGameScene();
                        return [3 /*break*/, 6];
                    case 5:
                        e_1 = _a.sent();
                        console.error(e_1);
                        return [3 /*break*/, 6];
                    case 6:
                        this.removeChildren();
                        return [2 /*return*/];
                }
            });
        });
    };
    /** 微信用户信息处理 */
    Main.prototype.userInfoHandler = function () {
        var info = WXManager.getInstance();
        platform.authorizeJurisdiction().then(function () {
            console.log("已经授权，正在获取用户信息...");
            platform.getUserInfo().then(function (data) {
                console.log("获取用户信息成功--授权过", data);
                info.nickName = data.userInfo.nickName;
                info.avatarUrl = data.userInfo.avatarUrl;
                info.gender = data.userInfo.gender;
                info.city = data.userInfo.city;
                info.province = data.userInfo.province;
                info.country = data.userInfo.country;
            }).catch(function () {
                console.log("获取用户信息失败...");
            });
        }).catch(function () {
            platform.getUserInfoByButton().then(function (data) {
                console.log("获取用户信息成功--第一次授权", data);
                info.nickName = data.userInfo.nickName;
                info.avatarUrl = data.userInfo.avatarUrl;
                info.gender = data.userInfo.gender;
                info.city = data.userInfo.city;
                info.province = data.userInfo.province;
                info.country = data.userInfo.country;
            }).catch(function () {
                console.log("获取用户信息失败...");
            });
        });
        // return new Promise(async (resolve, reject) => {
        //     platform.createBannerAd1();
        //     let login: boolean = false;
        //     let info: WXManager = WXManager.getInstance();
        //     platform.showShareMenu();
        //     console.log("资源加载完毕，进行登录操作...");
        //     let incode: any;
        //     await platform.getLaunchOptionsSync().then((info) => {
        //         console.log("返回的消息", info);
        //     });
        //     await platform.login(incode).then((jsonData) => {
        //         let js = jsonData.req.data;//RES.ResourceItem.TYPE_JSON(data.req.data.msg_data);
        //         console.log("登录成功，获取到用户的code以及openid：", jsonData);
        //         console.log("正在查询用户是否授权用户信息...");
        //         info.openId = js.openid;
        //         info.session_key = js.session_key;
        //         console.log("info.openId" + info.openId);
        //         // info.session_key = data.req.data.session_key;
        //         console.log("WXUserInfo.appId" + WXManager.appId);
        //         console.log("WXUserInfo.secret" + WXManager.secret);
        //         login = true;
        //     });
        //     await platform.authorizeJurisdiction().then(() => {
        //         console.log("已经授权，正在获取用户信息...");
        //         platform.getUserInfo().then((data) => {
        //             console.log("获取用户信息成功--授权过", data);
        //             info.nickName = data.userInfo.nickName;
        //             info.avatarUrl = data.userInfo.avatarUrl;
        //             info.gender = data.userInfo.gender;
        //             info.city = data.userInfo.city;
        //             info.province = data.userInfo.province;
        //             info.country = data.userInfo.country;
        //         }).catch(() => {
        //             console.log("获取用户信息失败...")
        //         });
        //     }).catch(() => {
        //         platform.getUserInfoByButton().then((data) => {
        //             console.log("获取用户信息成功--第一次授权", data);
        //             info.nickName = data.userInfo.nickName;
        //             info.avatarUrl = data.userInfo.avatarUrl;
        //             info.gender = data.userInfo.gender;
        //             info.city = data.userInfo.city;
        //             info.province = data.userInfo.province;
        //             info.country = data.userInfo.country;
        //         }).catch(() => {
        //             console.log("获取用户信息失败...")
        //         });
        //     })
        //     if (login) {
        //         resolve();
        //     }
        // })
    };
    Main.prototype.loadTheme = function () {
        var _this = this;
        return new Promise(function (resolve, reject) {
            // load skin theme configuration file, you can manually modify the file. And replace the default skin.
            //加载皮肤主题配置文件,可以手动修改这个文件。替换默认皮肤。
            var theme = new eui.Theme("resource/default.thm.json", _this.stage);
            theme.addEventListener(eui.UIEvent.COMPLETE, function () {
                resolve();
            }, _this);
        });
    };
    /** 创建游戏场景 */
    Main.prototype.createGameScene = function () {
        var model = game.Model.getInstance();
        var wx = WXManager.getInstance();
        this.stage.maxTouches = 2;
        window["game"] = game;
        var scaleX = this.stage.stageWidth / 1080;
        var scaleY = this.stage.stageHeight / 1920;
        if (scaleY > 1) {
            scaleY = 1920 / this.stage.stageHeight;
        }
        if (scaleX < 1) {
            scaleY = 1 - (scaleY - 1);
        }
        console.log("屏幕宽高", this.stage.stageWidth, this.stage.stageHeight, scaleX, scaleY, egret.Capabilities.boundingClientWidth, egret.Capabilities.boundingClientHeight);
        model.scaleX = scaleX;
        model.scaleY = scaleY;
        egret.ImageLoader.crossOrigin = "anonymous";
        game.Controller.getInstance().start();
        // platform.createBannerAd1().then((ad)=>{
        //     wx.overBanner = ad;
        // });
        // platform.createBannerAd2();
        // platform.createBannerAd2().then((ad)=>{
        //     wx.scenceBanner = ad;
        // });
        // platform.createRewardedVideoAd().then((ad)=>{
        //     wx.videoBanner = ad;
        // });
    };
    return Main;
}(eui.UILayer));
__reflect(Main.prototype, "Main");
var game;
(function (game) {
    /**
     * 项解析器的基类
     * 实现了一个发送通知到Controller的方法
     */
    var BaseItemRenderer = (function (_super) {
        __extends(BaseItemRenderer, _super);
        function BaseItemRenderer() {
            return _super.call(this) || this;
        }
        /** 发送全局通知 */
        BaseItemRenderer.prototype.sendNotification = function (type, body) {
            game.NotifyManager.getInstance().distribute(type, body);
        };
        return BaseItemRenderer;
    }(eui.ItemRenderer));
    game.BaseItemRenderer = BaseItemRenderer;
    __reflect(BaseItemRenderer.prototype, "game.BaseItemRenderer", ["ISendNofity"]);
})(game || (game = {}));
var DebugPlatform = (function () {
    function DebugPlatform() {
    }
    DebugPlatform.prototype.getUserInfo = function () {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                return [2 /*return*/];
            });
        });
    };
    DebugPlatform.prototype.getUserInfoByButton = function () {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                return [2 /*return*/];
            });
        });
    };
    DebugPlatform.prototype.login = function () {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                return [2 /*return*/];
            });
        });
    };
    DebugPlatform.prototype.getAccessToken = function (appId, secret) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                return [2 /*return*/];
            });
        });
    };
    DebugPlatform.prototype.showShareMenu = function () {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                return [2 /*return*/];
            });
        });
    };
    DebugPlatform.prototype.shareAppMessage = function () {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                return [2 /*return*/];
            });
        });
    };
    DebugPlatform.prototype.getopenDataContext = function () {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                return [2 /*return*/];
            });
        });
    };
    DebugPlatform.prototype.getFriendCloudStorage = function () {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                return [2 /*return*/];
            });
        });
    };
    DebugPlatform.prototype.setUseValue = function (playervalue, highestfraction) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                return [2 /*return*/];
            });
        });
    };
    DebugPlatform.prototype.setUserStorage = function (score, access_token, openid, session_key) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                return [2 /*return*/];
            });
        });
    };
    DebugPlatform.prototype.authorizeJurisdiction = function () {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                return [2 /*return*/];
            });
        });
    };
    DebugPlatform.prototype.vibrateShort = function () {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                return [2 /*return*/];
            });
        });
    };
    DebugPlatform.prototype.onShow = function () {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                return [2 /*return*/];
            });
        });
    };
    DebugPlatform.prototype.onHide = function () {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                return [2 /*return*/];
            });
        });
    };
    DebugPlatform.prototype.getIsHide = function () {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                return [2 /*return*/];
            });
        });
    };
    DebugPlatform.prototype.getIsShow = function () {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                return [2 /*return*/];
            });
        });
    };
    DebugPlatform.prototype.createBannerAd1 = function () {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                return [2 /*return*/];
            });
        });
    };
    DebugPlatform.prototype.createBannerAd2 = function () {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                return [2 /*return*/];
            });
        });
    };
    DebugPlatform.prototype.createRewardedVideoAd = function (type) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                return [2 /*return*/];
            });
        });
    };
    DebugPlatform.prototype.openGame = function () {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                return [2 /*return*/];
            });
        });
    };
    DebugPlatform.prototype.getPhoneInfo = function () {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                return [2 /*return*/];
            });
        });
    };
    DebugPlatform.prototype.getLaunchOptionsSync = function () {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                return [2 /*return*/];
            });
        });
    };
    DebugPlatform.prototype.hideBannerAd = function (ad) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                return [2 /*return*/];
            });
        });
    };
    DebugPlatform.prototype.showBannerAd = function (ad) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                return [2 /*return*/];
            });
        });
    };
    DebugPlatform.prototype.createInterstitialAd = function () {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                return [2 /*return*/];
            });
        });
    };
    return DebugPlatform;
}());
__reflect(DebugPlatform.prototype, "DebugPlatform", ["Platform"]);
if (!window.platform) {
    window.platform = new DebugPlatform();
}
var game;
(function (game) {
    var LayerManager = (function () {
        function LayerManager() {
        }
        LayerManager.getInstance = function () {
            if (!this._instance)
                this._instance = new LayerManager();
            return this._instance;
        };
        /** 初始化管理器 */
        LayerManager.prototype.initLayer = function () {
            this.loginGroup = new eui.Group();
            this.loadGroup = new eui.Group();
            this.mainGroup = new eui.Group();
            this.sysGroup = new eui.Group();
            this.sysGroup.touchThrough = true;
            game.StageUtil.stage.addChild(this.mainGroup);
            game.StageUtil.stage.addChild(this.loginGroup);
            game.StageUtil.stage.addChild(this.sysGroup);
            game.StageUtil.stage.addChild(this.loadGroup);
        };
        LayerManager.prototype.addUI = function (ui, layer) {
            if (layer === void 0) { layer = LayerConst.Layer_UI; }
            switch (layer) {
                case LayerConst.Layer_UI:
                    this.mainGroup.addChild(ui);
                    break;
                case LayerConst.Layer_Sys:
                    this.sysGroup.addChild(ui);
                    break;
                case LayerConst.Layer_Load:
                    this.loadGroup.addChild(ui);
                    break;
                case LayerConst.Layer_Login:
                    this.loginGroup.addChild(ui);
                    break;
            }
        };
        LayerManager.prototype.clear = function () {
            this.mainGroup.removeChildren();
        };
        return LayerManager;
    }());
    game.LayerManager = LayerManager;
    __reflect(LayerManager.prototype, "game.LayerManager");
    var LayerConst = (function () {
        function LayerConst() {
        }
        LayerConst.Layer_UI = 1;
        LayerConst.Layer_Sys = 2;
        LayerConst.Layer_Load = 3;
        LayerConst.Layer_Login = 4;
        return LayerConst;
    }());
    game.LayerConst = LayerConst;
    __reflect(LayerConst.prototype, "game.LayerConst");
})(game || (game = {}));
var game;
(function (game) {
    var TopicManager = (function () {
        function TopicManager() {
            this._requestPool = new game.Dictionary();
            this.gameSocket = new game.GameSocket();
            this.snapshotDic = new game.Dictionary();
            this._seqCallback = new game.Dictionary();
            this._topicListeners = new game.Dictionary();
            this._sequences = 1;
        }
        TopicManager.getInstance = function () {
            if (this.instance == null) {
                this.instance = new TopicManager();
            }
            return this.instance;
        };
        /**连接游戏socket */
        TopicManager.prototype.connect = function (host, callback, callbackobj, errCallback) {
            console.warn("连接socket==========", host);
            // this.gameSocket.connect(host,port,callback, callbackobj, errCallback);
            this.gameSocket.connectByUrl(host, callback, callbackobj, errCallback);
        };
        TopicManager.prototype.disconnect = function () {
            this.gameSocket.disconnect();
        };
        /**登陆游戏 */
        TopicManager.prototype.loginGame = function (msg) {
            this.sendCMD(msg);
        };
        /**
         * 添加协议监听
         */
        TopicManager.prototype.addSocketListener = function (topic, callBack, thisObject) {
            this._topicListeners.setValue(topic, new game.RequestHandler(callBack, thisObject));
        };
        /**
         * 移除协议监听
         */
        TopicManager.prototype.removeSocketListener = function (topic) {
            this._topicListeners.removeKey(topic);
        };
        /**收到服务器数据 准备处理 */
        TopicManager.prototype.onDataIn = function (message) {
            //返回有错误的话，直接执行回调 不继续派发消息
            this.handleData(message);
        };
        /** 客户端主动断开socket */
        TopicManager.prototype.closeSocket = function () {
            this.gameSocket.disconnect();
        };
        /**处理数据 */
        TopicManager.prototype.handleData = function (json) {
            // console.log("收到的服务器socket数据", json);
        };
        /**寻找此消息的seq是否注册过回调 并执行回调 */
        TopicManager.prototype.checkSeqCallback = function (resp) {
            var callbacker = this._seqCallback.getValue(resp.seq);
            if (callbacker) {
                this._seqCallback.removeKey(resp.seq);
                callbacker.callBack.call(callbacker.thisObject, resp);
            }
        };
        /**
         * 发送协议
         */
        TopicManager.prototype.sendCMD = function (message) {
            this.gameSocket.sendCMD(message);
        };
        return TopicManager;
    }());
    game.TopicManager = TopicManager;
    __reflect(TopicManager.prototype, "game.TopicManager");
})(game || (game = {}));
var game;
(function (game) {
    /**
     * @desc 单个http请求
     */
    var HttpItem = (function () {
        function HttpItem(url, sendData, successCallBack, errorCallback, thisObject, method) {
            if (sendData === void 0) { sendData = null; }
            if (method === void 0) { method = "GET"; }
            this.needTip = true;
            this.isload = false;
            this.url = url;
            this.sendData = sendData;
            this.thisObject = thisObject;
            this.errorCallback = errorCallback;
            this.successCallBack = successCallBack;
            this.method = method;
            this.xhr = new XMLHttpRequest();
        }
        HttpItem.prototype.load = function () {
            var _this = this;
            this.xhr.open(this.method, this.url, true);
            this.xhr.onreadystatechange = function () {
                if (_this.xhr.readyState == 4) {
                    if (_this.needTip && _this.timeOutId) {
                        clearTimeout(_this.timeOutId);
                        _this.timeOutId = null;
                    }
                    _this.isload = true;
                    var txt = _this.xhr.responseText;
                    switch (_this.xhr.status) {
                        case 200:
                        case 201:
                        case 204:
                            if (_this.successCallBack && _this.thisObject) {
                                _this.successCallBack.call(_this.thisObject, txt);
                            }
                            break;
                        default:
                            if (_this.errorCallback && _this.thisObject) {
                                _this.errorCallback.call(_this.thisObject, txt);
                            }
                            break;
                    }
                }
            };
            this.xhr.onerror = function (err) {
                _this.abnormal();
            };
            if (this.sendData)
                this.xhr.send(this.sendData);
            else
                this.xhr.send();
            if (this.needTip) {
                this.timeOutId = setTimeout(this.ioError.bind(this), 10000);
            }
        };
        /**
         * io网络超时
         */
        HttpItem.prototype.ioError = function () {
            if (this.timeOutId)
                clearTimeout(this.timeOutId);
            this.timeOutId = null;
            if (!this.isload && this.needTip) {
                //提示网络超时吗
                this.abnormal();
            }
            this.xhr.abort();
        };
        /**提示网络异常*/
        HttpItem.prototype.abnormal = function () {
            game.NotifyManager.getInstance().distribute(NotifyConst.connectError, "lbl_network_error");
        };
        return HttpItem;
    }());
    game.HttpItem = HttpItem;
    __reflect(HttpItem.prototype, "game.HttpItem");
})(game || (game = {}));
var game;
(function (game) {
    /**
     * @desc 处理一些http请求的类
     */
    var HttpUtil = (function () {
        function HttpUtil() {
        }
        /**
         * 发送http请求
         */
        HttpUtil.sendRequest = function (method, url, successCallBack, thisObject, errorCallback, sendData) {
            if (method === void 0) { method = "GET"; }
            if (successCallBack === void 0) { successCallBack = null; }
            if (thisObject === void 0) { thisObject = null; }
            if (errorCallback === void 0) { errorCallback = null; }
            if (sendData === void 0) { sendData = ""; }
            var httpItem = new game.HttpItem(url, sendData, successCallBack, errorCallback, thisObject, method);
            httpItem.load();
        };
        HttpUtil.prototype.sendPostRequest = function () {
            // var request = new egret.HttpRequest();
            // request.responseType = egret.HttpResponseType.TEXT;
            // request.open("http://gapi.vzboo.net/Home/api/winLoseRecord?gameid=6&wid=1", egret.HttpMethod.POST);
            // request.send();
            // request.addEventListener(egret.Event.COMPLETE, this.onPostComplete, this);
            // request.addEventListener(egret.IOErrorEvent.IO_ERROR, this.onPostIOError, this);
            // request.addEventListener(egret.ProgressEvent.PROGRESS, this.onPostProgress, this);
        };
        HttpUtil.prototype.onPostComplete = function (event) {
            var request = event.currentTarget;
            egret.log("post data : ", request.response);
        };
        HttpUtil.prototype.onPostIOError = function (event) {
            egret.log("post error : " + event);
        };
        HttpUtil.prototype.onPostProgress = function (event) {
            egret.log("post progress : " + Math.floor(100 * event.bytesLoaded / event.bytesTotal) + "%");
        };
        return HttpUtil;
    }());
    game.HttpUtil = HttpUtil;
    __reflect(HttpUtil.prototype, "game.HttpUtil");
})(game || (game = {}));
var game;
(function (game) {
    var GameSocket = (function () {
        function GameSocket() {
            this.socket = new egret.WebSocket();
            this.socket.type = egret.WebSocket.TYPE_STRING;
            this.socket.addEventListener(egret.Event.CONNECT, this.onSocketConnected, this);
            this.socket.addEventListener(egret.Event.CLOSE, this.onSocketClose, this);
            this.socket.addEventListener(egret.ProgressEvent.SOCKET_DATA, this.onDataIn, this);
            this.socket.addEventListener(egret.IOErrorEvent.IO_ERROR, this.onIoError, this);
        }
        GameSocket.prototype.connect = function (host, port, callback, callbackobj, errCallback) {
            this.successCallback = callback;
            this.successCallbackObj = callbackobj;
            this.errCallback = errCallback;
            this.socket.connect(host, port);
        };
        GameSocket.prototype.connectByUrl = function (url, callback, callbackobj, errCallback) {
            // console.log("socket connectByUrl:" + url);
            this.successCallback = callback;
            this.successCallbackObj = callbackobj;
            this.errCallback = errCallback;
            this.socket.connectByUrl(url);
        };
        GameSocket.prototype.disconnect = function () {
            this.isCloseBySelf = true;
            this.socket.close();
            console.log("客户端主动断开socket！");
        };
        /**
         * 当socket连接上
         */
        GameSocket.prototype.onSocketConnected = function (evt) {
            this.isCloseBySelf = false;
            if (this.successCallback && this.successCallbackObj) {
                this.successCallback.call(this.successCallbackObj);
            }
        };
        /**
         * 当socket关闭了
         */
        GameSocket.prototype.onSocketClose = function (evt) {
            console.warn("socket断开了~！");
            game.NotifyManager.getInstance().distribute(NotifyConst.connectError, "lbl_network_error");
        };
        /**
         * 当发生IO错误
         */
        GameSocket.prototype.onIoError = function (evt) {
            // DebugUtil.release('socket IO错误');
            game.NotifyManager.getInstance().distribute(NotifyConst.connectError, "lbl_network_error");
        };
        /**
         * 接收数据返回
         */
        GameSocket.prototype.onDataIn = function (evt) {
            if (this.socket) {
                var str = this.socket.readUTF();
                // DebugUtil.debug("received data:"+str);
                // let decodestr = Main.decryptByDES(str,GlobalConfig.desKey);
                // if(decodestr.length == 0){
                // 	decodestr = str;
                // }
                // console.log("received data:" + str);
                var message = JSON.parse(str);
                game.TopicManager.getInstance().onDataIn(message);
            }
        };
        /**
         * 发送数据到服务器
         */
        GameSocket.prototype.sendCMD = function (str) {
            if (this.socket && this.socket.connected) {
                // str = Main.encryptByDES(str,GlobalConfig.desKey);
                // DebugUtil.debug(str, LogConst.LOGTYPE_MSG_FIRED);
                this.socket.writeUTF(str);
                this.socket.flush();
            }
        };
        return GameSocket;
    }());
    game.GameSocket = GameSocket;
    __reflect(GameSocket.prototype, "game.GameSocket");
})(game || (game = {}));
var game;
(function (game) {
    /**
     *
     * @desc 封装一个请求回调函数
     *
     */
    var RequestHandler = (function () {
        function RequestHandler(callBack, thisObject, isRPC, timeOutCallback, timeout, clientData) {
            if (isRPC === void 0) { isRPC = false; }
            if (timeOutCallback === void 0) { timeOutCallback = null; }
            if (timeout === void 0) { timeout = 3000; }
            if (clientData === void 0) { clientData = null; }
            this._sendTime = 0; //协议发送的时候所处的时间
            this._timeout = 0; //设定超时时间,默认单位是毫秒
            this._clientData = null; //客户端回调参数，如果需要的话
            this._callBack = callBack;
            this._thisObject = thisObject;
            this._isRPC = isRPC;
            this._timeOutCallback = timeOutCallback;
            this._timeout = timeout;
            //this._sendTime = model.SFSingleModel.getInstance().serverTime;
            this._clientData = clientData;
        }
        return RequestHandler;
    }());
    game.RequestHandler = RequestHandler;
    __reflect(RequestHandler.prototype, "game.RequestHandler");
})(game || (game = {}));
//////////////////////////////////////////////////////////////////////////////////////
//
//  Copyright (c) 2014-present, Egret Technology.
//  All rights reserved.
//  Redistribution and use in source and binary forms, with or without
//  modification, are permitted provided that the following conditions are met:
//
//     * Redistributions of source code must retain the above copyright
//       notice, this list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above copyright
//       notice, this list of conditions and the following disclaimer in the
//       documentation and/or other materials provided with the distribution.
//     * Neither the name of the Egret nor the
//       names of its contributors may be used to endorse or promote products
//       derived from this software without specific prior written permission.
//
//  THIS SOFTWARE IS PROVIDED BY EGRET AND CONTRIBUTORS "AS IS" AND ANY EXPRESS
//  OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
//  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
//  IN NO EVENT SHALL EGRET AND CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
//  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
//  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;LOSS OF USE, DATA,
//  OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
//  LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
//  NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
//  EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
//////////////////////////////////////////////////////////////////////////////////////
var ThemeAdapter = (function () {
    function ThemeAdapter() {
    }
    /**
     * 解析主题
     * @param url 待解析的主题url
     * @param onSuccess 解析完成回调函数，示例：compFunc(e:egret.Event):void;
     * @param onError 解析失败回调函数，示例：errorFunc():void;
     * @param thisObject 回调的this引用
     */
    ThemeAdapter.prototype.getTheme = function (url, onSuccess, onError, thisObject) {
        var _this = this;
        function onResGet(e) {
            onSuccess.call(thisObject, e);
        }
        function onResError(e) {
            if (e.resItem.url == url) {
                RES.removeEventListener(RES.ResourceEvent.ITEM_LOAD_ERROR, onResError, null);
                onError.call(thisObject);
            }
        }
        if (typeof generateEUI !== 'undefined') {
            egret.callLater(function () {
                onSuccess.call(thisObject, generateEUI);
            }, this);
        }
        else if (typeof generateEUI2 !== 'undefined') {
            RES.getResByUrl("resource/gameEui.json", function (data, url) {
                window["JSONParseClass"]["setData"](data);
                egret.callLater(function () {
                    onSuccess.call(thisObject, generateEUI2);
                }, _this);
            }, this, RES.ResourceItem.TYPE_JSON);
        }
        else if (typeof generateJSON !== 'undefined') {
            if (url.indexOf(".exml") > -1) {
                var dataPath = url.split("/");
                dataPath.pop();
                var dirPath = dataPath.join("/") + "_EUI.json";
                if (!generateJSON.paths[url]) {
                    RES.getResByUrl(dirPath, function (data) {
                        window["JSONParseClass"]["setData"](data);
                        egret.callLater(function () {
                            onSuccess.call(thisObject, generateJSON.paths[url]);
                        }, _this);
                    }, this, RES.ResourceItem.TYPE_JSON);
                }
                else {
                    egret.callLater(function () {
                        onSuccess.call(thisObject, generateJSON.paths[url]);
                    }, this);
                }
            }
            else {
                egret.callLater(function () {
                    onSuccess.call(thisObject, generateJSON);
                }, this);
            }
        }
        else {
            RES.addEventListener(RES.ResourceEvent.ITEM_LOAD_ERROR, onResError, null);
            RES.getResByUrl(url, onResGet, this, RES.ResourceItem.TYPE_TEXT);
        }
    };
    return ThemeAdapter;
}());
__reflect(ThemeAdapter.prototype, "ThemeAdapter", ["eui.IThemeAdapter"]);
var game;
(function (game) {
    /**
     * 通知管理类
     * @public distribute Mediator、Server之间指派事件
     * @public distributeByUI UI指派事件给Mediator
     */
    var NotifyManager = (function () {
        function NotifyManager() {
            this.ObjDic = new Object();
            this.typeDic = new Object();
        }
        NotifyManager.getInstance = function () {
            if (this.instance == null) {
                this.instance = new NotifyManager();
            }
            return this.instance;
        };
        // -----------------------------------------------------------
        /**
         * Mediator、Server之间指派事件
         * @param type 事件类型
         * @param body 事件数据
         * @param className 可选，如果className存在，则会派发给指定类
         */
        NotifyManager.prototype.distribute = function (type, body, className) {
            var _this = this;
            var n;
            this.typeDic[type] && this.typeDic[type].forEach(function (name) {
                if (!className || className === name) {
                    n = _this.ObjDic[name];
                    n && n.handleNotification(type, body);
                }
            });
        };
        /**
         * 添加一个对象到字典中
         * @param name {string} 类名
         * @param obj {Object} 对象
         */
        NotifyManager.prototype.addObj = function (name, obj) {
            if (this.ObjDic[name]) {
                // DebugUtil.debug("Notify repeat Register:" + name);
            }
            else {
                this.ObjDic[name] = obj;
                // 配置type字典
                this.configurationType(name, obj);
            }
        };
        /**
         * 配置type字典
         * @param name {string} 类名
         * @param obj {Object} 对象
         */
        NotifyManager.prototype.configurationType = function (name, obj) {
            var _this = this;
            // let n = <INotification>obj;
            // if (n) {
            //     let list = n.listNotification();
            //     let len = list.length;
            //     let type = -1;
            //     for (let i = 0; i < len; i++) {
            //         type = list[i];
            //         if (this.typeDic[type]) {
            //             //添加到末尾
            //             this.typeDic[type].push(name);
            //         }
            //         else {
            //             this.typeDic[type] = [name];
            //         }
            //     }
            // }
            var n = obj;
            n && n.listNotification().forEach(function (type) {
                if (_this.typeDic[type]) {
                    _this.typeDic[type].push(name); // 添加到末尾
                }
                else {
                    _this.typeDic[type] = [name];
                }
            });
        };
        /**
         * 从字典中移除一个对象
         * @param name {string} 类名
         */
        NotifyManager.prototype.removeObj = function (name) {
            if (this.ObjDic[name]) {
                this.cleanType(name);
                delete this.ObjDic[name];
            }
        };
        /**
         * 清除类型
         */
        NotifyManager.prototype.cleanType = function (name) {
            var n = this.ObjDic[name];
            if (n) {
                var list = n.listNotification();
                var len = list.length;
                var type = void 0;
                var arr = void 0;
                for (var i = 0; i < len; i++) {
                    type = list[i];
                    arr = this.typeDic[type];
                    if (arr) {
                        var index = arr.indexOf(name);
                        if (index > -1) {
                            arr.splice(index, 1);
                            if (arr.length > 0) {
                                this.typeDic[type] = arr;
                            }
                            else {
                                arr = null;
                                this.typeDic[type] = null;
                                delete this.typeDic[type];
                            }
                        }
                    }
                }
            }
        };
        return NotifyManager;
    }());
    game.NotifyManager = NotifyManager;
    __reflect(NotifyManager.prototype, "game.NotifyManager");
})(game || (game = {}));
//////////////////////////////////////////////////////////////////////////////////////
//
//  Copyright (c) 2014-present, Egret Technology.
//  All rights reserved.
//  Redistribution and use in source and binary forms, with or without
//  modification, are permitted provided that the following conditions are met:
//
//     * Redistributions of source code must retain the above copyright
//       notice, this list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above copyright
//       notice, this list of conditions and the following disclaimer in the
//       documentation and/or other materials provided with the distribution.
//     * Neither the name of the Egret nor the
//       names of its contributors may be used to endorse or promote products
//       derived from this software without specific prior written permission.
//
//  THIS SOFTWARE IS PROVIDED BY EGRET AND CONTRIBUTORS "AS IS" AND ANY EXPRESS
//  OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
//  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
//  IN NO EVENT SHALL EGRET AND CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
//  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
//  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;LOSS OF USE, DATA,
//  OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
//  LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
//  NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
//  EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
//////////////////////////////////////////////////////////////////////////////////////
var LoadingUI = (function (_super) {
    __extends(LoadingUI, _super);
    function LoadingUI() {
        var _this = _super.call(this) || this;
        _this.skinName = "resource/skins/LoadingSkin.exml";
        _this.addEventListener(egret.Event.ADDED_TO_STAGE, _this.init, _this);
        return _this;
    }
    /** 初始化操作 */
    LoadingUI.prototype.init = function () {
        this.initAdaptation();
        this.img_loading.width = 0;
    };
    /** 适配处理 */
    LoadingUI.prototype.initAdaptation = function () {
        this.width = this.stage.stageWidth;
        this.height = this.stage.stageHeight;
        var scaleX = this.stage.stageWidth / 1080;
        var scaleY = this.stage.stageHeight / 1920;
        if (scaleY > 1) {
            scaleY = 1;
        }
        if (scaleX < 1) {
            scaleX = 1;
        }
        // this.img_bg.scaleX = scaleX;
        // this.img_bg.scaleY = scaleY;
    };
    /** 关闭loading */
    LoadingUI.prototype.close = function () {
    };
    LoadingUI.prototype.onProgress = function (current, total) {
        this.img_loading.width = current / total * 742;
        // this.textField.text = `Loading...${current}/${total}`;
    };
    return LoadingUI;
}(eui.Component));
__reflect(LoadingUI.prototype, "LoadingUI", ["RES.PromiseTaskReporter"]);
var game;
(function (game) {
    var SoundPlayer = (function () {
        function SoundPlayer() {
        }
        /**播放音效 */
        SoundPlayer.playSound = function (name, callback, callbackObj) {
            if (!this.isSoundOpen)
                return;
            var mp3 = RES.getRes(name);
            var sound = mp3;
            var channel = sound.play(0, 1);
            channel.addEventListener(egret.Event.SOUND_COMPLETE, function () {
                if (callback) {
                    callback.apply(callbackObj);
                }
            }, this);
        };
        SoundPlayer.playSoundWav = function (name, callback, callbackObj) {
            if (!this.isSoundOpen)
                return;
            var wav = RES.getRes(name);
            var sound = wav;
            var channel = sound.play(0, 1);
            channel.addEventListener(egret.Event.SOUND_COMPLETE, function () {
                if (callback)
                    callback.apply(callbackObj);
            }, this);
        };
        /**播放音乐 */
        SoundPlayer.playMusic = function (name) {
            if (!this.isMusicOpen)
                return;
            if (this.musicChannel) {
                this.musicChannel.stop();
            }
            var sound = RES.getRes(name);
            this.musicChannel = sound.play(0);
        };
        /**打开音效 */
        SoundPlayer.openSound = function (b) {
            this.isSoundOpen = b;
            this.isMusicOpen = b;
            if (b == false) {
                if (this.musicChannel) {
                    this.musicChannel.stop();
                    this.musicChannel = null;
                }
                while (this.effectChannels.length > 0) {
                    var c = this.effectChannels.pop();
                    if (c) {
                        c.stop();
                    }
                }
            }
        };
        /** 打开背景音乐 */
        SoundPlayer.openMusic = function () {
            this.isMusicOpen = true;
        };
        /**关闭背景音乐 */
        SoundPlayer.closeMusic = function () {
            this.isMusicOpen = false;
            if (this.musicChannel) {
                this.musicChannel.stop();
                this.musicChannel = null;
            }
            while (this.effectChannels.length > 0) {
                var c = this.effectChannels.pop();
                if (c) {
                    c.stop();
                }
            }
        };
        SoundPlayer.effectChannels = [];
        SoundPlayer.isSoundOpen = false;
        SoundPlayer.isMusicOpen = false;
        return SoundPlayer;
    }());
    game.SoundPlayer = SoundPlayer;
    __reflect(SoundPlayer.prototype, "game.SoundPlayer");
})(game || (game = {}));
var topic;
(function (topic) {
    /**基础请求类 */
    var BaseRequest = (function () {
        function BaseRequest() {
        }
        return BaseRequest;
    }());
    topic.BaseRequest = BaseRequest;
    __reflect(BaseRequest.prototype, "topic.BaseRequest");
})(topic || (topic = {}));
var topic;
(function (topic) {
    /**基础返回类 */
    var BaseResponse = (function () {
        function BaseResponse() {
            /**Request的唯一标识 */
            this.seq = 0;
            /**
             * 返回类型0、1
             * 0.成功的返回
             * 1.失败的返回
             */
            this.code = 0;
        }
        /**将原始json数据转换成可读的对象 */
        BaseResponse.prototype.decode = function (data) {
            if (data.seq) {
                this.code = data.code;
                this.seq = data.seq;
                //copy一个出来,避免和底层的snapshot造成冲突
                this.snapshot = game.ObjectUtil.copyObject(data.snapshot);
                this.isPush = false;
            }
            else if (data.topic && data.push) {
                this.snapshot = data.push;
                this.isPush = true;
            }
            this.isPush = false;
        };
        return BaseResponse;
    }());
    topic.BaseResponse = BaseResponse;
    __reflect(BaseResponse.prototype, "topic.BaseResponse");
})(topic || (topic = {}));
var game;
(function (game) {
    /**
     *
     * @desc 字典
     *
     */
    var Dictionary = (function () {
        function Dictionary() {
            this.dict = {};
        }
        /**
         * 根据key来设置value
         */
        Dictionary.prototype.setValue = function (key, value) {
            this.dict[key] = value;
        };
        /**
         * 根据key获得value
         */
        Dictionary.prototype.getValue = function (key) {
            return this.dict[key];
        };
        /**
         * 获取所有key
         */
        Dictionary.prototype.getAllKey = function () {
            var keys = [];
            for (var key in this.dict) {
                keys.push(key);
            }
            return keys;
        };
        /**
         * 获取所有value
         */
        Dictionary.prototype.getAllValue = function () {
            var values = [];
            for (var key in this.dict) {
                values.push(this.dict[key]);
            }
            return values;
        };
        /**
         * 检测是否包含某个key
         */
        Dictionary.prototype.containsKey = function (key) {
            return this.dict[key] == null ? false : true;
        };
        /**
         * 移除某个key
         */
        Dictionary.prototype.removeKey = function (key) {
            this.dict[key] = null;
            delete this.dict[key];
        };
        /**
         * 移除某个value
         * temp:只能移除第一个value
         */
        Dictionary.prototype.removeValue = function (value) {
            for (var key in this.dict) {
                if (this.dict[key] == value) {
                    this.removeKey(key);
                    break;
                }
            }
        };
        /**
         * 根据Value获得Key
         */
        Dictionary.prototype.getKeyByValue = function (value) {
            for (var key in this.dict) {
                if (this.dict[key] == value) {
                    return key;
                }
            }
            return null;
        };
        /**
         * 获取key的个数
         */
        Dictionary.prototype.getKeyLength = function () {
            var count = 0;
            for (var key in this.dict) {
                count++;
            }
            return count;
        };
        /**
         * 清除所有数据
         */
        Dictionary.prototype.clear = function () {
            this.dict = null;
            this.dict = {};
        };
        Dictionary.prototype.toString = function () {
            return this.dict.toString();
        };
        return Dictionary;
    }());
    game.Dictionary = Dictionary;
    __reflect(Dictionary.prototype, "game.Dictionary");
})(game || (game = {}));
var game;
(function (game) {
    /**
     * @desc 数字工具类
     */
    var NumberUtil = (function () {
        function NumberUtil() {
        }
        /**返回三位数的数字 前面用0补齐*/
        NumberUtil.getNum3 = function (n) {
            if (n >= 0 && n < 10)
                return "00" + n;
            if (n >= 10 && n < 100)
                return "0" + n;
            if (n >= 100)
                return "" + n;
            return "";
        };
        NumberUtil.getMax = function (arr) {
            if (arr === void 0) { arr = []; }
            var max;
            if (arr.length > 0) {
                max = arr[0];
                for (var i = 0; i < arr.length; i++) {
                    if (arr[i] > max) {
                        max = arr[i];
                    }
                }
            }
            else {
                max = 0;
            }
            return max;
        };
        NumberUtil.getMin = function (arr) {
            if (arr === void 0) { arr = []; }
            var min;
            if (arr.length > 0) {
                min = arr[0];
                for (var i = 0; i < arr.length; i++) {
                    if (arr[i] < min) {
                        min = arr[i];
                    }
                }
            }
            else {
                min = 0;
            }
            return min;
        };
        /**数字处理转化为带汉字单位的小数 */
        NumberUtil.numberToString = function (num) {
            if (num == 0 || !num) {
                return "0";
            }
            var number = 0;
            var result = "";
            var suffix = "";
            var str = "";
            if (num >= 100000000) {
                number = num / 100000000;
                suffix = "亿";
            }
            else if (num >= 10000 && num < 100000000) {
                number = num / 10000;
                suffix = "万";
            }
            else if (num >= 1000 && num < 10000) {
                number = num / 1000;
                suffix = "千";
            }
            else {
                number = num;
                suffix = "";
            }
            if ((number + "").indexOf(".") != -1) {
                if ((number + "").split(".")[1].charAt(1)) {
                    str = (number + "").split(".")[0] + "." + (number + "").split(".")[1].charAt(0) + (number + "").split(".")[1].charAt(1);
                }
                else {
                    str = (number + "").split(".")[0] + "." + (number + "").split(".")[1].charAt(0) + "0";
                }
                if (str.split(".")[1].indexOf("0") != -1) {
                    if (str.split(".")[1] == "00") {
                        result = str.split(".")[0] + suffix;
                    }
                    else if (str.split(".")[1].charAt(1) == "0") {
                        result = str.split(".")[0] + "." + str.split(".")[1].charAt(0) + suffix;
                    }
                    else {
                        result = str + suffix;
                    }
                }
                else {
                    result = str + suffix;
                }
            }
            else {
                result = number + suffix;
            }
            // str = number.toFixed(2);
            // str.split(".")[1] == "00" ? result = str.split(".")[0] + suffix : result = str + suffix;
            return result;
        };
        /**
         * 传入数字，返回千位逗号隔开的字符串效果
         * @param num 单位为分
         * @param isShort 是否为简写-->例如：10000000 --> 100k 1为大于等于1000就开始缩写 2为大于100000才开始缩写 3是保留一位小数
         */
        NumberUtil.getSplitNumStr = function (num, isShort) {
            if (isShort === void 0) { isShort = 0; }
            if (typeof num != "number") {
                return "0";
            }
            var preFix = num >= 0 ? "" : "-";
            num = Math.abs(num);
            num = num || 0;
            num = num / 100;
            //小数部分
            var decimal = "";
            var code = num.toString(10);
            if (code.indexOf(".") != -1) {
                // code = num.toFixed(2);
                var a = (num + "").split(".");
                if (a[1].length == 1) {
                    a[1] = a[1] + "0";
                }
                else {
                    a[1] = a[1].slice(0, 2);
                }
                code = a.join(".");
            }
            if (isShort) {
                code = this.num2short(num, isShort);
            }
            var data = code.split(".");
            var integer = data[0];
            var tailData = data[1];
            var DecimalPoint = "."; //小数点
            var Semicolon = ","; //分隔号
            // switch(LanguageConstTypes.AmountType)
            // {
            //     case 0:
            //         DecimalPoint = ".";
            //         Semicolon = ",";
            //         break;
            //     case 1:
            //         DecimalPoint = ",";
            //         Semicolon = ".";
            //         break;
            // }
            if (tailData) {
                if (tailData.length == 2 && tailData[1] == "0") {
                    tailData = tailData.substr(0, 1);
                    decimal = DecimalPoint + tailData;
                }
                else if (tailData.length == 2 && tailData[0] == "0" && tailData[1] == "0") {
                    tailData = "";
                    decimal = "";
                }
                else {
                    decimal = DecimalPoint + tailData;
                }
            }
            var result = integer.replace(/\B(?=(?:\d{3})+$)/g, Semicolon) + decimal;
            return preFix + result;
        };
        /**
         * 1000-->K
           1000 000-->M
           1 000 000 000-->B
           1 000 000 000 000-->T
         */
        NumberUtil.num2short = function (value, type) {
            var num = 0;
            var result = "";
            var suffix = "";
            var mini = 1000;
            if (type == 2) {
                mini = 1000;
            }
            if (value >= mini && value < 1000000) {
                num = value / 1000;
                suffix = "K";
            }
            else {
                num = value;
            }
            result = num.toString();
            var actNum = 4;
            if (result.indexOf(".") > -1 && suffix == "") {
                actNum = 5;
            }
            if (result.length > actNum) {
                if (type == 1) {
                    result = result.slice(0, actNum);
                }
            }
            var bNum = parseFloat(result); //小数点后保留两位
            // let rNum = (Math.floor(bNum * 100))/100;
            //小数点后只显示一位小数
            if (type == 2 || type == 3) {
                bNum = (Math.floor(bNum * 10)) / 10;
            }
            else {
                if (suffix != "") {
                    bNum = Math.floor(bNum); //策划要求去掉小数
                }
            }
            return bNum + suffix;
        };
        /**返回经过处理的整十数
         * param 含一位小数字符
        */
        NumberUtil.stringToNumber = function (str) {
            var txt = str;
            var num;
            num = Number(txt);
            num.toFixed(1);
            num *= 10;
            num.toFixed(0);
            num *= 10;
            return num;
        };
        /**返回经过精度处理的2位小数,如果这个2位小数的末位是0，会省去0*/
        NumberUtil.getCheckedNumber = function (n) {
            var n0 = parseInt(n.toFixed(0));
            var n1 = parseFloat(n.toFixed(1));
            var n2 = parseFloat(n.toFixed(2));
            if (n2 == n1) {
                if (n1 == n0) {
                    return n0;
                }
                else {
                    return n1;
                }
            }
            else {
                return n2;
            }
        };
        /** 1-10数字转换成文字 */
        NumberUtil.numberToBeString = function (num) {
            var str;
            switch (num) {
                case 1:
                    str = '一';
                    break;
                case 2:
                    str = '二';
                    break;
                case 3:
                    str = '三';
                    break;
                case 4:
                    str = '四';
                    break;
                case 5:
                    str = '五';
                    break;
                case 6:
                    str = '六';
                    break;
                case 7:
                    str = '七';
                    break;
                case 8:
                    str = '八';
                    break;
                case 9:
                    str = '九';
                    break;
                case 0:
                case 10:
                    str = '十';
                    break;
            }
            return str;
        };
        return NumberUtil;
    }());
    game.NumberUtil = NumberUtil;
    __reflect(NumberUtil.prototype, "game.NumberUtil");
})(game || (game = {}));
var game;
(function (game) {
    var ObjectUtil;
    (function (ObjectUtil) {
        var compareObject = function (oldVal, newVal, smart) {
            var result, flag = false;
            switch ([oldVal, newVal].filter(function (item) { return item instanceof Object; }).length) {
                // 新旧值都是Object的情况下，进行递归比较得到结果
                case 2:
                    var oldKey_1 = Object.keys(oldVal), newKey = Object.keys(newVal);
                    // 默认情况下，对数组只考虑增量，不考虑复杂变化
                    if (!smart && oldVal instanceof Array && newVal instanceof Array) {
                        result = [];
                        newVal.forEach(function (item) {
                            if (!oldVal.some(function (old) { return ObjectUtil.isEqualObject(old, item); })) {
                                result.push(ObjectUtil.copyObject(item));
                                flag = true;
                            }
                        });
                    }
                    else {
                        result = newVal instanceof Array ? [] : {};
                        oldKey_1.forEach(function (item) {
                            var temp = compareObject(oldVal[item], newVal[item], smart);
                            if (temp.flag) {
                                result[item] = temp.result;
                                flag = true;
                            }
                        });
                        newKey.forEach(function (item) {
                            if (oldKey_1.indexOf(item) === -1) {
                                result[item] = ObjectUtil.copyObject(newVal[item]);
                                flag = true;
                            }
                        });
                    }
                    break;
                // 只有其中一个值是Object的情况下，如果新值是Object，那么将新值的拷贝作为结果，否则直接将新值作为结果
                case 1:
                    result = newVal instanceof Object ? ObjectUtil.copyObject(newVal) : newVal;
                    flag = true;
                    break;
                // 新旧值都不是Object的情况下，如果新旧值不相等，那么将新值作为结果
                default:
                    if (oldVal !== newVal) {
                        result = newVal;
                        flag = true;
                    }
            }
            return {
                result: result,
                flag: flag
            };
        };
        ObjectUtil.minusObject = function (oldVal, newVal, smart) { return compareObject(oldVal, newVal, smart).result; };
        ObjectUtil.copyObject = function (obj) { return ObjectUtil.minusObject({}, obj); };
        ObjectUtil.isEqualObject = function (oldVal, newVal) { return !compareObject(oldVal, newVal, true).flag; };
        ObjectUtil.isEmptyObject = function (obj, unsafe) { return unsafe && (obj === undefined || obj === null) ? true : ObjectUtil.isEqualObject({}, obj); };
    })(ObjectUtil = game.ObjectUtil || (game.ObjectUtil = {}));
})(game || (game = {}));
var game;
(function (game) {
    /**
    *
    * @author
    *
    */
    var StageUtil = (function () {
        function StageUtil() {
        }
        Object.defineProperty(StageUtil, "width", {
            get: function () {
                if (this.stage)
                    return this.stage.stageWidth;
                else
                    return -1;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(StageUtil, "height", {
            get: function () {
                if (this.stage)
                    return this.stage.stageHeight;
                else
                    return -1;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(StageUtil, "frameRate", {
            get: function () {
                if (this.stage)
                    return this.stage.frameRate;
                else
                    return -1;
            },
            enumerable: true,
            configurable: true
        });
        /**将内容复制到剪切板 */
        StageUtil.copyTxt = function (txt) {
            window["copyTxt"](txt);
        };
        /**设置屏幕同时可触摸数量 */
        StageUtil.maxTouches = function (num) {
            if (this.stage)
                this.stage.maxTouches = num;
        };
        StageUtil.DesignWidth = 1080;
        StageUtil.DesignHeight = 1920;
        StageUtil.canvasHeight = 0;
        return StageUtil;
    }());
    game.StageUtil = StageUtil;
    __reflect(StageUtil.prototype, "game.StageUtil");
})(game || (game = {}));
var NotifyConst;
(function (NotifyConst) {
    NotifyConst[NotifyConst["connectError"] = 1] = "connectError";
})(NotifyConst || (NotifyConst = {}));
/** Controller通知UI的枚举 */
var UiCommand;
(function (UiCommand) {
    /** 创建场景 */
    UiCommand[UiCommand["createScence"] = 0] = "createScence";
    /** 显示日记 */
    UiCommand[UiCommand["showDiary"] = 1] = "showDiary";
    /** 初始化系列列表 */
    UiCommand[UiCommand["initSeriesList"] = 2] = "initSeriesList";
    /** 刷新关卡数 */
    UiCommand[UiCommand["updateCheckNum"] = 3] = "updateCheckNum";
    /** 显示会话列表 */
    UiCommand[UiCommand["showSectionList"] = 4] = "showSectionList";
    /** 显示关卡列表 */
    UiCommand[UiCommand["showStageList"] = 5] = "showStageList";
    /** 初始化答案界面 */
    UiCommand[UiCommand["initAnswer"] = 6] = "initAnswer";
    /** 游戏通关 */
    UiCommand[UiCommand["gameClearance"] = 7] = "gameClearance";
    /** 显示提示 */
    UiCommand[UiCommand["showTip"] = 8] = "showTip";
})(UiCommand || (UiCommand = {}));
/** UI通知Controller的事件 */
var UiNotifyConst;
(function (UiNotifyConst) {
    UiNotifyConst[UiNotifyConst["start"] = 200] = "start";
    /** 初始化舞台 */
    UiNotifyConst[UiNotifyConst["initStage"] = 201] = "initStage";
    /** 再次推理 */
    UiNotifyConst[UiNotifyConst["againGame"] = 202] = "againGame";
    /** 获取日记内容 */
    UiNotifyConst[UiNotifyConst["getDiary"] = 203] = "getDiary";
    /** 获取关卡回话列表 */
    UiNotifyConst[UiNotifyConst["getStageSectionList"] = 204] = "getStageSectionList";
    /** 刷新关卡数（已破案/总关数） */
    UiNotifyConst[UiNotifyConst["updateCheckNum"] = 205] = "updateCheckNum";
    /** 加入指定会话 */
    UiNotifyConst[UiNotifyConst["joinAppointSection"] = 206] = "joinAppointSection";
    /** 获取关卡列表 */
    UiNotifyConst[UiNotifyConst["getStageList"] = 207] = "getStageList";
    /** 保存记录 */
    UiNotifyConst[UiNotifyConst["saveRecord"] = 208] = "saveRecord";
    /** 下一关 */
    UiNotifyConst[UiNotifyConst["joinNextStage"] = 209] = "joinNextStage";
})(UiNotifyConst || (UiNotifyConst = {}));
var game;
(function (game) {
    var Controller = (function (_super) {
        __extends(Controller, _super);
        function Controller() {
            return _super.call(this) || this;
        }
        Controller.getInstance = function () {
            if (!this._instance)
                this._instance = new Controller();
            return this._instance;
        };
        /**
         * @extends BaseController
         */
        Controller.prototype.start = function () {
            game.Service.init();
            this.openGameUI();
        };
        /** 打开主页 */
        Controller.prototype.openGameUI = function () {
            this.enterUI(new game.GameUI, game.LayerConst.Layer_UI);
        };
        /**
         * @extends BaseController
        * 初始化UI数据
         */
        Controller.prototype.initData = function () {
        };
        /**
         * @extends BaseController
         * 罗列要接收的通知
         */
        Controller.prototype.listNotification = function () {
            return [
                UiNotifyConst.initStage,
                UiNotifyConst.againGame,
                UiNotifyConst.getDiary,
                UiNotifyConst.updateCheckNum,
                UiNotifyConst.getStageSectionList,
                UiNotifyConst.joinAppointSection,
                UiNotifyConst.getStageList,
                UiNotifyConst.saveRecord,
                UiNotifyConst.joinNextStage
            ];
        };
        ;
        /**
         * @extends BaseController
         * 接收通知
         */
        Controller.prototype.handleNotification = function (type, body) {
            switch (type) {
                case UiNotifyConst.initStage:
                    this.initStage();
                    break;
                case UiNotifyConst.againGame:
                    this.againGame();
                    break;
                case UiNotifyConst.getDiary:
                    this.getDiary();
                    break;
                case UiNotifyConst.updateCheckNum:
                    this.updateCheckNum();
                    break;
                case UiNotifyConst.getStageSectionList:
                    this.getStageSectionList(body);
                    break;
                case UiNotifyConst.joinAppointSection:
                    this.joinAppointSection(body);
                    break;
                case UiNotifyConst.getStageList:
                    this.getStageList(body);
                    break;
                case UiNotifyConst.saveRecord:
                    this.saveRecord();
                    break;
                case UiNotifyConst.joinNextStage:
                    this.joinNextStage();
                    break;
            }
        };
        /** 加载资源 */
        Controller.prototype.loadRes = function () {
            var seriesArr = RES.getRes("StageConfig_json");
            var _loop_1 = function (i) {
                var stageArr = RES.getRes(seriesArr.stage[i].CnStagePath);
                stageArr.stage.forEach(function (stage) {
                    RES.loadGroup("stage_" + seriesArr.stage[i].stageId + "_" + stage.stageId);
                });
            };
            for (var i = 0; i < seriesArr.stageNum; i++) {
                _loop_1(i);
            }
        };
        /** 初始化关卡 */
        Controller.prototype.initStage = function () {
            var _this = this;
            //  egret.localStorage.clear();
            this.seriesArr = RES.getRes("StageConfig_json");
            var recordStr = egret.localStorage.getItem(game.GlobalConfig.Record);
            var model = game.Model.getInstance();
            model.record = [];
            //游戏记录处理
            if (recordStr) {
                model.record = JSON.parse(recordStr);
                console.log("本地保存的通关记录", model.record);
                var nowStageId = 0;
                var nowSeriesId = 0;
                var nowSectionId = 0;
                //初始化关卡
                for (var i = 0; i < model.record.length; i++) {
                    if (model.record[i].record.sectionId > 0 && model.record[i].record.sectionId <= 4) {
                        nowSectionId = model.record[i].record.sectionId;
                        nowStageId = model.record[i].record.stageId;
                        nowSeriesId = model.record[i].seriesId;
                        break;
                    }
                }
                //设置初始化关卡数据
                for (var i = 0; i < this.seriesArr.stageNum; i++) {
                    if (this.seriesArr.stage[i].stageId == nowSeriesId) {
                        this.nowSeriesId = this.seriesArr.stage[i].stageId;
                        this.stageArr = RES.getRes(this.seriesArr.stage[i].CnStagePath); //读取该系列的关卡总表配置
                        for (var j = 0; j < this.stageArr.stage.length; j++) {
                            if (this.stageArr.stage[j].stageId == nowStageId) {
                                this.nowStage = this.stageArr.stage[j];
                                for (var k = 0; k < this.nowStage.section.length; k++) {
                                    if (this.nowStage.section[k].sectionId == nowSectionId) {
                                        if (this.nowStage.section[k + 1]) {
                                            this.nowSection = this.nowStage.section[k + 1];
                                        }
                                        else {
                                            if (this.stageArr.stage[j + 1]) {
                                                this.nowStage = this.stageArr.stage[j + 1];
                                                this.nowSection = this.nowStage.section[0];
                                            }
                                            else {
                                                if (this.seriesArr.stage[this.nowSeriesId] && this.nowSeriesId <= this.seriesArr.stageNum) {
                                                    this.stageArr = RES.getRes(this.seriesArr.stage[this.nowSeriesId].CnStagePath);
                                                    this.nowStage = this.stageArr.stage[0];
                                                    this.nowSection = this.nowStage.section[0];
                                                }
                                                else {
                                                    this.nowStage = this.stageArr.stage[j + 1];
                                                    this.nowSection = this.nowStage.section[0];
                                                }
                                            }
                                        }
                                        break;
                                    }
                                }
                                break;
                            }
                        }
                        break;
                    }
                }
            }
            else {
                for (var i = 0; i < this.seriesArr.stageNum; i++) {
                    var recordConfig = new data.RecordConfig();
                    recordConfig.seriesId = this.seriesArr.stage[i].stageId;
                    var record = new data.Record();
                    record.sectionId = 0;
                    record.stageId = 1;
                    recordConfig.record = record;
                    model.record.push(recordConfig);
                }
                console.log("初始化的通关记录", model.record);
                //初始化关卡
                this.nowSeriesId = this.seriesArr.stage[0].stageId;
                this.stageArr = RES.getRes(this.seriesArr.stage[0].CnStagePath);
                this.nowStage = this.stageArr.stage[0];
                this.nowSection = this.nowStage.section[0];
            }
            console.log("初始化的关卡数据", this.nowSeriesId, this.nowStage, this.nowSection);
            this.updateSeriesList();
            RES.loadGroup("stage_" + this.nowSeriesId + "_" + this.nowStage.stageId).then(function () {
                _this.notifyUI(UiCommand.createScence, { stage: _this.nowStage, section: _this.nowSection });
                _this.loadRes();
            });
        };
        /** 刷新章节列表 */
        Controller.prototype.updateSeriesList = function () {
            this.needSeriesArr = [];
            var record = game.Model.getInstance().record;
            var seriesList = [];
            for (var i = 0; i < record.length; i++) {
                for (var j = 0; j < this.seriesArr.stageNum; j++) {
                    if (record[i].seriesId == this.seriesArr.stage[j].stageId) {
                        var series = new data.NeedSeriesConfig();
                        series.stageId = this.seriesArr.stage[j].stageId;
                        var stageArr = RES.getRes(this.seriesArr.stage[i].CnStagePath);
                        series.stage = stageArr;
                        for (var k = 0; k < stageArr.stage.length; k++) {
                            series.stage.stage[k].seriesId = this.seriesArr.stage[j].stageId;
                            if (stageArr.stage[k].stageId <= record[i].record.stageId) {
                                series.stage.stage[k].isLock = false;
                            }
                            else if (stageArr.stage[k].stageId > record[i].record.stageId) {
                                if (record[i].record.stageId + 1 == stageArr.stage[k].stageId && record[i].record.sectionId == 4) {
                                    series.stage.stage[k].isLock = false;
                                }
                                else {
                                    series.stage.stage[k].isLock = true;
                                }
                            }
                            else {
                                series.stage.stage[k].isLock = true;
                            }
                        }
                        seriesList.push(series);
                    }
                }
            }
            this.needSeriesArr = seriesList;
            console.log("需要显示的系列总表数据", this.needSeriesArr);
            this.notifyUI(UiCommand.initSeriesList, this.needSeriesArr);
        };
        /** 重新推理 */
        Controller.prototype.againGame = function () {
            this.createScence();
        };
        /** 获取日记内容 */
        Controller.prototype.getDiary = function () {
            var record = game.Model.getInstance().record;
            var diary = "";
            for (var i = 0; i < this.nowStage.section.length; i++) {
                if (this.nowStage.section[i].sectionId <= this.nowSection.sectionId) {
                    if (this.nowStage.section[i].sectionId == 1) {
                        diary += this.nowStage.section[i].sectionId + ":" + this.nowStage.section[i].sectionName + "\n" + this.nowStage.section[i].question;
                    }
                    else {
                        diary += "\n\n" + this.nowStage.section[i].sectionId + ":" + this.nowStage.section[i].sectionName + "\n" + this.nowStage.section[i].question;
                    }
                    if (this.nowSection.sectionId > this.nowStage.section[i].sectionId) {
                        diary += "\n\n(" + this.nowStage.section[i].answer + ")";
                    }
                }
            }
            this.notifyUI(UiCommand.showDiary, diary);
        };
        /** 刷新已破案数和总关数 */
        Controller.prototype.updateCheckNum = function () {
            var record = game.Model.getInstance().record;
            var max = 0;
            var now = 0;
            for (var i = 0; i < this.seriesArr.stageNum; i++) {
                max += this.seriesArr.stage[i].sectionNum * 4;
            }
            record.forEach(function (record) {
                now += record.record.stageId * 4 - (4 - record.record.sectionId);
            });
            this.notifyUI(UiCommand.updateCheckNum, { now: now, max: max });
            this.updateSeriesList();
        };
        /** 获取关卡的会话列表 */
        Controller.prototype.getStageSectionList = function (json) {
            this.clickSeriesId = json.seriesId;
            this.clickStageId = json.stageId;
            var needSectionArr = [];
            var stageArr;
            var record = game.Model.getInstance().record;
            for (var i = 0; i < this.needSeriesArr.length; i++) {
                if (this.needSeriesArr[i].stageId == json.seriesId) {
                    stageArr = this.needSeriesArr[i].stage;
                    break;
                }
            }
            for (var i = 0; i < record.length; i++) {
                if (record[i].seriesId == json.seriesId) {
                    for (var j = 0; j < stageArr.stage.length; j++) {
                        if (json.stageId == stageArr.stage[j].stageId) {
                            var index = 0;
                            for (var k = 0; k < stageArr.stage[j].section.length; k++) {
                                var needSection = new data.NeedSectionConfig();
                                if (index != 0 && stageArr.stage[j].section[index]) {
                                    needSection.isAdopt = 0;
                                    index = 0;
                                }
                                else {
                                    if (record[i].record.stageId == json.stageId) {
                                        if (record[i].record.sectionId > stageArr.stage[j].section[k].sectionId) {
                                            needSection.isAdopt = 1;
                                        }
                                        else if (record[i].record.sectionId == stageArr.stage[j].section[k].sectionId) {
                                            needSection.isAdopt = 1;
                                            index = k + 1;
                                        }
                                        else {
                                            if (record[i].record.sectionId == 0 && k == 0) {
                                                needSection.isAdopt = 0;
                                            }
                                            else {
                                                needSection.isAdopt = 2;
                                            }
                                        }
                                    }
                                    else if (record[i].record.stageId < json.stageId) {
                                        if (record[i].record.sectionId == 4 && record[i].record.stageId + 1 == json.stageId && k == 0) {
                                            needSection.isAdopt = 0;
                                        }
                                        else {
                                            needSection.isAdopt = 2;
                                        }
                                    }
                                    else {
                                        needSection.isAdopt = 1;
                                    }
                                }
                                needSection.section = this.needSeriesArr[i].stage.stage[j].section[k];
                                needSectionArr.push(needSection);
                            }
                            console.log("要显示的会话列表", needSectionArr);
                            this.notifyUI(UiCommand.showSectionList, needSectionArr);
                            break;
                        }
                    }
                    break;
                }
            }
        };
        /** 加入指定会话 */
        Controller.prototype.joinAppointSection = function (sectionId) {
            for (var i = 0; i < this.needSeriesArr.length; i++) {
                if (this.needSeriesArr[i].stageId == this.clickSeriesId) {
                    this.nowSeriesId = this.clickSeriesId;
                    this.stageArr = this.needSeriesArr[i].stage;
                    break;
                }
            }
            for (var i = 0; i < this.stageArr.stage.length; i++) {
                if (this.stageArr.stage[i].stageId == this.clickStageId) {
                    this.nowStage = this.stageArr.stage[i];
                    break;
                }
            }
            for (var i = 0; i < this.nowStage.section.length; i++) {
                if (sectionId == this.nowStage.section[i].sectionId) {
                    this.nowSection = this.nowStage.section[i];
                    break;
                }
            }
            this.createScence();
        };
        /** 创建场景 */
        Controller.prototype.createScence = function () {
            var img = RES.getRes("Stage" + this.nowSeriesId + "_" + this.nowStage.stageId + "_png");
            if (img) {
                this.notifyUI(UiCommand.createScence, { stage: this.nowStage, section: this.nowSection });
            }
            else {
                this.notifyUI(UiCommand.showTip, "资源正在加载中...");
                RES.loadGroup("stage_" + this.nowSeriesId + "_" + this.nowStage.stageId);
            }
        };
        /** 获取关卡列表 */
        Controller.prototype.getStageList = function (jsonData) {
            this.clickSeriesId = jsonData.seriesId;
            var needStageConfig = new data.NeedStageConfig();
            needStageConfig.seriesId = jsonData.seriesId;
            needStageConfig.stage = jsonData.stageData;
            this.notifyUI(UiCommand.showStageList, needStageConfig);
        };
        /** 保存记录 */
        Controller.prototype.saveRecord = function () {
            var record = game.Model.getInstance().record;
            for (var i = 0; i < record.length; i++) {
                if (record[i].seriesId == this.nowSeriesId) {
                    if (record[i].record.stageId == this.nowStage.stageId) {
                        if (record[i].record.sectionId < this.nowSection.sectionId) {
                            record[i].record.sectionId = this.nowSection.sectionId;
                        }
                    }
                    else if (record[i].record.stageId < this.nowStage.stageId) {
                        record[i].record.stageId = this.nowStage.stageId;
                        record[i].record.sectionId = this.nowSection.sectionId;
                    }
                    break;
                }
            }
            console.log("保存记录", game.Model.getInstance().record);
            game.Model.getInstance().record = record;
            egret.localStorage.setItem(game.GlobalConfig.Record, JSON.stringify(record));
            this.notifyUI(UiCommand.initAnswer, this.nowSection);
            console.log("保存记录", game.Model.getInstance().record);
        };
        /** 下一关 */
        Controller.prototype.joinNextStage = function () {
            if (this.nowSection.sectionId + 1 > 4) {
                for (var i = 0; i < this.stageArr.stage.length; i++) {
                    if (this.stageArr.stage[i] == this.nowStage && this.stageArr.stage[i + 1]) {
                        this.nowStage = this.stageArr.stage[i + 1];
                        this.nowSection = this.nowStage.section[0];
                        this.createScence();
                        break;
                    }
                }
            }
            else {
                for (var i = 0; i < this.nowStage.section.length; i++) {
                    if (this.nowStage.section[i] == this.nowSection) {
                        if (this.nowStage.section[i + 1]) {
                            this.nowSection = this.nowStage.section[i + 1];
                            this.createScence();
                        }
                        else {
                            this.nowSection = this.nowStage.section[i];
                            var isFinish = true;
                            for (var i_1 = 0; i_1 < this.needSeriesArr.length; i_1++) {
                                if (this.nowSeriesId + 1 == this.needSeriesArr[i_1].stageId) {
                                    isFinish = false;
                                    this.stageArr = this.needSeriesArr[i_1].stage;
                                    this.nowStage = this.stageArr.stage[0];
                                    this.nowSection = this.nowStage.section[0];
                                    this.createScence();
                                    break;
                                }
                            }
                            if (isFinish) {
                                this.notifyUI(UiCommand.gameClearance);
                            }
                        }
                        break;
                    }
                }
            }
        };
        return Controller;
    }(game.BaseController));
    game.Controller = Controller;
    __reflect(Controller.prototype, "game.Controller");
})(game || (game = {}));
var data;
(function (data) {
    /** 关卡总表配置 */
    var StageArrConfig = (function () {
        function StageArrConfig() {
        }
        return StageArrConfig;
    }());
    data.StageArrConfig = StageArrConfig;
    __reflect(StageArrConfig.prototype, "data.StageArrConfig");
    /** 关卡配置 */
    var StageConfig = (function () {
        function StageConfig() {
        }
        return StageConfig;
    }());
    data.StageConfig = StageConfig;
    __reflect(StageConfig.prototype, "data.StageConfig");
    /** 对话配置 */
    var SectionConfig = (function () {
        function SectionConfig() {
        }
        return SectionConfig;
    }());
    data.SectionConfig = SectionConfig;
    __reflect(SectionConfig.prototype, "data.SectionConfig");
    /** 系列配置总表 */
    var SeriesAllConfig = (function () {
        function SeriesAllConfig() {
        }
        return SeriesAllConfig;
    }());
    data.SeriesAllConfig = SeriesAllConfig;
    __reflect(SeriesAllConfig.prototype, "data.SeriesAllConfig");
    /** 系列配置 */
    var SeriesConfig = (function () {
        function SeriesConfig() {
        }
        return SeriesConfig;
    }());
    data.SeriesConfig = SeriesConfig;
    __reflect(SeriesConfig.prototype, "data.SeriesConfig");
    /** 需要显示的系列配置 */
    var NeedSeriesConfig = (function () {
        function NeedSeriesConfig() {
        }
        return NeedSeriesConfig;
    }());
    data.NeedSeriesConfig = NeedSeriesConfig;
    __reflect(NeedSeriesConfig.prototype, "data.NeedSeriesConfig");
    /** 需要显示的会话配置 */
    var NeedSectionConfig = (function () {
        function NeedSectionConfig() {
        }
        return NeedSectionConfig;
    }());
    data.NeedSectionConfig = NeedSectionConfig;
    __reflect(NeedSectionConfig.prototype, "data.NeedSectionConfig");
    /** 需要显示的关卡配置 */
    var NeedStageConfig = (function () {
        function NeedStageConfig() {
        }
        return NeedStageConfig;
    }());
    data.NeedStageConfig = NeedStageConfig;
    __reflect(NeedStageConfig.prototype, "data.NeedStageConfig");
    /** 通关记录配置 */
    var RecordConfig = (function () {
        function RecordConfig() {
        }
        return RecordConfig;
    }());
    data.RecordConfig = RecordConfig;
    __reflect(RecordConfig.prototype, "data.RecordConfig");
    /** 单条记录 */
    var Record = (function () {
        function Record() {
        }
        return Record;
    }());
    data.Record = Record;
    __reflect(Record.prototype, "data.Record");
})(data || (data = {}));
var game;
(function (game) {
    var GlobalConfig = (function () {
        function GlobalConfig() {
        }
        /** 本地保存的通关记录字段 */
        GlobalConfig.Record = "Record";
        /** 点击的蓝球直径（正确范围的直径） */
        GlobalConfig.diameter = 65;
        return GlobalConfig;
    }());
    game.GlobalConfig = GlobalConfig;
    __reflect(GlobalConfig.prototype, "game.GlobalConfig");
})(game || (game = {}));
var game;
(function (game) {
    var Model = (function () {
        function Model() {
            /** 适配X */
            this.scaleX = 0;
            /** 适配Y */
            this.scaleY = 0;
        }
        Model.getInstance = function () {
            if (!this._instance)
                this._instance = new Model();
            return this._instance;
        };
        return Model;
    }());
    game.Model = Model;
    __reflect(Model.prototype, "game.Model");
})(game || (game = {}));
var game;
(function (game) {
    /**
     * 工具类(包含常用方法)
     * @author zjw
     */
    var Tool = (function () {
        function Tool() {
        }
        /**
         * 画一条直线
         */
        Tool.drawLine = function (color, size, start, end) {
            var line = new egret.Shape();
            line.graphics.beginFill(color);
            line.graphics.lineStyle(size, color);
            line.graphics.lineTo(start[0], start[1]);
            line.graphics.lineTo(end[0], end[1]);
            line.graphics.endFill();
            return line;
        };
        /** 时间戳转换日期格式yy-mm-dd */
        Tool.timeChange_A = function (time) {
            var date = new Date(time);
            var y = date.getFullYear();
            var m = "0" + (date.getMonth() + 1);
            var d = "0" + date.getDate();
            return y + "-" + m.substring(m.length - 2, m.length) + "-" + d.substring(d.length - 2, d.length);
        };
        /** 日期格式mm-dd-yy|hh:mm:ss转换为时间戳 */
        Tool.timeChange_B = function (dateStr) {
            var time = 0;
            var strArr_a = dateStr.split("|");
            var strArr_b = strArr_a[0].split("-");
            var strArr_c = strArr_a[1].split(":");
            // let strDate:string = strArr_b[2]+"-"+strArr_b[0]+"-"+strArr_b[1]+" "+strArr_a[1];
            var date = new Date(parseInt(strArr_b[2]), parseInt(strArr_b[0]) - 1, parseInt(strArr_b[1]), parseInt(strArr_c[0]), parseInt(strArr_c[1]), parseInt(strArr_c[2]));
            time = date.getTime();
            return time;
        };
        /**
         * 在group里设置图片字
         * @param imgSrc 图片字资源组
         * @param grp 存放图片字的group
         * @param num 需要设置的分数
         * @param tipsImgRes 分数前的提示图片（历史最佳：6666）
         *
         * @author zjw
         */
        Tool.setFontImgInGroup = function (imgSrc, grp, num, tipsImgRes) {
            grp.removeChildren();
            if (tipsImgRes) {
                var img = new eui.Image();
                img.source = tipsImgRes;
                grp.addChild(img);
            }
            var str = num + "";
            for (var i = 0; i < str.length; i++) {
                var img = new eui.Image();
                img.source = imgSrc[parseInt(str.charAt(i))];
                grp.addChild(img);
            }
        };
        /**
         * 预加载指定的帧动画(此方法需要game库)
         * @param configRes 配置文件在RES配置里的key名称
         * @param textureRes 图集文件在RES配置里的key名称
         * @param animationNmae 需要播放的动画的名称
         * @returns 加载完毕的MovieClip对象
         *
         * @author zjw
         */
        Tool.preLoadingFrameAnimation = function (configRes, textureRes, animationNmae) {
            var config = RES.getRes(configRes);
            var texture = RES.getRes(textureRes);
            if (config && texture) {
                var factory = new egret.MovieClipDataFactory(config, texture);
                var mc = new egret.MovieClip(factory.generateMovieClipData(animationNmae));
                return mc;
            }
            else {
                return null;
            }
        };
        /**
         * 指定范围内随机数 Min<=Num<=Max
         * @param Min 最小值
         * @param Max 最大值
         *
         * @author zjw
         */
        Tool.getRandom = function (Min, Max) {
            var Range = Max - Min;
            var Rand = Math.random();
            var num = Min + Math.round(Rand * Range);
            return num;
        };
        /**
         * 一个点根据指定点旋转任意度数后的坐标
         * @param point 需要旋转的点
         * @param target 围绕的目标点
         * @param angle 需要旋转的角度
         *
         * @author zjw
         */
        Tool.getAroundPointRotate = function (point, target, angle) {
            var result = new egret.Point();
            result.x = (point.x - target.x) * Math.cos(angle) - (point.y - target.y) * Math.sin(angle) + target.x;
            result.y = (point.x - target.x) * Math.sin(angle) + (point.y - target.y) * Math.cos(angle) + target.x;
            return result;
        };
        /** 设置一个显示对象的适配属性 */
        Tool.setDisObjAdaptation = function (disObj) {
            var model = game.Model.getInstance();
            var chilsArr = disObj.$children;
            if (chilsArr && disObj instanceof eui.Group) {
                chilsArr.forEach(function (element) {
                    Tool.setDisObjAdaptation(element);
                });
            }
            else {
                if (disObj instanceof eui.Label && model.scaleX < 1) {
                    disObj.scaleX = model.scaleX;
                    disObj.scaleY = model.scaleY;
                }
                else {
                    disObj.scaleX = model.scaleX;
                    disObj.scaleY = model.scaleY;
                }
            }
        };
        /**
         * 预加载指定的粒子特效(此方法需要第三方粒子库particle)
         * @param configRes 配置文件在RES配置里的key名称
         * @param textureRes 图集文件在RES配置里的key名称
         * @returns 加载完毕的GravityParticleSystem对象
         *
         * @author zjw
         */
        // public static preLoadingParticleEffect(configRes: string, textureRes: string): particle.GravityParticleSystem {
        // 	let config: JSON = RES.getRes(configRes);
        // 	let texture: egret.Texture = RES.getRes(textureRes);
        // 	if (texture && config) {
        // 		let effect = new particle.GravityParticleSystem(texture, config);
        // 		return effect;
        // 	} else {
        // 		return null;
        // 	}
        // }
        /** 请求报价数据返回不足3000条时进行日期处理--往前推三个月 */
        Tool.dealDate = function (data) {
            var arrAll = data.startTime.split('|');
            var arrDate = arrAll[0].split('-');
            var month = parseInt(arrDate[0]);
            var newStart = '';
            if (month > 3) {
                newStart = "0" + (month - 3).toString() + "-" + arrDate[1] + "-" + arrDate[2] + "|" + arrAll[1];
                if (month - 3 == 2) {
                    var year = parseInt(arrDate[2]);
                    var day = parseInt(arrDate[1]);
                    if (day > 28) {
                        if (year % 4 == 0 && year % 100 != 0) {
                            newStart = "02-29-" + arrDate[2] + "|" + arrAll[1];
                        }
                        else {
                            newStart = "02-28-" + arrDate[2] + "|" + arrAll[1];
                        }
                    }
                }
            }
            else {
                newStart = (month + 9).toString() + "-" + arrDate[1] + "-" + (parseInt(arrDate[2]) - 1).toString() + "|" + arrAll[1];
            }
            data.startTime = newStart;
            return data;
        };
        /** base64转换成纹理 */
        Tool.base64ToTexture = function (base64) {
            return new Promise(function (resolve, reject) {
                var imgTag = new Image();
                var texture = new egret.Texture();
                imgTag.src = base64;
                imgTag.onload = function () {
                    var bitmapdata = new egret.BitmapData(imgTag);
                    texture.bitmapData = bitmapdata;
                    resolve(texture);
                };
            });
        };
        /** 时间格式处理
         * @param time 毫秒数
        */
        Tool.timeHandler = function (time) {
            var result = "";
            var Minute = "00";
            var Second = "00";
            var numA = time / 60000;
            var numB = time % 60000;
            if (numB == 0) {
                numA >= 10 ? Minute = numA + "" : Minute = "0" + numA;
            }
            else {
                var strArr = (numA + "").split(".");
                var numC = parseInt(strArr[0]);
                numC >= 10 ? Minute = numC + "" : Minute = "0" + numC;
                var numD = numB / 1000;
                numD >= 10 ? Second = numD + "" : Second = "0" + numD;
            }
            result = Minute + ":" + Second;
            return result;
        };
        /** 判断手机号是否合法 */
        Tool.judgeAccount = function (account) {
            var result = false;
            var judge = /^(((13[0-9]{1})|(14[0-9]{1})|(17[0-9]{1})|(15[0-3]{1})|(15[4-9]{1})|(18[0-9]{1})|(199))+\d{8})$/;
            if (!judge.test(account)) {
                result = false;
            }
            else {
                result = true;
            }
            return result;
        };
        return Tool;
    }());
    game.Tool = Tool;
    __reflect(Tool.prototype, "game.Tool");
})(game || (game = {}));
var game;
(function (game) {
    var Service = (function (_super) {
        __extends(Service, _super);
        function Service() {
            var _this = _super.call(this) || this;
            _this.addRegister("Service", _this);
            return _this;
        }
        Service.init = function () {
            if (!this._instance)
                this._instance = new Service();
        };
        /** 罗列要接收的通知 */
        Service.prototype.listNotification = function () {
            return [];
        };
        /** 接收通知 */
        Service.prototype.handleNotification = function (type, body) {
            switch (type) {
            }
        };
        return Service;
    }(game.BaseNotification));
    game.Service = Service;
    __reflect(Service.prototype, "game.Service");
})(game || (game = {}));
var game;
(function (game) {
    /** 游戏场景类 */
    var GameUI = (function (_super) {
        __extends(GameUI, _super);
        function GameUI() {
            var _this = _super.call(this) || this;
            _this.skinName = "resource/skins/GameUISkin.exml";
            return _this;
        }
        /** 初始化操作 */
        GameUI.prototype.initUI = function () {
            this.initAdaptation();
            this.initView();
            this.addStartMenuEventList();
        };
        /** 适配处理 */
        GameUI.prototype.initAdaptation = function () {
            game.Tool.setDisObjAdaptation(this.adaptation);
        };
        /** 添加开始菜单监听 */
        GameUI.prototype.addStartMenuEventList = function () {
            this.grp_start.addEventListener(egret.TouchEvent.TOUCH_TAP, this.startGame, this);
        };
        /** 移除开始菜单监听 */
        GameUI.prototype.removeStartMenuEventList = function () {
            this.grp_start.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.startGame, this);
        };
        /** 初始化界面 */
        GameUI.prototype.initView = function () {
            RES.loadGroup("sound").then(function () {
                game.SoundPlayer.openSound(true);
                game.SoundPlayer.playMusic(game.SoundConst.bg);
            });
            this.grp_tip.visible = false;
            this.grp_tip.alpha = 0;
            this.isFirst = true;
            this.isShowTitle = false;
            this.sco_series.bounces = false;
            this.sco_stage.bounces = false;
            this.grp_start.visible = true;
            this.grp_game.visible = false;
            this.grp_result.visible = false;
            this.grp_diary.visible = false;
            this.isVideo = false;
            this.grp_over.visible = false;
            this.grp_video.visible = false;
            this.grp_set.visible = false;
            this.grp_check.visible = false;
            this.grp_section.visible = false;
            this.grp_goon.visible = false;
            this.grp_tips.visible = false;
            this.grp_stage.visible = false;
            this.list_stage.itemRenderer = game.StageItem;
            this.grp_scence.mask = this.rect_mask;
            this.touchMovePoint0 = new egret.Point(0, 0);
            this.touchMovePoint1 = new egret.Point(0, 0);
            this.isBothHands = false;
            this.oldValue = 0;
            this.lastMoveX = 0;
            this.lastMoveY = 0;
            this.img_target.visible = false;
            this.grp_sure.visible = false;
            this.targetTween = game.Tool.preLoadingFrameAnimation("click_json", "click_png", "click");
            this.sendNotification(UiNotifyConst.initStage);
            this.grp_clue.visible = false;
            this.img_target.width = this.img_target.height = game.GlobalConfig.diameter;
            this.img_target.anchorOffsetX = this.img_target.width / 2;
            this.img_target.anchorOffsetY = this.img_target.height * game.Model.getInstance().scaleY / 2;
            this.grp_gane_head.y = this.grp_game_bg.y;
            // this.rect_mask.width = this.grp_scence.width;
            // this.rect_mask.height = this.grp_scence.height;
            this.grp_scence.anchorOffsetY = this.grp_scence.height * game.Model.getInstance().scaleY / 2;
            this.grp_scence.x = this.width / 2;
            this.grp_scence.y = this.height / 2 - 100;
        };
        /** 接收Controller的控制命令*/
        GameUI.prototype.onControllerCommand = function (type, params) {
            if (params === void 0) { params = null; }
            switch (type) {
                case UiCommand.createScence:
                    this.createScence(params);
                    break;
                case UiCommand.showDiary:
                    this.showDiary(params);
                    break;
                case UiCommand.initSeriesList:
                    this.initSeriesList(params);
                    break;
                case UiCommand.updateCheckNum:
                    this.updateCheckNum(params);
                    break;
                case UiCommand.showSectionList:
                    this.showSectionList(params);
                    break;
                case UiCommand.showStageList:
                    this.showStageList(params);
                    break;
                case UiCommand.initAnswer:
                    this.initAnswer(params);
                    break;
                case UiCommand.gameClearance:
                    this.gameClearance();
                    break;
                case UiCommand.showTip:
                    this.showTips(params);
                    break;
            }
        };
        /** 开始游戏 */
        GameUI.prototype.startGame = function () {
            platform.createBannerAd2();
            this.grp_start.visible = false;
            this.grp_game.visible = true;
            this.grp_clue.visible = true;
            this.removeStartMenuEventList();
            this.addGameScenceEventList();
            this.restScence();
            this.isFirst = false;
        };
        /** 游戏通关 */
        GameUI.prototype.gameClearance = function () {
            this.grp_result.visible = true;
            this.lab_result.text = "全部完成";
            this.grp_result_close.addEventListener(egret.TouchEvent.TOUCH_TAP, this.showCheckView, this);
        };
        /** 添加游戏场景内监听 */
        GameUI.prototype.addGameScenceEventList = function () {
            this.addEventListener(egret.TouchEvent.TOUCH_BEGIN, this.touchBeginScenceHandler, this);
            this.addEventListener(egret.TouchEvent.TOUCH_END, this.touchEndScenceHandler, this);
            this.addEventListener(egret.TouchEvent.TOUCH_MOVE, this.touchMoveScenceHandler, this);
            this.grp_scence.addEventListener(egret.TouchEvent.TOUCH_TAP, this.touchTapScencrHandler, this);
            this.grp_sure.addEventListener(egret.TouchEvent.TOUCH_TAP, this.inspect, this);
            this.grp_close.addEventListener(egret.TouchEvent.TOUCH_TAP, this.closeSection, this);
            this.grp_game_plot.addEventListener(egret.TouchEvent.TOUCH_TAP, this.getDiary, this);
            this.grp_diary_close.addEventListener(egret.TouchEvent.TOUCH_TAP, this.closeDiary, this);
            this.grp_video_close.addEventListener(egret.TouchEvent.TOUCH_TAP, this.closeVideo, this);
            this.grp_game_tips.addEventListener(egret.TouchEvent.TOUCH_TAP, this.showVideo, this);
            this.grp_game_clue.addEventListener(egret.TouchEvent.TOUCH_TAP, this.showClue, this);
            this.grp_setting.addEventListener(egret.TouchEvent.TOUCH_TAP, this.showSetting, this);
            this.grp_set_close.addEventListener(egret.TouchEvent.TOUCH_TAP, this.closeSet, this);
            this.grp_sound.addEventListener(egret.TouchEvent.TOUCH_TAP, this.isOpenSound, this);
            this.grp_game_back.addEventListener(egret.TouchEvent.TOUCH_TAP, this.closeScence, this);
            this.grp_video_look.addEventListener(egret.TouchEvent.TOUCH_TAP, this.playVideo, this);
            this.grp_tips_close.addEventListener(egret.TouchEvent.TOUCH_TAP, this.closeTips, this);
        };
        /** 移除游戏场景内监听 */
        GameUI.prototype.removeGameScenceEventList = function () {
            this.removeEventListener(egret.TouchEvent.TOUCH_BEGIN, this.touchBeginScenceHandler, this);
            this.removeEventListener(egret.TouchEvent.TOUCH_END, this.touchEndScenceHandler, this);
            this.removeEventListener(egret.TouchEvent.TOUCH_MOVE, this.touchMoveScenceHandler, this);
            this.grp_scence.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.touchTapScencrHandler, this);
            this.grp_sure.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.inspect, this);
            this.grp_close.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.closeSection, this);
            this.grp_game_plot.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.getDiary, this);
            this.grp_diary_close.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.closeDiary, this);
            this.grp_video_close.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.closeVideo, this);
            this.grp_game_tips.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.showVideo, this);
            this.grp_game_clue.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.showClue, this);
            this.grp_setting.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.showSetting, this);
            this.grp_set_close.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.closeSet, this);
            this.grp_sound.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.isOpenSound, this);
            this.grp_game_back.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.closeScence, this);
            this.grp_video_look.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.playVideo, this);
            this.grp_tips_close.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.closeTips, this);
        };
        /** 关闭提示组 */
        GameUI.prototype.closeTips = function () {
            game.SoundPlayer.playSoundWav(game.SoundConst.click);
            this.grp_tips.visible = false;
        };
        /** 场景内触摸开始处理 */
        GameUI.prototype.touchBeginScenceHandler = function (evt) {
            this.lastMoveX = evt.stageX;
            this.lastMoveY = evt.stageY;
        };
        /** 场景内触摸结束处理 */
        GameUI.prototype.touchEndScenceHandler = function (evt) {
            this.isBothHands = false;
            this.oldValue = 0;
            this.touchMovePoint0.x = 0;
            this.touchMovePoint0.y = 0;
            this.touchMovePoint1.x = 0;
            this.touchMovePoint1.y = 0;
            this.lastMoveX = 0;
            this.lastMoveY = 0;
        };
        /** 场景内触摸发生时处理 */
        GameUI.prototype.touchMoveScenceHandler = function (evt) {
            var x = evt.stageX;
            var y = evt.stageY;
            var scence = this.grp_scence;
            if (evt.touchPointID == 0) {
                this.touchMovePoint0.x = x;
                this.touchMovePoint0.y = y;
            }
            else {
                this.isBothHands = true;
                this.touchMovePoint1.x = x;
                this.touchMovePoint1.y = y;
            }
            if (this.isBothHands) {
                var value = egret.Point.distance(this.touchMovePoint0, this.touchMovePoint1);
                if (Math.abs(this.oldValue - value) > 2) {
                    if (value > this.oldValue) {
                        if (scence.scaleX < 2) {
                            scence.scaleX += 0.1;
                            scence.scaleY += 0.1;
                        }
                    }
                    else if (value < this.oldValue) {
                        if (scence.scaleX > 1) {
                            scence.scaleX -= 0.1;
                            scence.scaleY -= 0.1;
                            var speedX = 50;
                            var speedY = 78;
                            var numB = (scence.x - 540);
                            var numC = (scence.y - 960);
                            if (numB < 0) {
                                scence.x + speedX >= 540 ? scence.x = 540 : scence.x += speedX;
                            }
                            else if (numB > 0) {
                                scence.x - speedX <= 540 ? scence.x = 540 : scence.x -= speedX;
                            }
                            if (numC < 0) {
                                scence.y + speedY >= 960 ? scence.y = 960 : scence.y += speedY;
                            }
                            else if (numC > 0) {
                                scence.y - speedY <= 960 ? scence.y = 960 : scence.y -= speedY;
                            }
                        }
                    }
                    this.oldValue = value;
                }
            }
            else {
                if (scence.scaleX) {
                    var valueX = x - this.lastMoveX;
                    var valueY = y - this.lastMoveY;
                    var valueWidth = scence.width * scence.scaleX / 2 + 36 - 540;
                    var valueHeight = scence.height * scence.scaleY / 2 + 288 - 960;
                    if (scence.x + valueX >= 540 - valueWidth && scence.x + valueX <= 540 + valueWidth) {
                        scence.x += valueX;
                    }
                    if (scence.y + valueY >= 960 - valueHeight && scence.y + valueY <= 960 + valueHeight) {
                        scence.y += valueY;
                    }
                    this.lastMoveX = x;
                    this.lastMoveY = y;
                }
            }
        };
        /** 设置确认按钮状态 */
        GameUI.prototype.setSureState = function (type) {
            var grp = this.grp_sure;
            var txt = this.lab_sure;
            var target = this.img_target;
            var distance = target.width * target.scaleY / 2 + 10;
            grp.x = target.x;
            switch (type) {
                case 0://点在左上角
                    grp.scaleX = Math.abs(grp.scaleX);
                    txt.scaleX = Math.abs(txt.scaleX);
                    grp.rotation = 180;
                    txt.rotation = 180;
                    grp.y = target.y + distance;
                    break;
                case 1://点在右上角
                    if (grp.scaleX > 0) {
                        grp.scaleX *= -1;
                        txt.scaleX *= -1;
                    }
                    grp.y = target.y + distance;
                    grp.rotation = 180;
                    txt.rotation = 180;
                    break;
                case 2://点在左下角
                    if (grp.scaleX > 0) {
                        grp.scaleX *= -1;
                        txt.scaleX *= -1;
                    }
                    grp.y = target.y - distance;
                    grp.rotation = 0;
                    txt.rotation = 0;
                    break;
                case 3://点在右下角
                    grp.scaleX = Math.abs(grp.scaleX);
                    txt.scaleX = Math.abs(txt.scaleX);
                    grp.rotation = 0;
                    txt.rotation = 0;
                    grp.y = target.y - distance;
                    break;
            }
        };
        /** 游戏场景内点击处理 */
        GameUI.prototype.touchTapScencrHandler = function (evt) {
            var stageX = evt.stageX;
            var stageY = evt.stageY;
            var width = this.stage.stageWidth / 2;
            var height = this.stage.stageHeight / 2;
            this.img_target.x = evt.localX;
            this.img_target.y = evt.localY * game.Model.getInstance().scaleY;
            console.log(evt.stageY, evt.localY, this.img_scence.x, this.img_scence.y);
            if (stageX < width && stageY < height) {
                this.setSureState(0);
            }
            else if (stageX >= width && stageY <= height) {
                this.setSureState(1);
            }
            else if (stageX < width && stageY > height) {
                this.setSureState(2);
            }
            else if (stageX >= width && stageY >= height) {
                this.setSureState(3);
            }
            this.img_target.visible = true;
            this.grp_sure.visible = true;
        };
        /** 检查是否正确 */
        GameUI.prototype.inspect = function () {
            var _this = this;
            game.SoundPlayer.playSoundWav(game.SoundConst.click);
            var target = this.img_target;
            var centerX = this.img_scence.width * this.img_scence.scaleX / 2;
            var centerY = this.img_scence.height * this.img_scence.scaleY / 2;
            if (!this.targetTween.parent)
                this.grp_scence.addChild(this.targetTween);
            this.targetTween.scaleY = game.Model.getInstance().scaleY;
            this.targetTween.x = target.x;
            this.targetTween.y = target.y;
            this.targetTween.visible = true;
            this.targetTween.play(-1);
            this.grp_sure.visible = false;
            //判断是否在坐标范围内
            var targetPoint = new egret.Point(centerX + this.answerX, centerY - this.answerY);
            var clickPoint = new egret.Point(target.x, target.y);
            var distance = egret.Point.distance(targetPoint, clickPoint);
            this.removeGameScenceEventList();
            setTimeout(function () {
                if (distance <= game.GlobalConfig.diameter * target.scaleY) {
                    _this.setResult(true);
                }
                else {
                    _this.setResult(false);
                }
            }, 1000);
        };
        /** 设置结果 */
        GameUI.prototype.setResult = function (isWin) {
            this.targetTween.visible = false;
            if (isWin) {
                this.lab_result.text = "正确";
                this.grp_result_close.addEventListener(egret.TouchEvent.TOUCH_TAP, this.showVictoryView, this);
            }
            else {
                this.lab_result.text = "不正确";
                this.grp_result_close.addEventListener(egret.TouchEvent.TOUCH_TAP, this.showDefeatView, this);
            }
            this.grp_result.visible = true;
        };
        /** 创建场景内容 */
        GameUI.prototype.createScence = function (data) {
            this.lab_section.text = data.section.sectionId + "." + data.section.sectionName;
            this.lab_question.text = data.section.question;
            this.img_scence.source = data.stage.illust + "_png";
            this.answerX = data.section.answer_x * 1.8;
            this.answerY = data.section.answer_y * 1.53 * game.Model.getInstance().scaleY;
            this.answerW = data.section.answer_w;
            this.answerH = data.section.answer_h;
            this.lab_tips.text = data.section.hint;
            this.lab_explain.text = data.section.answer;
            this.img_answer.source = data.section.answer_image + "_jpg";
            if (!this.isFirst) {
                this.restScence();
            }
            if (data.section.sectionId == 1) {
                this.isShowTitle = true;
                this.lab_title_id.text = "日记." + data.stage.stageId;
                this.lab_title_name.text = data.stage.stageName;
                this.grp_titile.visible = true;
                this.grp_titile.addEventListener(egret.TouchEvent.TOUCH_TAP, this.closeTitile, this);
            }
            else {
                this.isShowTitle = false;
                this.closeTitile();
            }
        };
        /** 重置场景 */
        GameUI.prototype.restScence = function () {
            // platform.showBannerAd(WXManager.getInstance().scenceBanner);
            this.addGameScenceEventList();
            this.grp_tip.alpha = 0;
            this.grp_tip.visible = false;
            this.grp_over_close.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.againGame, this);
            this.grp_over_choose.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.showCheckView, this);
            this.grp_game.visible = true;
            this.grp_result.visible = false;
            this.grp_over.visible = false;
            // this.grp_scence.mask = this.rect_mask;
            this.isBothHands = false;
            this.oldValue = 0;
            this.lastMoveX = 0;
            this.lastMoveY = 0;
            this.isVideo = false;
            this.img_target.visible = false;
            this.grp_sure.visible = false;
            this.grp_clue.visible = true;
            this.grp_scence.scaleX = this.grp_scence.scaleY = 1;
            this.grp_scence.x = 540;
            this.grp_scence.y = this.height / 2 - 100;
            this.grp_diary.visible = false;
            this.grp_video.visible = false;
            this.grp_set.visible = false;
            this.grp_section.visible = false;
            this.removeCheckEventList();
            this.grp_check.visible = false;
            this.grp_goon.visible = false;
            // if(this.isShowTitle)
            // {
            // 	this.grp_titile.visible = true;
            // 	this.grp_titile.addEventListener(egret.TouchEvent.TOUCH_TAP,this.closeTitile,this);
            // }else{
            // 	this.closeTitile();
            // }
        };
        /** 关闭标题界面 */
        GameUI.prototype.closeTitile = function () {
            this.grp_titile.visible = false;
            this.grp_titile.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.closeTitile, this);
        };
        /** 关闭会话界面 */
        GameUI.prototype.closeSection = function () {
            game.SoundPlayer.playSoundWav(game.SoundConst.click);
            this.grp_clue.visible = false;
        };
        /** 显示失败界面 */
        GameUI.prototype.showDefeatView = function () {
            game.SoundPlayer.playSoundWav(game.SoundConst.click);
            this.grp_result_close.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.showDefeatView, this);
            this.grp_result.visible = false;
            this.grp_over_close.addEventListener(egret.TouchEvent.TOUCH_TAP, this.againGame, this);
            this.grp_over_choose.addEventListener(egret.TouchEvent.TOUCH_TAP, this.showCheckView, this);
            this.grp_over_answer.addEventListener(egret.TouchEvent.TOUCH_TAP, this.playVideo, this);
            this.grp_over.visible = true;
            // platform.showBannerAd(WXManager.getInstance().overBanner);
            platform.createInterstitialAd();
        };
        /** 显示胜利界面 */
        GameUI.prototype.showVictoryView = function () {
            game.SoundPlayer.playSoundWav(game.SoundConst.click);
            this.sendNotification(UiNotifyConst.saveRecord);
            this.grp_over_close.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.againGame, this);
            this.grp_over_choose.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.showCheckView, this);
            this.grp_over_answer.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.playVideo, this);
            this.grp_result_close.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.showVictoryView, this);
            this.grp_over.visible = false;
            // platform.hideBannerAd(WXManager.getInstance().overBanner);
            this.grp_result.visible = false;
            this.grp_goon_choose.addEventListener(egret.TouchEvent.TOUCH_TAP, this.showCheckView, this);
            this.grp_goon_next.addEventListener(egret.TouchEvent.TOUCH_TAP, this.joinNextStage, this);
            this.grp_goon.visible = true;
            // platform.createInterstitialAd();
        };
        /** 重新推理 */
        GameUI.prototype.againGame = function () {
            game.SoundPlayer.playSoundWav(game.SoundConst.click);
            this.sendNotification(UiNotifyConst.againGame);
            platform.createBannerAd2();
        };
        /** 获取日记内容 */
        GameUI.prototype.getDiary = function () {
            game.SoundPlayer.playSoundWav(game.SoundConst.click);
            this.sendNotification(UiNotifyConst.getDiary);
        };
        /** 显示日记 */
        GameUI.prototype.showDiary = function (txt) {
            this.lab_diary.text = txt;
            this.grp_diary.visible = true;
        };
        /** 关闭日记 */
        GameUI.prototype.closeDiary = function () {
            game.SoundPlayer.playSoundWav(game.SoundConst.click);
            this.grp_diary.visible = false;
        };
        /** 关闭视频组 */
        GameUI.prototype.closeVideo = function () {
            game.SoundPlayer.playSoundWav(game.SoundConst.click);
            this.grp_video.visible = false;
        };
        /** 显示视频组 */
        GameUI.prototype.showVideo = function () {
            game.SoundPlayer.playSoundWav(game.SoundConst.click);
            this.grp_video.visible = true;
        };
        /** 显示线索组 */
        GameUI.prototype.showClue = function () {
            game.SoundPlayer.playSoundWav(game.SoundConst.click);
            this.grp_clue.visible = true;
        };
        /** 显示设置 */
        GameUI.prototype.showSetting = function () {
            game.SoundPlayer.playSoundWav(game.SoundConst.click);
            this.grp_set.visible = true;
        };
        /** 关闭设置 */
        GameUI.prototype.closeSet = function () {
            game.SoundPlayer.playSoundWav(game.SoundConst.click);
            this.grp_set.visible = false;
        };
        /** 是否需要音效 */
        GameUI.prototype.isOpenSound = function () {
            if (this.img_sound.name == "on") {
                this.img_sound.name = "off";
                game.SoundPlayer.openSound(false);
            }
            else {
                this.img_sound.name = "on";
                game.SoundPlayer.openSound(true);
                game.SoundPlayer.playSoundWav(game.SoundConst.click);
                game.SoundPlayer.playMusic(game.SoundConst.bg);
            }
            this.img_sound.source = "res_json.btn_music_" + this.img_sound.name;
        };
        /** 初始化系列列表 */
        GameUI.prototype.initSeriesList = function (data) {
            this.list_series.itemRenderer = game.Series;
            this.list_series.dataProvider = new eui.ArrayCollection(data);
        };
        /** 关闭场景 */
        GameUI.prototype.closeScence = function () {
            game.SoundPlayer.playSoundWav(game.SoundConst.click);
            this.removeGameScenceEventList();
            this.grp_game.visible = false;
            this.showCheckView();
        };
        /** 显示关卡界面 */
        GameUI.prototype.showCheckView = function () {
            game.SoundPlayer.playSoundWav(game.SoundConst.click);
            this.sendNotification(UiNotifyConst.updateCheckNum);
            this.grp_over_close.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.againGame, this);
            this.grp_over_choose.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.showCheckView, this);
            this.grp_over_answer.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.playVideo, this);
            this.grp_goon_choose.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.showCheckView, this);
            this.grp_goon_next.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.joinNextStage, this);
            this.grp_result_close.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.showCheckView, this);
            this.grp_result.visible = false;
            this.grp_over.visible = false;
            this.grp_check.visible = true;
            this.sco_series.visible = true;
            this.sco_series.viewport.scrollV = 0;
            this.addCheckEventList();
        };
        /** 添加关卡界面监听 */
        GameUI.prototype.addCheckEventList = function () {
            this.grp_check_back.addEventListener(egret.TouchEvent.TOUCH_TAP, this.closeCheck, this);
            this.img_stage_close.addEventListener(egret.TouchEvent.TOUCH_TAP, this.closeStageList, this);
        };
        /** 移除关卡界面监听 */
        GameUI.prototype.removeCheckEventList = function () {
            this.grp_check_back.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.closeCheck, this);
            this.img_stage_close.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.closeStageList, this);
        };
        /** 关闭关卡界面 */
        GameUI.prototype.closeCheck = function () {
            game.SoundPlayer.playSoundWav(game.SoundConst.click);
            if (this.grp_section.visible) {
                this.grp_section.visible = false;
                this.sco_series.visible = true;
                for (var i = 0; i < 4; i++) {
                    this["grp_section_" + i].removeEventListener(egret.TouchEvent.TOUCH_TAP, this.joinAppointSection, this);
                }
            }
            else {
                this.removeCheckEventList();
                this.grp_check.visible = false;
                this.grp_game.visible = false;
                this.grp_start.visible = true;
                this.addStartMenuEventList();
            }
        };
        /** 刷新关卡数 */
        GameUI.prototype.updateCheckNum = function (data) {
            this.lab_num.text = data.now + "/" + data.max;
        };
        /** 显示会话列表 */
        GameUI.prototype.showSectionList = function (data) {
            for (var i = 0; i < data.length; i++) {
                this["grp_section_" + i].name = data[i].section.sectionId;
                switch (data[i].isAdopt) {
                    case 0://正在
                        this["grp_section_pass_" + i].visible = false;
                        this["img_section_lock_" + i].visible = false;
                        break;
                    case 1://已通关
                        this["grp_section_pass_" + i].visible = true;
                        this["img_section_lock_" + i].visible = false;
                        break;
                    case 2://未通关
                        this["grp_section_pass_" + i].visible = false;
                        this["img_section_lock_" + i].visible = true;
                        break;
                }
                this["lab_section_id_" + i].text = "QUESTION." + data[i].section.sectionId;
                this["lab_section_name_" + i].text = data[i].section.sectionName;
            }
            for (var i = 0; i < 4; i++) {
                if (!this["img_section_lock_" + i].visible) {
                    this["grp_section_" + i].addEventListener(egret.TouchEvent.TOUCH_TAP, this.joinAppointSection, this);
                }
            }
            this.sco_series.visible = false;
            this.grp_stage.visible = false;
            this.grp_section.visible = true;
        };
        /** 进入指定对话 */
        GameUI.prototype.joinAppointSection = function (evt) {
            game.SoundPlayer.playSoundWav(game.SoundConst.click);
            this.sendNotification(UiNotifyConst.joinAppointSection, parseInt(evt.currentTarget.name));
        };
        /** 显示关卡列表 */
        GameUI.prototype.showStageList = function (data) {
            this.sco_stage.viewport.scrollV = 0;
            this.list_stage.dataProvider = new eui.ArrayCollection(data.stage.stage);
            this.grp_stage.visible = true;
        };
        /** 关闭关卡列表 */
        GameUI.prototype.closeStageList = function () {
            game.SoundPlayer.playSoundWav(game.SoundConst.click);
            this.grp_stage.visible = false;
        };
        /** 初始化答案界面 */
        GameUI.prototype.initAnswer = function (data) {
            this.img_answer.source = data.answer_image + "_jpg";
            this.lab_explain.text = data.answer;
        };
        /** 下一关 */
        GameUI.prototype.joinNextStage = function () {
            game.SoundPlayer.playSoundWav(game.SoundConst.click);
            this.grp_goon.visible = false;
            this.sendNotification(UiNotifyConst.joinNextStage);
        };
        /** 播放广告 */
        GameUI.prototype.playVideo = function (evt) {
            var _this = this;
            game.SoundPlayer.playSoundWav(game.SoundConst.click);
            platform.createRewardedVideoAd(evt.currentTarget.name).then(function (suc) {
                console.log("看完了！", suc);
                switch (suc) {
                    case "1":
                        _this.isVideo = true;
                        _this.grp_tips.visible = true;
                        _this.closeVideo();
                        break;
                    case "2":
                        _this.isVideo = true;
                        _this.showVictoryView();
                        break;
                }
            }).catch(function (data) {
                console.log("没看完！", data);
            });
            // platform.showBannerAd(WXManager.getInstance().videoBanner);
            // switch(evt.currentTarget.name)
            // {
            // 	case "1":
            // 		this.isVideo = true;
            // 		this.grp_tips.visible = true;
            // 		this.closeVideo();
            // 		break;
            // 	case "2":
            // 		this.isVideo = true;
            // 		this.showVictoryView();
            // 		break;
            // }
        };
        /** 显示提示框 */
        GameUI.prototype.showTips = function (txt) {
            var _this = this;
            if (this.grp_tip.alpha != 0) {
                return;
            }
            this.grp_tip.visible = true;
            this.lab_tip.text = txt;
            egret.Tween.get(this.grp_tip)
                .to({ alpha: 1 }, 800)
                .wait(1400)
                .to({ alpha: 0 }, 800)
                .call(function () {
                _this.grp_tip.visible = false;
                egret.Tween.removeTweens(_this.grp_tip);
            });
        };
        return GameUI;
    }(game.BaseUI));
    game.GameUI = GameUI;
    __reflect(GameUI.prototype, "game.GameUI");
})(game || (game = {}));
var game;
(function (game) {
    var Series = (function (_super) {
        __extends(Series, _super);
        function Series() {
            var _this = _super.call(this) || this;
            _this.skinName = "resource/skins/SeriesSkin.exml";
            _this.addEventListener(egret.Event.ADDED_TO_STAGE, _this.init, _this);
            return _this;
        }
        /** 初始化操作 */
        Series.prototype.init = function () {
            for (var i = 0; i < 4; i++) {
                this["grp_" + i].addEventListener(egret.TouchEvent.TOUCH_TAP, this.getStageSectionList, this);
            }
            this.grp_more.addEventListener(egret.TouchEvent.TOUCH_TAP, this.getNeedStageList, this);
            this.grp_chose.addEventListener(egret.TouchEvent.TOUCH_TAP, this.getNeedStageList, this);
        };
        Series.prototype.dataChanged = function () {
            this.setShowContent(this.data);
        };
        /** 设置显示内容 */
        Series.prototype.setShowContent = function (data) {
            this.stageData = data.stage;
            this.img_title.source = "title_" + data.stageId + "_png";
            for (var i = 0; i < 4; i++) {
                this["lab_num_" + i].text = "Stage." + data.stage.stage[i].stageId;
                this["grp_" + i].name = data.stage.stage[i].stageId;
                this["lab_name_" + i].text = data.stage.stage[i].stageName;
                this.seriesId = data.stageId;
                this["img_lock_" + i].visible = data.stage.stage[i].isLock;
            }
        };
        /** 获取关卡会话列表 */
        Series.prototype.getStageSectionList = function (evt) {
            game.SoundPlayer.playSound(game.SoundConst.click);
            if (this["img_lock_" + (parseInt(evt.currentTarget.name) - 1)].visible) {
                return;
            }
            console.log("要显示的系列编号：" + this.seriesId, "要显示的章节Id：" + parseInt(evt.currentTarget.name));
            game.NotifyManager.getInstance().distribute(UiNotifyConst.getStageSectionList, { seriesId: this.seriesId, stageId: parseInt(evt.currentTarget.name) });
        };
        /** 获取需要的关卡列表 */
        Series.prototype.getNeedStageList = function () {
            game.NotifyManager.getInstance().distribute(UiNotifyConst.getStageList, { seriesId: this.seriesId, stageData: this.stageData });
        };
        return Series;
    }(eui.ItemRenderer));
    game.Series = Series;
    __reflect(Series.prototype, "game.Series");
})(game || (game = {}));
var game;
(function (game) {
    var StageItem = (function (_super) {
        __extends(StageItem, _super);
        function StageItem() {
            var _this = _super.call(this) || this;
            _this.skinName = "resource/skins/StageItemSkin.exml";
            _this.addEventListener(egret.Event.ADDED_TO_STAGE, _this.init, _this);
            return _this;
        }
        /** 初始化 */
        StageItem.prototype.init = function () {
            this.img_lock.visible = true;
        };
        StageItem.prototype.dataChanged = function () {
            this.setShowContent(this.data);
        };
        /** 设置显示内容 */
        StageItem.prototype.setShowContent = function (data) {
            this.img_lock.visible = data.isLock;
            this.lab_id.text = "Stage." + data.stageId;
            this.lab_name.text = data.stageName;
            this.stageId = data.stageId;
            this.seriesId = data.seriesId;
            if (!data.isLock) {
                this.addEventListener(egret.TouchEvent.TOUCH_TAP, this.getStageSectionList, this);
            }
        };
        /** 获取关卡会话列表 */
        StageItem.prototype.getStageSectionList = function () {
            game.SoundPlayer.playSound(game.SoundConst.click);
            console.log("要显示的系列编号：" + this.seriesId, "要显示的章节Id：" + this.stageId);
            game.NotifyManager.getInstance().distribute(UiNotifyConst.getStageSectionList, { seriesId: this.seriesId, stageId: this.stageId });
        };
        return StageItem;
    }(eui.ItemRenderer));
    game.StageItem = StageItem;
    __reflect(StageItem.prototype, "game.StageItem");
})(game || (game = {}));

;window.Main = Main;